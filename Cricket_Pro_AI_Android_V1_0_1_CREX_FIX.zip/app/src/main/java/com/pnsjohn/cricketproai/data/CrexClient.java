package com.pnsjohn.cricketproai.data;

import com.pnsjohn.cricketproai.model.*;
import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.util.*; import java.util.regex.*;

public final class CrexClient {
    private static final String BASE="https://crex.com";
    private String get(String url) throws IOException {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36");
        c.setRequestProperty("Accept-Language","en-US,en;q=0.9");
        try(InputStream in=c.getInputStream()){return new String(in.readAllBytes(),StandardCharsets.UTF_8);}
    }
    private static String text(String h){return h.replaceAll("(?is)<script.*?</script>"," ").replaceAll("(?is)<style.*?</style>"," ").replaceAll("<[^>]+>"," ").replace("&amp;","&").replace("&#39;","'").replaceAll("\\s+"," ").trim();}
    public List<LiveMatch> liveMatches() throws IOException {
        String h=get(BASE+"/cricket-live-score");
        Matcher m=Pattern.compile("href=\\\"([^\\\"]*(?:live-score|scorecard)[^\\\"]*)\\\"[^>]*>(.*?)</a>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(h);
        LinkedHashMap<String,LiveMatch> out=new LinkedHashMap<>();
        while(m.find()){
            String u=m.group(1); if(!u.startsWith("http"))u=BASE+(u.startsWith("/")?u:"/"+u);
            if(u.equals(BASE+"/cricket-live-score") || !u.contains("match-updates"))continue;
            String title=text(m.group(2)); if(title.length()<5)continue;
            out.put(u,new LiveMatch(title.length()>90?title.substring(0,90):title,u));
        }
        return new ArrayList<>(out.values());
    }
    public LiveState state(LiveMatch match) throws IOException {
        String h=get(match.url), t=text(h); LiveState s=new LiveState(); s.match=match.title;
        // CREX rendered pages currently use forms such as:
        // SKNP 147-6 (18.1) ... and SKNP 147-6 18.1 Wicket CRR: 8.09.
        // Do not require the literal word "overs".
        Matcher sc=Pattern.compile("(?:^|\\s)(?:[A-Z][A-Z0-9&-]{1,9}\\s+)?(\\d{1,3})\\s*[/\\-]\\s*(\\d{1,2})\\s*\\(?\\s*(\\d{1,2})\\.(\\d)\\s*\\)?(?=\\s|$)",Pattern.CASE_INSENSITIVE).matcher(t);
        if(sc.find()){s.score=Integer.parseInt(sc.group(1));s.wickets=Integer.parseInt(sc.group(2));s.balls=Integer.parseInt(sc.group(3))*6+(sc.group(4)==null?0:Integer.parseInt(sc.group(4)));s.valid=true;}
        Matcher toss=Pattern.compile("([A-Za-z][A-Za-z .&'-]{2,50} won the toss[^.]{0,90})",Pattern.CASE_INSENSITIVE).matcher(t); if(toss.find())s.toss=toss.group(1).trim();
        Matcher venue=Pattern.compile("Venue\\s*:?\\s*([A-Za-z0-9 ,.&'-]{4,80})",Pattern.CASE_INSENSITIVE).matcher(t);if(venue.find())s.venue=venue.group(1).trim();
        // The page title contains the two current batters with their live figures.
        Matcher bats=Pattern.compile("\\(([^(),]{2,40})\\s+\\d{1,3}\\s*\\(\\d{1,3}\\)\\s*,\\s*([^(),]{2,40})\\s+\\d{1,3}\\s*\\(\\d{1,3}\\)\\)").matcher(t);
        if(bats.find()){s.striker=bats.group(1).trim();s.nonStriker=bats.group(2).trim();}
        // Latest commentary is the strongest current bowler/striker evidence.
        Matcher current=Pattern.compile("(?:^|\\s)\\d{1,2}\\.[0-6]\\s+(?:W|wd|nb|[0-6])\\s+([A-Z][A-Za-z .'-]{2,40}?)\\s+to\\s+",Pattern.CASE_INSENSITIVE).matcher(t);
        if(current.find())s.bowler=current.group(1).trim();
        // CREX's compact recent-over ledger is more complete than the visible
        // commentary window and preserves wides as separate deliveries.
        ArrayDeque<String> recent=new ArrayDeque<>();
        Matcher overs=Pattern.compile("Over\\s+\\d+\\s+((?:(?:wd|nb|W|[0-6])\\s+){1,12})=",Pattern.CASE_INSENSITIVE).matcher(t);
        while(overs.find())for(String token:overs.group(1).trim().split("\\s+")){recent.addLast(token.toLowerCase(Locale.ROOT));while(recent.size()>12)recent.removeFirst();}
        if(recent.isEmpty()){
            Matcher delivery=Pattern.compile("(?:^|\\s)\\d{1,2}\\.[0-6]\\s+(W|wd|nb|[0-6])(?=\\s)",Pattern.CASE_INSENSITIVE).matcher(t);
            while(delivery.find()&&recent.size()<12)recent.addLast(delivery.group(1).toLowerCase(Locale.ROOT));
        }
        for(String token:recent){if(token.equals("w"))s.last12Wickets++;else if(token.equals("wd")||token.equals("nb"))s.last12Runs++;else{int r=Integer.parseInt(token);s.last12Runs+=r;if(r==4||r==6)s.last12Boundaries++;}}
        Matcher target=Pattern.compile("Target\\s*:?\\s*(\\d{2,3})",Pattern.CASE_INSENSITIVE).matcher(t);if(target.find())s.target=Integer.parseInt(target.group(1));
        s.status=s.valid?"CREX PRIMARY • verified live score":"CREX page received • score still unverified"; s.fetchedAt=System.currentTimeMillis(); return s;
    }
}
