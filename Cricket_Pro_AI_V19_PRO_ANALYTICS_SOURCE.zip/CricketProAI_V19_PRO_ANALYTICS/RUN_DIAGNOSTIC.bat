@echo off
cd /d "%~dp0"
python --version
python cricket_pro_ai.py > cricket_pro_ai_error.log 2>&1
type cricket_pro_ai_error.log
pause
