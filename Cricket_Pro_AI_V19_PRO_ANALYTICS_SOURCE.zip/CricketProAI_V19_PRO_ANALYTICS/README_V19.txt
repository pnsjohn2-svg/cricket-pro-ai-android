CRICKET PRO AI V19 — PROFESSIONAL PROBABILISTIC ANALYTICS

Built from V18.1 Source Primary Universal Live.

Preserved:
- CREX is the primary no-key live source.
- Cricbuzz is optional structured enrichment.
- Automatic toss, XI, current batter/bowler and delivery extraction.
- Wides/no-balls and repeated extra deliveries remain distinct.

V19 analytics upgrade:
- Deterministic ball-outcome simulation for final-score distributions.
- Median, 50% interval and 80% interval instead of one unsupported range.
- Next-over and next-two-over run bands, boundary and wicket probabilities.
- Scenario probabilities: collapse/suppressed, central and acceleration.
- Explicit analytical confidence based on feed freshness, current matchup,
  delivery ledger, XI coverage and historical player coverage.
- Prediction reliability is kept separate from model-input confidence.
- Optional trained-model hook is documented; no trained XGBoost artefact was
  present in the supplied V18.1 ZIP, so V19 does not falsely claim ML inference.
- Historical Data tab can import selected JSON files, an entire folder, or a
  ZIP of JSON files while live monitoring remains usable.
- Imported matches are stored permanently in cricket_pro_ai.db; duplicates are
  skipped and invalid files are reported without stopping the whole batch.

Import your JSON data while using the app:
1. Open Advanced Tools -> Historical Data Engine.
2. Choose Import JSON Files, Import JSON Folder, or Import ZIP of JSON Files.
3. Keep the live match screen open; import progress runs in the background.
4. When complete, player/venue dropdowns and analytics refresh automatically.

Run on Windows:
1. Keep cricket_pro_ai.db and online_player_cache.json beside cricket_pro_ai.py.
2. Run RUN_CRICKET_PRO_AI.bat.

Important:
The database/model dataset was not included in the V18.1 source archive.
V19 runs with neutral priors when history is missing, but historical coverage
and confidence will correctly remain low until the database is supplied.
