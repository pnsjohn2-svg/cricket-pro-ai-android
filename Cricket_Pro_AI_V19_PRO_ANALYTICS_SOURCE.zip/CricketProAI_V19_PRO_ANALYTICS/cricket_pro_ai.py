
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import sqlite3, json, zipfile, tempfile, os, math, statistics, csv, re, difflib, urllib.request, urllib.parse, threading, time, html, subprocess, shutil as _shutil, queue, hashlib, random
from pathlib import Path
from datetime import datetime

APP_TITLE = "Cricket Pro AI V19 - Professional Probabilistic Analytics"
DB_FILE = "cricket_pro_ai.db"
API_CONFIG_FILE = "live_api_config.json"
ONLINE_PLAYER_CACHE_FILE = "online_player_cache.json"

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def sigmoid(x):
    if x > 30: return 1.0
    if x < -30: return 0.0
    return 1/(1+math.exp(-x))

def safe_div(a,b,default=0.0):
    return a/b if b else default

def norm_name(s):
    return " ".join(str(s or "").strip().split())



def player_key(name):
    s = str(name or "").lower().strip()
    s = re.sub(r"\([^)]*\)", " ", s)
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    return " ".join(s.split())

def surname_of(name):
    t = player_key(name).split()
    return t[-1] if t else ""

def initials_of_given_names(name):
    t = player_key(name).split()
    return "".join(x[0] for x in t[:-1] if x)

def compact_initials_token(name):
    """For DB forms like 'AE Jones', 'N de Klerk', 'DJS Dottin'."""
    t = player_key(name).split()
    if len(t) < 2:
        return ""
    # surname can be compound: de Klerk, van Niekerk, etc.
    particles = {"de","van","von","der","den","di","da","dos","du","le","la","st"}
    surname_start = len(t)-1
    while surname_start-1 >= 0 and t[surname_start-1] in particles:
        surname_start -= 1
    prefix = t[:surname_start]
    if len(prefix)==1 and len(prefix[0]) <= 4:
        return prefix[0]
    return "".join(x[0] for x in prefix if x)

def surname_phrase(name):
    t = player_key(name).split()
    if not t: return ""
    particles = {"de","van","von","der","den","di","da","dos","du","le","la","st"}
    start=len(t)-1
    while start-1>=0 and t[start-1] in particles:
        start-=1
    return " ".join(t[start:])

def identity_score(requested, candidate):
    """
    Returns a conservative identity score.
    Strongly supports Cricsheet abbreviated names:
      Sarah Jennifer Bryce -> SJ Bryce
      Amy Jones -> AE Jones
      Nadine de Klerk -> N de Klerk
      Grace Harris -> GM Harris
    """
    a,b=player_key(requested),player_key(candidate)
    if not a or not b: return 0.0
    if a==b: return 1.0

    at,bt=a.split(),b.split()
    asur,bsur=surname_phrase(a),surname_phrase(b)
    if asur != bsur:
        return difflib.SequenceMatcher(None,a,b).ratio()*0.45

    # Same surname phrase is mandatory for abbreviation logic.
    ai=initials_of_given_names(a)
    bi=compact_initials_token(b)

    # Full-name subset/middle-name omission.
    aset,bset=set(at),set(bt)
    if aset.issubset(bset) or bset.issubset(aset):
        return 0.98

    # Requested full name vs DB initials.
    if ai and bi:
        if ai == bi:
            return 0.985
        # Feed may omit middle names while DB contains them (Grace Harris -> GM Harris).
        if bi.startswith(ai[0]) and ai.startswith(bi[0]):
            # exact first initial + same surname, but weaker than exact initials
            return 0.91

    # First token text similarity with same surname.
    first_ratio=difflib.SequenceMatcher(None,at[0],bt[0]).ratio()
    if first_ratio>=0.75:
        return 0.90 + 0.07*first_ratio

    return difflib.SequenceMatcher(None,a,b).ratio()*0.80

class DB:
    def __init__(self, path):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        # Read-heavy desktop analytics tuning.
        try:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA temp_store=MEMORY")
            self.conn.execute("PRAGMA cache_size=-131072")  # ~128 MB page cache
            self.conn.execute("PRAGMA mmap_size=268435456") # 256 MB when supported
        except Exception:
            pass
        self._query_cache={}
        self._list_cache={}
        self._player_name_cache={}
        self.setup()

    def setup(self):
        c=self.conn.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS matches(
            match_id TEXT PRIMARY KEY,
            date TEXT,
            format TEXT,
            venue TEXT,
            team1 TEXT,
            team2 TEXT,
            winner TEXT
        );
        CREATE TABLE IF NOT EXISTS batting(
            player TEXT,
            match_id TEXT,
            team TEXT,
            innings INTEGER,
            runs INTEGER,
            balls INTEGER,
            fours INTEGER,
            sixes INTEGER,
            dots INTEGER,
            out_flag INTEGER,
            phase_pp_runs INTEGER DEFAULT 0,
            phase_pp_balls INTEGER DEFAULT 0,
            phase_mid_runs INTEGER DEFAULT 0,
            phase_mid_balls INTEGER DEFAULT 0,
            phase_death_runs INTEGER DEFAULT 0,
            phase_death_balls INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS bowling(
            player TEXT,
            match_id TEXT,
            team TEXT,
            innings INTEGER,
            balls INTEGER,
            runs INTEGER,
            wickets INTEGER,
            dots INTEGER,
            fours INTEGER,
            sixes INTEGER,
            phase_pp_runs INTEGER DEFAULT 0,
            phase_pp_balls INTEGER DEFAULT 0,
            phase_pp_wkts INTEGER DEFAULT 0,
            phase_mid_runs INTEGER DEFAULT 0,
            phase_mid_balls INTEGER DEFAULT 0,
            phase_mid_wkts INTEGER DEFAULT 0,
            phase_death_runs INTEGER DEFAULT 0,
            phase_death_balls INTEGER DEFAULT 0,
            phase_death_wkts INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS innings(
            match_id TEXT,
            innings INTEGER,
            batting_team TEXT,
            bowling_team TEXT,
            venue TEXT,
            format TEXT,
            total_runs INTEGER,
            wickets INTEGER,
            balls INTEGER
        );
        CREATE TABLE IF NOT EXISTS player_aliases(
            alias TEXT PRIMARY KEY,
            canonical TEXT NOT NULL,
            confidence REAL DEFAULT 1.0
        );
        CREATE INDEX IF NOT EXISTS idx_bat_player ON batting(player);
        CREATE INDEX IF NOT EXISTS idx_bowl_player ON bowling(player);
        CREATE INDEX IF NOT EXISTS idx_inn_venue ON innings(venue, format);

        -- Large-database indexes. Existing queries use lower(player)/lower(venue),
        -- so normal indexes alone are not enough.
        CREATE INDEX IF NOT EXISTS idx_bat_player_ci ON batting(lower(player));
        CREATE INDEX IF NOT EXISTS idx_bowl_player_ci ON bowling(lower(player));
        CREATE INDEX IF NOT EXISTS idx_alias_ci ON player_aliases(lower(alias));
        CREATE INDEX IF NOT EXISTS idx_bat_match ON batting(match_id);
        CREATE INDEX IF NOT EXISTS idx_bowl_match ON bowling(match_id);
        CREATE INDEX IF NOT EXISTS idx_matches_format_date ON matches(format,date);
        CREATE INDEX IF NOT EXISTS idx_inn_venue_ci_fmt_inn ON innings(lower(venue),format,innings);
        CREATE INDEX IF NOT EXISTS idx_inn_fmt_inn ON innings(format,innings);
        """)
        self.conn.commit()

    def invalidate_caches(self):
        self._query_cache.clear()
        self._list_cache.clear()
        self._player_name_cache.clear()

    def _cache_get(self,key):
        return self._query_cache.get(key,"__MISS__")

    def _cache_set(self,key,value):
        self._query_cache[key]=value
        return value

    def counts(self):
        c=self.conn.cursor()
        return {
            "matches": c.execute("select count(*) from matches").fetchone()[0],
            "batters": c.execute("select count(distinct player) from batting").fetchone()[0],
            "bowlers": c.execute("select count(distinct player) from bowling").fetchone()[0],
            "innings": c.execute("select count(*) from innings").fetchone()[0],
        }

    def all_teams(self, fmt=None):
        ck=("all_teams",fmt or "ALL")
        if ck in self._list_cache:return list(self._list_cache[ck])
        if fmt:
            rows=self.conn.execute("""
                SELECT DISTINCT team FROM (
                    SELECT batting_team team FROM innings WHERE format=?
                    UNION
                    SELECT bowling_team team FROM innings WHERE format=?
                )
                WHERE team<>'' ORDER BY team
            """,(fmt,fmt)).fetchall()
        else:
            rows=self.conn.execute("""
                SELECT DISTINCT team FROM (
                    SELECT batting_team team FROM innings
                    UNION
                    SELECT bowling_team team FROM innings
                )
                WHERE team<>'' ORDER BY team
            """).fetchall()
        out=[r[0] for r in rows if r[0]]
        self._list_cache[ck]=tuple(out)
        return out

    def all_venues(self, fmt=None):
        ck=("all_venues",fmt or "ALL")
        if ck in self._list_cache:return list(self._list_cache[ck])
        if fmt:
            rows=self.conn.execute("SELECT DISTINCT venue FROM innings WHERE format=? AND venue<>'' ORDER BY venue",(fmt,)).fetchall()
        else:
            rows=self.conn.execute("SELECT DISTINCT venue FROM innings WHERE venue<>'' ORDER BY venue").fetchall()
        out=[r[0] for r in rows if r[0]]
        self._list_cache[ck]=tuple(out)
        return out

    def all_players(self, fmt=None):
        ck=("all_players",fmt or "ALL")
        if ck in self._list_cache:return list(self._list_cache[ck])
        if fmt:
            rows=self.conn.execute("""
                SELECT DISTINCT player FROM (
                    SELECT b.player player FROM batting b JOIN matches m ON m.match_id=b.match_id WHERE m.format=?
                    UNION
                    SELECT bo.player player FROM bowling bo JOIN matches m2 ON m2.match_id=bo.match_id WHERE m2.format=?
                ) ORDER BY player
            """,(fmt,fmt)).fetchall()
        else:
            rows=self.conn.execute("""
                SELECT DISTINCT player FROM (
                    SELECT player FROM batting
                    UNION
                    SELECT player FROM bowling
                ) ORDER BY player
            """).fetchall()
        out=[r[0] for r in rows if r[0]]
        self._list_cache[ck]=tuple(out)
        return out

    def save_alias(self, alias, canonical, confidence=1.0):
        alias=norm_name(alias); canonical=norm_name(canonical)
        if alias and canonical:
            self.conn.execute("INSERT OR REPLACE INTO player_aliases(alias,canonical,confidence) VALUES(?,?,?)",
                              (alias,canonical,float(confidence)))
            self.conn.commit()

    def resolve_player(self, player, table, fmt=None):
        requested = norm_name(player)
        if not requested:
            return None, 0.0
        _rkey=("resolve",table,fmt or "ALL",requested.lower())
        _cached=self._cache_get(_rkey)
        if _cached!="__MISS__":
            return _cached

        # User/learned alias first.
        ar=self.conn.execute("SELECT canonical,confidence FROM player_aliases WHERE lower(alias)=lower(?)",(requested,)).fetchone()
        if ar:
            return self._cache_set(_rkey,(ar["canonical"], float(ar["confidence"] or 1.0)))

        # Exact case-insensitive match.
        row = self.conn.execute(f"SELECT player FROM {table} WHERE lower(player)=lower(?) LIMIT 1", (requested,)).fetchone()
        if row:
            return self._cache_set(_rkey,(row[0], 1.0))

        cache_key = (table, fmt or "ALL")
        if not hasattr(self, "_player_name_cache"):
            self._player_name_cache = {}
        if cache_key not in self._player_name_cache:
            if fmt:
                rows = self.conn.execute(
                    f"SELECT DISTINCT t.player FROM {table} t JOIN matches m ON m.match_id=t.match_id WHERE m.format=?",
                    (fmt,)
                ).fetchall()
            else:
                rows = self.conn.execute(f"SELECT DISTINCT player FROM {table}").fetchall()
            self._player_name_cache[cache_key] = [r[0] for r in rows if r[0]]

        candidates=self._player_name_cache[cache_key]
        req_surname=surname_phrase(requested)
        same_surname=[c for c in candidates if surname_phrase(c)==req_surname] if req_surname else []
        pool=same_surname if same_surname else candidates

        scored=sorted(((identity_score(requested,c),c) for c in pool), reverse=True)
        if not scored:
            return None,0.0
        best_score,best_name=scored[0]
        second_score=scored[1][0] if len(scored)>1 else 0.0

        # Ambiguity guard: don't auto-resolve two near-equal candidates.
        if best_score >= 0.90 and (best_score-second_score >= 0.035 or best_score >= 0.98):
            # Learn only high-confidence aliases automatically.
            if best_score >= 0.97:
                self.save_alias(requested,best_name,best_score)
            return self._cache_set(_rkey,(best_name,best_score))

        return self._cache_set(_rkey,(None,best_score))

    def player_batting(self, player, fmt=None):
        requested=norm_name(player)
        ck=("player_batting",fmt or "ALL",requested.lower())
        cached=self._cache_get(ck)
        if cached!="__MISS__":return cached
        player, match_score = self.resolve_player(requested, "batting", fmt)
        if not player:
            return self._cache_set(ck,None)
        q="""SELECT 
             COUNT(DISTINCT b.match_id) matches,
             SUM(b.runs) runs, SUM(b.balls) balls, SUM(b.fours) fours, SUM(b.sixes) sixes,
             SUM(b.dots) dots, SUM(b.out_flag) dismissals,
             SUM(b.phase_pp_runs) pp_runs, SUM(b.phase_pp_balls) pp_balls,
             SUM(b.phase_mid_runs) mid_runs, SUM(b.phase_mid_balls) mid_balls,
             SUM(b.phase_death_runs) death_runs, SUM(b.phase_death_balls) death_balls
             FROM batting b"""
        params=[player]
        where=" WHERE lower(b.player)=lower(?)"
        if fmt:
            q += " JOIN matches m ON m.match_id=b.match_id"
            where += " AND m.format=?"
            params.append(fmt)
        r=self.conn.execute(q+where,params).fetchone()
        if not r or not r["balls"]:
            return None
        balls=r["balls"] or 0; runs=r["runs"] or 0; dis=r["dismissals"] or 0
        result={
            "matches":r["matches"] or 0,
            "runs":runs,"balls":balls,
            "sr":safe_div(runs*100,balls),
            "avg":safe_div(runs,dis, runs if runs else 0),
            "boundary_pct":safe_div(((r["fours"] or 0)+(r["sixes"] or 0))*100,balls),
            "dot_pct":safe_div((r["dots"] or 0)*100,balls),
            "dismissal_ball_pct":safe_div(dis*100,balls),
            "pp_sr":safe_div((r["pp_runs"] or 0)*100,(r["pp_balls"] or 0)),
            "mid_sr":safe_div((r["mid_runs"] or 0)*100,(r["mid_balls"] or 0)),
            "death_sr":safe_div((r["death_runs"] or 0)*100,(r["death_balls"] or 0)),
            "matched_name": player,
            "requested_name": requested,
            "name_match": round(match_score,3),
        }
        return self._cache_set(ck,result)

    def player_bowling(self, player, fmt=None):
        requested=norm_name(player)
        ck=("player_bowling",fmt or "ALL",requested.lower())
        cached=self._cache_get(ck)
        if cached!="__MISS__":return cached
        player, match_score = self.resolve_player(requested, "bowling", fmt)
        if not player:
            return self._cache_set(ck,None)
        q="""SELECT 
             COUNT(DISTINCT b.match_id) matches,
             SUM(b.balls) balls, SUM(b.runs) runs, SUM(b.wickets) wickets,
             SUM(b.dots) dots, SUM(b.fours) fours, SUM(b.sixes) sixes,
             SUM(b.phase_pp_runs) pp_runs, SUM(b.phase_pp_balls) pp_balls, SUM(b.phase_pp_wkts) pp_wkts,
             SUM(b.phase_mid_runs) mid_runs, SUM(b.phase_mid_balls) mid_balls, SUM(b.phase_mid_wkts) mid_wkts,
             SUM(b.phase_death_runs) death_runs, SUM(b.phase_death_balls) death_balls, SUM(b.phase_death_wkts) death_wkts
             FROM bowling b"""
        params=[player]
        where=" WHERE lower(b.player)=lower(?)"
        if fmt:
            q += " JOIN matches m ON m.match_id=b.match_id"
            where += " AND m.format=?"
            params.append(fmt)
        r=self.conn.execute(q+where,params).fetchone()
        if not r or not r["balls"]:
            return None
        balls=r["balls"] or 0; runs=r["runs"] or 0; wk=r["wickets"] or 0
        result={
            "matches":r["matches"] or 0,
            "balls":balls,"runs":runs,"wickets":wk,
            "econ":safe_div(runs*6,balls),
            "sr":safe_div(balls,wk,999),
            "dot_pct":safe_div((r["dots"] or 0)*100,balls),
            "boundary_pct":safe_div(((r["fours"] or 0)+(r["sixes"] or 0))*100,balls),
            "pp_econ":safe_div((r["pp_runs"] or 0)*6,(r["pp_balls"] or 0),99),
            "mid_econ":safe_div((r["mid_runs"] or 0)*6,(r["mid_balls"] or 0),99),
            "death_econ":safe_div((r["death_runs"] or 0)*6,(r["death_balls"] or 0),99),
            "pp_wkts":r["pp_wkts"] or 0,
            "mid_wkts":r["mid_wkts"] or 0,
            "death_wkts":r["death_wkts"] or 0,
            "matched_name": player,
            "requested_name": requested,
            "name_match": round(match_score,3),
        }
        return self._cache_set(ck,result)

    def venue_stats(self, venue, fmt):
        venue=norm_name(venue)
        ck=("venue_stats",fmt,venue.lower())
        cached=self._cache_get(ck)
        if cached!="__MISS__":return cached
        rows=self.conn.execute(
            "SELECT total_runs FROM innings WHERE lower(venue)=lower(?) AND format=? AND innings=1",
            (venue,fmt)).fetchall()
        vals=[r[0] for r in rows if r[0] is not None]
        if not vals:
            rows=self.conn.execute(
                "SELECT total_runs FROM innings WHERE format=? AND innings=1",(fmt,)).fetchall()
            vals=[r[0] for r in rows if r[0] is not None]
            fallback=True
        else:
            fallback=False
        if not vals:
            return self._cache_set(ck,{"n":0,"avg":170 if fmt=="T20" else 145,"median":170 if fmt=="T20" else 145,
                    "p25":150 if fmt=="T20" else 130,"p75":190 if fmt=="T20" else 160,"fallback":True})
        vals=sorted(vals)
        def pct(p):
            i=(len(vals)-1)*p
            lo=int(math.floor(i)); hi=int(math.ceil(i))
            if lo==hi:return vals[lo]
            return vals[lo]*(hi-i)+vals[hi]*(i-lo)
        result={
            "n":len(vals),
            "avg":statistics.mean(vals),
            "median":statistics.median(vals),
            "p25":pct(.25),
            "p75":pct(.75),
            "fallback":fallback
        }
        return self._cache_set(ck,result)

    def recent_batting_form(self, player, fmt=None, limit=10):
        ck=("recent_batting",fmt or "ALL",norm_name(player).lower(),int(limit))
        cached=self._cache_get(ck)
        if cached!="__MISS__":return cached
        player_resolved, conf = self.resolve_player(player, "batting", fmt)
        if not player_resolved:
            return self._cache_set(ck,None)
        params=[player_resolved]
        fmt_join=""
        fmt_where=""
        if fmt:
            fmt_join=" JOIN matches m ON m.match_id=b.match_id"
            fmt_where=" AND m.format=?"
            params.append(fmt)
        q=f"""SELECT b.runs,b.balls,b.out_flag,COALESCE(m2.date,'') dt
              FROM batting b
              LEFT JOIN matches m2 ON m2.match_id=b.match_id
              {fmt_join}
              WHERE lower(b.player)=lower(?) {fmt_where}
              ORDER BY COALESCE(m2.date,'' ) DESC, b.rowid DESC
              LIMIT {int(limit)}"""
        rows=self.conn.execute(q,params).fetchall()
        if not rows:return self._cache_set(ck,None)
        runs=sum(r["runs"] or 0 for r in rows)
        balls=sum(r["balls"] or 0 for r in rows)
        outs=sum(r["out_flag"] or 0 for r in rows)
        scores=[r["runs"] or 0 for r in rows]
        result={
            "innings":len(rows),
            "runs":runs,
            "balls":balls,
            "sr":safe_div(runs*100,balls),
            "avg":safe_div(runs,outs,runs if runs else 0),
            "avg_score":safe_div(runs,len(rows)),
            "scores":scores,
            "name":player_resolved,
            "match_conf":conf
        }
        return self._cache_set(ck,result)

    def recent_bowling_form(self, player, fmt=None, limit=10):
        ck=("recent_bowling",fmt or "ALL",norm_name(player).lower(),int(limit))
        cached=self._cache_get(ck)
        if cached!="__MISS__":return cached
        player_resolved, conf = self.resolve_player(player, "bowling", fmt)
        if not player_resolved:
            return self._cache_set(ck,None)
        params=[player_resolved]
        fmt_join=""
        fmt_where=""
        if fmt:
            fmt_join=" JOIN matches m ON m.match_id=b.match_id"
            fmt_where=" AND m.format=?"
            params.append(fmt)
        q=f"""SELECT b.runs,b.balls,b.wickets,COALESCE(m2.date,'') dt
              FROM bowling b
              LEFT JOIN matches m2 ON m2.match_id=b.match_id
              {fmt_join}
              WHERE lower(b.player)=lower(?) {fmt_where}
              ORDER BY COALESCE(m2.date,'' ) DESC, b.rowid DESC
              LIMIT {int(limit)}"""
        rows=self.conn.execute(q,params).fetchall()
        if not rows:return self._cache_set(ck,None)
        runs=sum(r["runs"] or 0 for r in rows)
        balls=sum(r["balls"] or 0 for r in rows)
        wk=sum(r["wickets"] or 0 for r in rows)
        wickets_list=[int(r["wickets"] or 0) for r in rows]
        econ_list=[safe_div((r["runs"] or 0)*6,(r["balls"] or 0),99) for r in rows]
        result={
            "innings":len(rows),
            "runs":runs,
            "balls":balls,
            "wickets":wk,
            "econ":safe_div(runs*6,balls,99),
            "sr":safe_div(balls,wk,999),
            "wickets_list":wickets_list,
            "econ_list":econ_list,
            "name":player_resolved,
            "match_conf":conf
        }
        return self._cache_set(ck,result)

class Importer:
    def __init__(self, db, progress_cb=None):
        self.db=db
        self.progress_cb=progress_cb or (lambda x:None)
        self.last_errors=[]

    def infer_format(self, data):
        info=data.get("info",{})
        mt=str(info.get("match_type","")).lower()
        balls_per_over=info.get("balls_per_over",6)
        if "hundred" in mt or balls_per_over==5:
            return "Hundred"
        return "T20"

    def parse_date(self,data):
        dates=data.get("meta",{}).get("data_version")
        info=data.get("info",{})
        ds=info.get("dates",[])
        if ds:
            return str(ds[0])
        return ""

    def phase(self, fmt, legal_ball_index):
        if fmt=="Hundred":
            if legal_ball_index<=25:return "pp"
            if legal_ball_index<=75:return "mid"
            return "death"
        if legal_ball_index<=36:return "pp"
        if legal_ball_index<=96:return "mid"
        return "death"

    def import_json_file(self, path):
        try:
            data=json.loads(Path(path).read_text(encoding="utf-8"))
        except UnicodeDecodeError:
            data=json.loads(Path(path).read_text(encoding="utf-8-sig"))
        if not isinstance(data,dict):
            raise ValueError("Top-level JSON must be an object")
        info=data.get("info",{})
        if not isinstance(info,dict) or not isinstance(data.get("innings",[]),list):
            raise ValueError("Not a supported Cricsheet-style match JSON")
        fmt=self.infer_format(data)
        venue=norm_name(info.get("venue","Unknown"))
        teams=info.get("teams",["Team1","Team2"])
        team1=norm_name(teams[0]) if teams else "Team1"
        team2=norm_name(teams[1]) if len(teams)>1 else "Team2"
        outcome=info.get("outcome",{})
        winner=norm_name(outcome.get("winner",""))
        match_id=Path(path).stem

        # Avoid duplicates
        if self.db.conn.execute("select 1 from matches where match_id=?",(match_id,)).fetchone():
            return False

        self.db.conn.execute("INSERT INTO matches(match_id,date,format,venue,team1,team2,winner) VALUES(?,?,?,?,?,?,?)",
                             (match_id,self.parse_date(data),fmt,venue,team1,team2,winner))

        innings_list=data.get("innings",[])
        for inn_no,inn in enumerate(innings_list,1):
            batting_team=norm_name(inn.get("team",""))
            bowling_team=team2 if batting_team.lower()==team1.lower() else team1
            batter={}
            bowler={}
            total=0; wkts=0; legal=0

            overs=inn.get("overs",[])
            for over in overs:
                for d in over.get("deliveries",[]):
                    striker=norm_name(d.get("batter",""))
                    bow=norm_name(d.get("bowler",""))
                    runs=d.get("runs",{})
                    total_runs=int(runs.get("total",0) or 0)
                    bat_runs=int(runs.get("batter",0) or 0)
                    extras=d.get("extras",{}) or {}
                    is_wide=bool(extras.get("wides",0))
                    is_noball=bool(extras.get("noballs",0))
                    legal_ball=not is_wide and not is_noball
                    if legal_ball:
                        legal+=1
                    ph=self.phase(fmt, legal if legal else 1)

                    bs=batter.setdefault(striker,dict(runs=0,balls=0,fours=0,sixes=0,dots=0,out=0,
                        pp_runs=0,pp_balls=0,mid_runs=0,mid_balls=0,death_runs=0,death_balls=0))
                    bs["runs"]+=bat_runs
                    if legal_ball:
                        bs["balls"]+=1
                        if bat_runs==0: bs["dots"]+=1
                        if ph=="pp": bs["pp_balls"]+=1
                        elif ph=="mid": bs["mid_balls"]+=1
                        else: bs["death_balls"]+=1
                    if bat_runs==4: bs["fours"]+=1
                    if bat_runs==6: bs["sixes"]+=1
                    bs[ph+"_runs"]+=bat_runs

                    bo=bowler.setdefault(bow,dict(balls=0,runs=0,wickets=0,dots=0,fours=0,sixes=0,
                        pp_runs=0,pp_balls=0,pp_wkts=0,mid_runs=0,mid_balls=0,mid_wkts=0,
                        death_runs=0,death_balls=0,death_wkts=0))
                    # bowler runs excludes byes/legbyes
                    bowler_conceded=total_runs-int(extras.get("byes",0) or 0)-int(extras.get("legbyes",0) or 0)
                    bo["runs"]+=max(0,bowler_conceded)
                    bo[ph+"_runs"]+=max(0,bowler_conceded)
                    if legal_ball:
                        bo["balls"]+=1
                        bo[ph+"_balls"]+=1
                        if total_runs==0: bo["dots"]+=1
                    if bat_runs==4: bo["fours"]+=1
                    if bat_runs==6: bo["sixes"]+=1

                    for w in d.get("wickets",[]) or []:
                        kind=str(w.get("kind","")).lower()
                        player_out=norm_name(w.get("player_out",""))
                        if kind not in ("retired hurt","obstructing the field"):
                            wkts+=1
                        # batter dismissal excluding run out/retired
                        if player_out in batter and kind not in ("run out","retired hurt","retired out","obstructing the field"):
                            batter[player_out]["out"]=1
                        if kind not in ("run out","retired hurt","retired out","obstructing the field"):
                            bo["wickets"]+=1
                            bo[ph+"_wkts"]+=1
                    total+=total_runs

            for p,s in batter.items():
                self.db.conn.execute("""INSERT INTO batting
                (player,match_id,team,innings,runs,balls,fours,sixes,dots,out_flag,
                 phase_pp_runs,phase_pp_balls,phase_mid_runs,phase_mid_balls,phase_death_runs,phase_death_balls)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (p,match_id,batting_team,inn_no,s["runs"],s["balls"],s["fours"],s["sixes"],s["dots"],s["out"],
                 s["pp_runs"],s["pp_balls"],s["mid_runs"],s["mid_balls"],s["death_runs"],s["death_balls"]))

            for p,s in bowler.items():
                self.db.conn.execute("""INSERT INTO bowling
                (player,match_id,team,innings,balls,runs,wickets,dots,fours,sixes,
                 phase_pp_runs,phase_pp_balls,phase_pp_wkts,phase_mid_runs,phase_mid_balls,phase_mid_wkts,
                 phase_death_runs,phase_death_balls,phase_death_wkts)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (p,match_id,bowling_team,inn_no,s["balls"],s["runs"],s["wickets"],s["dots"],s["fours"],s["sixes"],
                 s["pp_runs"],s["pp_balls"],s["pp_wkts"],s["mid_runs"],s["mid_balls"],s["mid_wkts"],
                 s["death_runs"],s["death_balls"],s["death_wkts"]))

            self.db.conn.execute("""INSERT INTO innings
            (match_id,innings,batting_team,bowling_team,venue,format,total_runs,wickets,balls)
            VALUES(?,?,?,?,?,?,?,?,?)""",(match_id,inn_no,batting_team,bowling_team,venue,fmt,total,wkts,legal))
        self.db.conn.commit()
        if hasattr(self.db,'_player_name_cache'): self.db._player_name_cache.clear()
        return True

    def import_paths(self, paths):
        ok=0; bad=0
        paths=[Path(p) for p in paths]
        total=len(paths)
        self.last_errors=[]
        # Batch import with a single cache invalidation at the end.
        for i,p in enumerate(paths,1):
            try:
                if self.import_json_file(p): ok+=1
            except Exception as e:
                bad+=1
                if len(self.last_errors)<100:
                    self.last_errors.append(f"{Path(p).name}: {e}")
            # Updating UI thousands of times is expensive. Report every 100 files.
            if i==1 or i==total or i%100==0:
                self.progress_cb(f"Imported {i}/{total} | new {ok} | errors {bad}")
        try:
            self.db.conn.commit()
            self.db.invalidate_caches()
            self.db.conn.execute("PRAGMA optimize")
        except Exception:
            pass
        return ok,bad

    def import_zip(self, zpath):
        with tempfile.TemporaryDirectory() as td:
            with zipfile.ZipFile(zpath) as z:
                base=Path(td).resolve()
                json_members=[]
                for member in z.infolist():
                    if member.is_dir() or not member.filename.lower().endswith(".json"):
                        continue
                    target=(base/member.filename).resolve()
                    if base not in target.parents:
                        raise ValueError("Unsafe ZIP path rejected: "+member.filename)
                    json_members.append(member)
                if not json_members:
                    raise ValueError("ZIP contains no JSON match files")
                for member in json_members:
                    z.extract(member,td)
            paths=list(Path(td).rglob("*.json"))
            return self.import_paths(paths)

class Model:
    def __init__(self, db):
        self.db=db
        self.online_lookup=None

    def batter_score(self, p, fmt):
        s=self.db.player_batting(p,fmt)
        if not s:
            if callable(self.online_lookup):
                online=self.online_lookup(p,fmt,"bat")
                if online:return online
            return None
        # Shrink small samples toward league average
        n=s["balls"]
        reliability=n/(n+120)
        raw=50
        raw += (s["sr"]-(135 if fmt=="T20" else 140))*0.18
        raw += (s["avg"]-22)*0.35
        raw += (s["boundary_pct"]-13)*0.9
        raw -= (s["dot_pct"]-38)*0.28
        raw=clamp(raw,10,95)
        score=50*(1-reliability)+raw*reliability
        return round(score,1), s, reliability

    def bowler_score(self, p, fmt):
        s=self.db.player_bowling(p,fmt)
        if not s:
            if callable(self.online_lookup):
                online=self.online_lookup(p,fmt,"bowl")
                if online:return online
            return None
        n=s["balls"]
        reliability=n/(n+120)
        base_econ=8.4 if fmt=="T20" else 8.7
        raw=50
        raw += (base_econ-s["econ"])*5.2
        raw += (s["dot_pct"]-35)*0.55
        raw += (24-min(s["sr"],40))*0.55
        raw -= (s["boundary_pct"]-12)*0.55
        raw=clamp(raw,10,95)
        score=50*(1-reliability)+raw*reliability
        return round(score,1), s, reliability

    def xi_profile(self, names, fmt):
        bats=[]; bowls=[]; cover=[]
        detail=[]
        for p in names:
            b=self.batter_score(p,fmt)
            bo=self.bowler_score(p,fmt)
            best_cov=0
            matched_name=None
            if b:
                bats.append(b[0]); best_cov=max(best_cov,b[2]); matched_name=b[1].get("matched_name")
            if bo:
                bowls.append(bo[0]); best_cov=max(best_cov,bo[2]); matched_name=matched_name or bo[1].get("matched_name")
            cover.append(best_cov)
            detail.append({
                "requested":p,
                "matched":matched_name,
                "bat_rating":b[0] if b else None,
                "bowl_rating":bo[0] if bo else None,
                "coverage":best_cov*100,
                "status":"MATCHED" if matched_name else "UNRESOLVED"
            })
        bats_sorted=sorted(bats,reverse=True)
        bowls_sorted=sorted(bowls,reverse=True)
        batting=statistics.mean(bats_sorted[:7]) if bats_sorted else 50
        bowling=statistics.mean(bowls_sorted[:6]) if bowls_sorted else 50
        coverage=statistics.mean(cover)*100 if cover else 0
        return {"batting":round(batting,1),"bowling":round(bowling,1),
                "coverage":round(coverage,1),"details":detail,
                "known":sum(1 for x in detail if x["matched"]),"total":len(names)}

    def pre_match(self, fmt, venue, bat_xi, bowl_xi):
        v=self.db.venue_stats(venue,fmt)
        bp=self.xi_profile(bat_xi,fmt)
        op=self.xi_profile(bowl_xi,fmt)
        par=v["avg"]
        xi_edge=(bp["batting"]-op["bowling"])
        pred=par + xi_edge*0.42
        coverage=(bp["coverage"]+op["coverage"])/2
        shrink=coverage/100
        pred=par*(1-shrink*0.35)+pred*(shrink*0.35)
        margin=max(10, round(24-coverage*0.12))
        return {"pred":round(pred),"low":round(pred-margin),"high":round(pred+margin),
                "venue":v,"bat_profile":bp,"bowl_profile":op,"coverage":round(coverage,1)}

    def live_first(self, fmt, venue, bat_xi, bowl_xi, score,wkts,balls,last6,total_balls=None,pp_balls=None):
        total=int(total_balls or (120 if fmt=="T20" else 100))
        pre=self.pre_match(fmt,venue,bat_xi,bowl_xi)
        if balls<=0:
            return {**pre,"phase":"Pre-match","next_runs":0,"wicket_pct":0,"boundary_pct":0}
        progress=balls/total
        live_rr=score*6/balls
        live_final=score + max(0,total-balls)*(score/balls)
        # Momentum
        block=6 if fmt=="T20" else 10
        recent_rpb=last6/max(1,block)
        base_future=(pre["pred"]-score)/max(1,total-balls)
        momentum=(recent_rpb-base_future)*0.25
        wicket_penalty=(wkts/10)*(0.25+0.3*progress)
        future=max(0.45,base_future*(1-wicket_penalty)+momentum)
        live_model=score+future*(total-balls)
        w_live=clamp(0.18+0.78*progress,0.18,0.96)
        pred=pre["pred"]*(1-w_live)+live_model*w_live
        margin=max(6,round((pre["high"]-pre["low"])/2*(1-progress*0.65)))
        pp_cut=int(pp_balls or (36 if fmt=="T20" else 25))
        death_start=max(pp_cut+1, int(total*0.80))
        phase=("Powerplay" if balls <= pp_cut
               else "Middle" if balls <= death_start else "Death")
        next_n=min(block,total-balls)
        next_runs=round(future*next_n,1)
        # Data-aware event probabilities
        bp=pre["bat_profile"]; op=pre["bowl_profile"]
        boundary_ball=clamp(.16+(bp["batting"]-50)/350-(op["bowling"]-50)/500,0.08,0.32)
        wicket_ball=clamp(.035+(op["bowling"]-50)/800+wkts*.0015,0.018,0.075)
        return {**pre,"pred":round(pred),"low":round(max(score,pred-margin)),
                "high":round(pred+margin),"phase":phase,"live_rr":round(live_rr,2),
                "next_runs":next_runs,
                "boundary_pct":round((1-(1-boundary_ball)**max(1,next_n))*100,1),
                "wicket_pct":round((1-(1-wicket_ball)**max(1,next_n))*100,1),
                "next_n":next_n}

    def chase(self, fmt, venue, bat_xi, bowl_xi, score,wkts,balls,target,last6,total_balls=None):
        total=int(total_balls or (120 if fmt=="T20" else 100))
        rem=max(0,total-balls)
        need=max(0,target-score)
        bp=self.xi_profile(bat_xi,fmt); op=self.xi_profile(bowl_xi,fmt)
        coverage=(bp["coverage"]+op["coverage"])/2
        if need<=0:return {"win":100,"need":0,"rem":rem,"rrr":0,"coverage":coverage}
        if rem<=0 or wkts>=10:return {"win":0,"need":need,"rem":rem,"rrr":99,"coverage":coverage}
        req_rpb=need/rem
        current_rpb=score/balls if balls else 0
        recent_rpb=last6/(6 if fmt=="T20" else 10)
        expected=max(.65, current_rpb*.35 + recent_rpb*.25 + (target/total)*.20 +
                     (bp["batting"]/50)*.12 + (50/op["bowling"])*.08)
        z=(expected-req_rpb)*3.6 + (10-wkts-5)*0.48 + (bp["batting"]-op["bowling"])/35
        # uncertainty shrink when coverage low
        win=sigmoid(z)*100
        win=50+(win-50)*(0.45+0.55*coverage/100)
        return {"win":round(clamp(win,1,99),1),"need":need,"rem":rem,
                "rrr":round(req_rpb*6,2),"coverage":round(coverage,1),
                "projected":round(score+expected*rem)}

    def technical_assessment(self, fmt, venue, bat_xi, bowl_xi, score=None, wkts=None, balls=None, target=None, last_block=None):
        pre=self.pre_match(fmt,venue,bat_xi,bowl_xi)
        bp=pre["bat_profile"]; op=pre["bowl_profile"]; v=pre["venue"]
        total=120 if fmt=="T20" else 100
        assessment={}

        # Strength labels
        def band(x):
            if x>=62:return "Elite"
            if x>=56:return "Strong"
            if x>=50:return "Average"
            if x>=44:return "Below Average"
            return "Weak"

        assessment["batting_band"]=band(bp["batting"])
        assessment["bowling_band"]=band(op["bowling"])
        assessment["venue_type"]="High-scoring" if v["avg"] >= (175 if fmt=="T20" else 150) else ("Low-scoring" if v["avg"] <= (150 if fmt=="T20" else 130) else "Balanced")

        if score is not None and balls is not None and balls>0:
            rpb=score/balls
            par_rpb=v["avg"]/total
            assessment["tempo"]="Ahead of par" if rpb>par_rpb*1.10 else ("Behind par" if rpb<par_rpb*0.90 else "Around par")
            progress=balls/total
            phase=("Powerplay" if balls <= (36 if fmt=="T20" else 25)
                   else "Middle" if balls <= (96 if fmt=="T20" else 75) else "Death")
            assessment["phase"]=phase
            assessment["wicket_state"]="Excellent wickets in hand" if wkts<=1 else ("Stable" if wkts<=3 else ("Under pressure" if wkts<=5 else "Collapse risk"))
            if last_block is not None:
                block=6 if fmt=="T20" else 10
                recent_rpb=last_block/block
                assessment["momentum"]="Positive" if recent_rpb>rpb*1.12 else ("Negative" if recent_rpb<rpb*0.82 else "Neutral")
            else:
                assessment["momentum"]="Neutral"

            if target and target>0:
                need=max(0,target-score); rem=max(1,total-balls)
                req=need*6/rem
                assessment["chase_pressure"]="Low" if req<7 else ("Manageable" if req<9 else ("High" if req<11.5 else "Extreme"))
        return assessment

    def coach_forecast_first(self, fmt, venue, bat_xi, bowl_xi, score,wkts,balls,last_block):
        r=self.live_first(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,last_block)
        a=self.technical_assessment(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,None,last_block)
        total=120 if fmt=="T20" else 100
        rem=max(0,total-balls)

        # Scoring bands
        pred=r["pred"]
        bands = []
        for threshold in ([140,160,180,200] if fmt=="T20" else [120,140,160,180]):
            # heuristic probability from distance to projection and interval width
            width=max(8,(r["high"]-r["low"])/2)
            p=1/(1+math.exp((threshold-pred)/max(5,width*0.65)))
            bands.append((threshold,round(p*100,1)))

        # Coaching interpretation
        notes=[]
        if a.get("tempo")=="Ahead of par":
            notes.append("Batting side is scoring above the venue-adjusted par tempo.")
        elif a.get("tempo")=="Behind par":
            notes.append("Current scoring tempo is below venue-adjusted par; acceleration is required.")
        else:
            notes.append("Current scoring tempo is broadly aligned with venue par.")

        if a.get("wicket_state")=="Excellent wickets in hand":
            notes.append("Wickets in hand create room for controlled acceleration.")
        elif a.get("wicket_state")=="Collapse risk":
            notes.append("High wicket loss materially caps the ceiling and raises collapse risk.")

        if a.get("momentum")=="Positive":
            notes.append("Recent scoring momentum is positive; next-block boundary probability is elevated.")
        elif a.get("momentum")=="Negative":
            notes.append("Recent momentum has slowed; a wicket or dot-ball sequence could suppress the projection.")

        if r.get("wicket_pct",0) >= 30:
            notes.append("Short-term wicket risk is significant.")
        if r.get("boundary_pct",0) >= 60:
            notes.append("At least one boundary in the next block is more likely than not.")

        if r["coverage"]<40:
            notes.append("Player-history coverage is limited, so venue and live-state information carry more weight.")

        # likely scenario
        if pred >= r["high"]-4:
            scenario="Aggressive finish / upper-range outcome"
        elif pred <= r["low"]+4:
            scenario="Suppressed scoring / lower-range outcome"
        else:
            scenario="Most likely finish near the central projection"

        return r,a,bands,notes,scenario

    def coach_forecast_chase(self, fmt, venue, bat_xi, bowl_xi, score,wkts,balls,target,last_block):
        r=self.chase(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,target,last_block)
        a=self.technical_assessment(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,target,last_block)
        notes=[]
        if r["win"]>=70:
            notes.append("Chasing side is currently in a strong winning position.")
        elif r["win"]<=30:
            notes.append("Bowling side currently controls the chase.")
        else:
            notes.append("The chase remains competitive.")

        if a.get("chase_pressure")=="Extreme":
            notes.append("Required-rate pressure is extreme; boundaries are needed immediately.")
        elif a.get("chase_pressure")=="High":
            notes.append("Required rate is high enough to increase shot-risk and wicket probability.")
        elif a.get("chase_pressure")=="Low":
            notes.append("Required rate is comfortable; wicket preservation is more valuable than forcing shots.")

        if a.get("momentum")=="Positive":
            notes.append("Recent scoring momentum supports the chase.")
        elif a.get("momentum")=="Negative":
            notes.append("Recent scoring momentum is against the batting side.")

        if r["coverage"]<40:
            notes.append("Low player-history coverage reduces confidence in player-specific adjustments.")

        if r["win"]>=80:
            scenario="Chasing side likely to control the finish"
        elif r["win"]<=20:
            scenario="Bowling side likely to defend successfully"
        else:
            scenario="Match remains live; next wicket/boundary sequence is critical"

        return r,a,notes,scenario

    def _live_player_context(self, fmt, striker, non_striker, bowler):
        sb=self.batter_score(striker,fmt) if striker else None
        nsb=self.batter_score(non_striker,fmt) if non_striker else None
        bw=self.bowler_score(bowler,fmt) if bowler else None
        sf=self.db.recent_batting_form(striker,fmt) if striker else None
        nf=self.db.recent_batting_form(non_striker,fmt) if non_striker else None
        bf=self.db.recent_bowling_form(bowler,fmt) if bowler else None
        return sb,nsb,bw,sf,nf,bf

    def professional_live_first(self, fmt, venue, bat_xi, bowl_xi, score,wkts,balls,
                                last_block_runs, striker, non_striker, bowler,
                                striker_runs, striker_balls, non_runs, non_balls,
                                bowler_runs, bowler_balls, bowler_wkts,
                                partnership_runs, partnership_balls,
                                balls_since_boundary, balls_since_wicket,
                                boundaries_last12, wickets_last12,
                                yet_to_bat, available_bowlers, total_balls=None, pp_balls=None):
        total=int(total_balls or (120 if fmt=="T20" else 100))
        block=6 if fmt=="T20" else 10
        base=self.live_first(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,last_block_runs,total,pp_balls)
        sb,nsb,bw,sf,nf,bf=self._live_player_context(fmt,striker,non_striker,bowler)

        rem=max(0,total-balls)
        if rem<=0:
            return {**base,"next1":0,"next2":0}

        # Current batter live performance
        s_live_sr=safe_div(striker_runs*100,striker_balls,0)
        n_live_sr=safe_div(non_runs*100,non_balls,0)
        # Combined current-batter scoring rate must be weighted by balls faced.
        # Example: 34(13)+1(5) = 35/18 = 194.4, not the mean of 261.5 and 20.0.
        current_pair_sr=safe_div((striker_runs+non_runs)*100,(striker_balls+non_balls),0)

        hist_bat_vals=[x[0] for x in (sb,nsb) if x]
        hist_pair=statistics.mean(hist_bat_vals) if hist_bat_vals else 50
        hist_bowler=bw[0] if bw else 50

        # Recent form adjustments
        form_adj=0
        for f in (sf,nf):
            if f:
                form_adj += clamp((f["sr"]-(135 if fmt=="T20" else 140))/100,-0.25,0.30)*0.5
        bowl_form_adj=0
        if bf:
            base_econ=8.4 if fmt=="T20" else 8.7
            bowl_form_adj=clamp((base_econ-bf["econ"])/8,-0.25,0.25)

        # Partnership stability
        part_rpb=safe_div(partnership_runs,partnership_balls,0)
        part_stability=clamp(partnership_balls/30,0,1)
        wicket_momentum=clamp(wickets_last12/3,0,1)
        boundary_momentum=clamp(boundaries_last12/5,0,1)

        # Remaining batting depth from actual yet-to-bat names
        yet_profile=self.xi_profile(yet_to_bat,fmt) if yet_to_bat else {"batting":50,"coverage":0}
        bowling_resources=self.xi_profile(available_bowlers,fmt) if available_bowlers else {"bowling":50,"coverage":0}

        # Rebuild future run rate from base prediction with player/resource context.
        future_rpb=max(.4,(base["pred"]-score)/max(1,rem))
        live_pair_factor=0
        if current_pair_sr:
            live_pair_factor=clamp((current_pair_sr-(135 if fmt=="T20" else 140))/140,-.30,.35)*0.16
        matchup_factor=(hist_pair-hist_bowler)/100*0.12
        depth_factor=(yet_profile["batting"]-50)/100*0.14
        resource_factor=-(bowling_resources["bowling"]-50)/100*0.13
        momentum_factor=boundary_momentum*0.08 - wicket_momentum*0.12
        partnership_factor=clamp((part_rpb-future_rpb),-.7,.7)*0.08*part_stability
        dot_pressure=clamp(balls_since_boundary/18,0,1)*-0.045
        wicket_relief=clamp(balls_since_wicket/24,0,1)*0.025

        adjusted_rpb=future_rpb*(1+live_pair_factor+matchup_factor+depth_factor+resource_factor+
                                  momentum_factor+partnership_factor+form_adj*0.10+bowl_form_adj*-0.08+
                                  dot_pressure+wicket_relief)
        adjusted_rpb=clamp(adjusted_rpb,.38,2.45)

        pred=round(score+adjusted_rpb*rem)
        # Blend with base to avoid overreacting to tiny samples
        live_detail_weight=clamp((striker_balls+non_balls+bowler_balls)/45,0.15,0.70)
        pred=round(base["pred"]*(1-live_detail_weight)+pred*live_detail_weight)

        margin=max(5,round((base["high"]-base["low"])/2*(1-0.35*live_detail_weight)))
        low=max(score,pred-margin); high=pred+margin

        # Next one and two blocks
        next1_n=min(block,rem)
        next2_n=min(block*2,rem)
        next1=round(adjusted_rpb*next1_n,1)
        # second block slight phase acceleration/pressure uncertainty
        phase_boost=1.05 if balls+block > (96 if fmt=="T20" else 75) else 1.0
        next2=round(adjusted_rpb*next2_n*phase_boost,1)

        # Event probabilities
        bat_event=((hist_pair-50)/100)*0.06
        bowl_event=((hist_bowler-50)/100)*0.05
        boundary_ball=clamp(.16+bat_event-bowl_event+boundary_momentum*.035-wicket_momentum*.02,0.07,.38)
        wicket_ball=clamp(.033+bowl_event-bat_event*.35+wicket_momentum*.025+max(0,balls_since_boundary-10)*.001,0.015,.10)
        boundary1=100*(1-(1-boundary_ball)**max(1,next1_n))
        wicket1=100*(1-(1-wicket_ball)**max(1,next1_n))
        boundary2=100*(1-(1-boundary_ball)**max(1,next2_n))
        wicket2=100*(1-(1-wicket_ball)**max(1,next2_n))

        # Technical flags
        flags=[]
        if wicket_momentum>=0.66: flags.append("Wicket cluster / collapse pressure")
        if boundary_momentum>=0.60: flags.append("Boundary momentum strongly positive")
        if balls_since_boundary>=12: flags.append("Boundary drought building pressure")
        if balls_since_wicket>=24: flags.append("Partnership has stabilized")
        if yet_profile["batting"]>=56: flags.append("Strong batting resources still to come")
        if bowling_resources["bowling"]>=56: flags.append("Strong bowling resources remain")
        if sf and sf["sr"]>150: flags.append(f"{striker} in strong recent scoring form")
        if bf and bf["econ"]<7.5: flags.append(f"{bowler} in strong recent bowling form")

        live_cov=statistics.mean([
            base["coverage"],
            yet_profile.get("coverage",0),
            bowling_resources.get("coverage",0),
            100 if sb else 0, 100 if nsb else 0, 100 if bw else 0
        ])
        return {
            **base,
            "pred":pred,"low":low,"high":high,
            "next1":next1,"next1_n":next1_n,
            "next2":next2,"next2_n":next2_n,
            "boundary1":round(boundary1,1),"wicket1":round(wicket1,1),
            "boundary2":round(boundary2,1),"wicket2":round(wicket2,1),
            "striker_hist":sb[0] if sb else None,
            "non_hist":nsb[0] if nsb else None,
            "bowler_hist":bw[0] if bw else None,
            "striker_form":sf,"non_form":nf,"bowler_form":bf,
            "yet_strength":yet_profile["batting"],
            "yet_coverage":yet_profile.get("coverage",0),
            "remaining_bowl_strength":bowling_resources["bowling"],
            "remaining_bowl_coverage":bowling_resources.get("coverage",0),
            "live_coverage":round(live_cov,1),
            "current_pair_sr":round(current_pair_sr,1),
            "partnership_rpb":round(part_rpb,2),
            "flags":flags,
            "boundary_momentum":"Hot" if boundary_momentum>=.6 else ("Cold" if balls_since_boundary>=12 else "Normal"),
            "wicket_momentum":"High" if wicket_momentum>=.66 else ("Moderate" if wicket_momentum>=.33 else "Low")
        }

    def professional_live_chase(self, fmt, venue, bat_xi, bowl_xi, score,wkts,balls,target,last_block_runs,
                                striker,non_striker,bowler,striker_runs,striker_balls,non_runs,non_balls,
                                bowler_runs,bowler_balls,bowler_wkts,partnership_runs,partnership_balls,
                                balls_since_boundary,balls_since_wicket,boundaries_last12,wickets_last12,
                                yet_to_bat,available_bowlers,total_balls=None,pp_balls=None):
        total=int(total_balls or (120 if fmt=="T20" else 100))
        base=self.chase(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,target,last_block_runs,total)
        first=self.professional_live_first(fmt,venue,bat_xi,bowl_xi,score,wkts,balls,last_block_runs,
                                striker,non_striker,bowler,striker_runs,striker_balls,non_runs,non_balls,
                                bowler_runs,bowler_balls,bowler_wkts,partnership_runs,partnership_balls,
                                balls_since_boundary,balls_since_wicket,boundaries_last12,wickets_last12,
                                yet_to_bat,available_bowlers,total,pp_balls)
        rem=max(0,total-balls); need=max(0,target-score)
        if need<=0:
            win=100
        elif rem<=0 or wkts>=10:
            win=0
        else:
            expected_rpb=max(.35,(first["pred"]-score)/max(1,rem))
            req_rpb=need/rem
            z=(expected_rpb-req_rpb)*4.0 + (10-wkts-5)*.45
            z += (first["yet_strength"]-first["remaining_bowl_strength"])/40
            if first["wicket_momentum"]=="High": z-=.55
            if first["boundary_momentum"]=="Hot": z+=.38
            win=sigmoid(z)*100
            coverage=first["live_coverage"]/100
            win=50+(win-50)*(0.45+0.55*coverage)
            win=clamp(win,1,99)
        return {**first,**base,"win":round(win,1),"loss":round(100-win,1),
                "need":need,"rem":rem,"rrr":round(safe_div(need*6,rem,99),2)}





class PublicMarketPageClient:
    """
    Read-only market-page parser.
    It does not log in, place bets, submit forms or access account balances.
    It only parses a public/renderable event page supplied by the user.
    """
    HEADERS={
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                     "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    }

    def _find_edge(self):
        candidates=[
            os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        for p in candidates:
            if p and os.path.exists(p): return p
        return _shutil.which("msedge") or _shutil.which("microsoft-edge") or _shutil.which("chrome")

    def rendered_html(self,url):
        edge=self._find_edge()
        if not edge:
            raise RuntimeError("Edge/Chrome not found.")
        cmd=[
            edge,"--headless=new","--disable-gpu","--no-sandbox",
            "--disable-dev-shm-usage","--run-all-compositor-stages-before-draw",
            "--virtual-time-budget=3500","--dump-dom",url
        ]
        cp=subprocess.run(cmd,capture_output=True,text=True,timeout=15,encoding="utf-8",errors="ignore")
        if not cp.stdout:
            raise RuntimeError((cp.stderr or "Browser render failed")[:500])
        return cp.stdout

    def plain_lines(self,page):
        txt=re.sub(r"(?is)<script.*?</script>|<style.*?</style>"," ",page)
        txt=re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</tr>|</td>|</th>|</h\d>","\n",txt)
        txt=re.sub(r"(?s)<[^>]+>"," ",txt)
        txt=html.unescape(txt)
        return [" ".join(x.split()) for x in txt.splitlines() if " ".join(x.split())]

    def parse(self,url):
        html_page=self.rendered_html(url)
        lines=self.plain_lines(html_page)
        text="\n".join(lines)
        low=text.lower()

        login_required=any(x in low for x in [
            "login to continue","please login","sign in to continue","enter username","enter password"
        ])
        blocked=any(x in low for x in ["access denied","forbidden","cloudflare","verify you are human"])

        # Known exchange section headers observed on Dubaiexch247-style pages.
        section_aliases=[
            ("match_odds",["match odds"]),
            ("who_will_win",["who will win the match"]),
            ("bookmaker",["bookmaker"]),
            ("fancy_market",["fancy market"]),
            ("line_market",["line market"]),
            ("ball_by_ball",["ball by ball market","ball by ball"]),
            ("khado_market",["khado market"]),
            ("meter_market",["meter market","1 meter market"]),
            ("tied_match",["tied match"]),
        ]

        def detect_section(line):
            l=line.lower()
            for key,aliases in section_aliases:
                if any(a in l for a in aliases):
                    return key
            return None

        sections={k:[] for k,_ in section_aliases}
        sections["other_markets"]=[]
        current="other_markets"
        for i,ln in enumerate(lines):
            sec=detect_section(ln)
            if sec:
                current=sec
            # Keep a wide window of raw exchange rows exactly as visible.
            if current in sections:
                sections[current].append({"line_index":i,"text":ln})

        # Parse generic numeric market rows without assuming every number is a decimal odd.
        def parse_values(ln):
            vals=[]
            for tok in re.findall(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?(?:K|M)?(?![A-Za-z])",ln,re.I):
                raw=tok
                mult=1
                if raw.upper().endswith("K"):
                    mult=1000; raw=raw[:-1]
                elif raw.upper().endswith("M"):
                    mult=1000000; raw=raw[:-1]
                try: vals.append(float(raw)*mult)
                except: pass
            return vals

        market_rows=[]
        current_section="other_markets"
        for i,ln in enumerate(lines):
            sec=detect_section(ln)
            if sec:
                current_section=sec
            l=ln.lower()
            vals=parse_values(ln)
            flags=[]
            if "back" in l: flags.append("back")
            if "lay" in l: flags.append("lay")
            if re.search(r"\byes\b",l): flags.append("yes")
            if re.search(r"\bno\b",l): flags.append("no")
            if "suspended" in l: flags.append("suspended")
            if "cash out" in l: flags.append("cash_out")
            if "min:" in l or "max:" in l: flags.append("limits")
            if vals or flags:
                market_rows.append({
                    "section":current_section,
                    "line_index":i,
                    "text":ln,
                    "values":vals[:12],
                    "flags":flags
                })

        # Explicit min/max extraction.
        limits=[]
        for i,ln in enumerate(lines):
            mm=re.search(r"Min\s*:\s*([\d,.]+)\s*\|\s*Max\s*:\s*([\d,.]+)",ln,re.I)
            if mm:
                try:
                    mn=float(mm.group(1).replace(",",""))
                    mx=float(mm.group(2).replace(",",""))
                    limits.append({"line_index":i,"min":mn,"max":mx,"text":ln})
                except: pass

        # Back/Lay and No/Yes headers, preserved for downstream interpretation.
        headers=[]
        for i,ln in enumerate(lines):
            l=ln.lower()
            if ("back" in l and "lay" in l) or ("no" in l and "yes" in l):
                headers.append({"line_index":i,"text":ln})

        # Try to identify event/match name around "Match Odds" or top visible content.
        match_name=""
        mo_idx=next((i for i,ln in enumerate(lines) if "match odds" in ln.lower()),None)
        if mo_idx is not None:
            for prev in reversed(lines[max(0,mo_idx-12):mo_idx]):
                if (" vs " in prev.lower() or " v " in prev.lower()) and len(prev)<180:
                    match_name=prev
                    break
        if not match_name:
            for ln in lines[:80]:
                if (" vs " in ln.lower() or " v " in ln.lower()) and len(ln)<180:
                    match_name=ln; break

        return {
            "url":url,
            "timestamp":time.time(),
            "match_name":match_name,
            "login_required":login_required,
            "blocked":blocked,
            "headers":headers,
            "limits":limits,
            "market_rows":market_rows,
            "sections":sections,
            "lines":lines,
            "text_sample":"\n".join(lines[:180])
        }


class DirectCrexClient:
    """Fast direct parser for public CREX live pages. No API key."""
    BASE="https://crex.com"
    HEADERS={
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                     "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Referer":"https://crex.com/"
    }

    def _text(self,url):
        req=urllib.request.Request(url,headers=self.HEADERS)
        with urllib.request.urlopen(req,timeout=12) as r:
            return r.read().decode("utf-8","ignore")
    def _find_edge(self):
        candidates=[
            os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        for p in candidates:
            if p and os.path.exists(p):
                return p
        return _shutil.which("msedge") or _shutil.which("microsoft-edge") or _shutil.which("chrome")

    def _rendered_html(self,url):
        edge=self._find_edge()
        if not edge:
            raise RuntimeError("Microsoft Edge/Chrome executable not found.")
        cmd=[
            edge,"--headless=new","--disable-gpu","--no-sandbox",
            "--disable-dev-shm-usage","--run-all-compositor-stages-before-draw",
            "--virtual-time-budget=3500","--dump-dom",url
        ]
        cp=subprocess.run(cmd,capture_output=True,text=True,timeout=12,encoding="utf-8",errors="ignore")
        if not cp.stdout:
            raise RuntimeError((cp.stderr or "Headless browser failed")[:500])
        return cp.stdout

    def _best_page(self,url):
        page=self._text(url)
        probe=" ".join(self._plain(page)[:120])
        if re.search(r"\b\d{1,3}[-/]\d{1,2}\b",probe):
            return page,"static"
        return self._rendered_html(url),"edge-headless"


    def _plain(self,page):
        # Preserve useful line boundaries while removing markup.
        txt=re.sub(r"(?is)<script.*?</script>|<style.*?</style>"," ",page)
        txt=re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</tr>|</h\d>","\n",txt)
        txt=re.sub(r"(?s)<[^>]+>"," ",txt)
        txt=html.unescape(txt)
        lines=[]
        for ln in txt.splitlines():
            ln=" ".join(ln.split())
            if ln: lines.append(ln)
        return lines

    def live_matches(self):
        page=self._text(self.BASE+"/cricket-live-score")
        # Pull cricket-live-score match links and filter obvious finished/upcoming cards.
        pat=re.compile(r"href=['\"](/cricket-live-score/[^'\"]+match-updates-[^'\"]+)['\"]", re.I)
        if not pat.search(page):
            try:
                page=self._rendered_html(self.BASE+"/cricket-live-score")
            except Exception:
                pass
        links=[]
        seen=set()
        for m in pat.finditer(page):
            href=m.group(1)
            if href in seen:continue
            seen.add(href)
            lo=max(0,m.start()-700); hi=min(len(page),m.end()+1200)
            snippet=self._plain(page[lo:hi])
            text=" ".join(snippet)
            low=text.lower()
            if any(x in low for x in ["starting in","won by ","won the match","abandoned","no result"]):
                # Keep if this snippet also clearly says live / needs runs.
                if " live " not in f" {low} " and "need " not in low and "yet to bat" not in low:
                    continue
            slug=href.rsplit("/",1)[-1]
            title=slug.replace("-match-updates-"," ").replace("-"," ").title()
            links.append({
                "id":slug,
                "name":title,
                "status":"Live",
                "matchStarted":True,
                "matchEnded":False,
                "_source":"CREX",
                "_url":self.BASE+href
            })
        return {"status":"success","data":links}

    def health(self):
        out={}
        for label,url in [("CREX home",self.BASE+"/"),("CREX live",self.BASE+"/cricket-live-score")]:
            try:
                t=self._text(url); out[label]={"ok":True,"bytes":len(t)}
            except Exception as e:
                out[label]={"ok":False,"error":str(e)}
        return out

    def detail(self,url):
        page,render_mode=self._best_page(url)
        lines=self._plain(page)
        text="\n".join(lines)
        title_m=re.search(r"(?is)<title>(.*?)</title>",page)
        title=html.unescape(re.sub("<[^>]+>"," ",title_m.group(1))).strip() if title_m else ""

        # Current live score from title/body.
        # Typical: SDS 181-6 (17.4) (Ayush Badoni 91(46), Pranav Pant 14(10))
        score_match=re.search(r"\b([A-Z][A-Z0-9-]{1,8})\s+(\d+)-(\d+)\s*\((\d+(?:\.\d+)?)\)",title)
        if not score_match:
            score_match=re.search(r"\b([A-Z][A-Z0-9-]{1,8})\s+(\d+)-(\d+)\s+(\d+(?:\.\d+)?)\b",text)
        state={}
        if score_match:
            state={
                "team_short":score_match.group(1),
                "score":int(score_match.group(2)),
                "wickets":int(score_match.group(3)),
                "overs":score_match.group(4),
            }

        # Need/target state.
        need_m=re.search(r"need\s+(\d+)\s+runs?\s+in\s+(\d+)\s+balls?",text,re.I)
        if need_m:
            state["need"]=int(need_m.group(1)); state["balls_remaining"]=int(need_m.group(2))
            state["target"]=state.get("score",0)+state["need"]

        crr_m=re.search(r"CRR\s*:\s*([0-9.]+)",text,re.I)
        rrr_m=re.search(r"RRR\s*:\s*([0-9.]+)",text,re.I)
        if crr_m:state["crr"]=float(crr_m.group(1))
        if rrr_m:state["rrr"]=float(rrr_m.group(1))

        # Match metadata and rain/reduction information.
        def first_match(patterns):
            for pat in patterns:
                mm=re.search(pat,text,re.I)
                if mm:return " ".join(mm.group(1).split()).strip(" .:-")
            return ""

        venue=first_match([
            r"(?:Venue|Ground)\s*:?\s*([^\n]{3,100})",
            r"at\s+([A-Za-z][A-Za-z0-9 ,.'&()-]{4,90})\s+(?:on|,\s*\d)"
        ])
        toss=first_match([
            r"Toss\s*:?\s*([^\n]{4,180})",
            r"([A-Za-z][A-Za-z .&'-]{2,70}\s+won the toss[^\n]{0,100})"
        ])

        reduced_overs=None
        reduction_text=""
        reduction_patterns=[
            r"(?:match|innings)\s+reduced\s+to\s+(\d+)\s+overs?",
            r"reduced\s+to\s+(\d+)\s+overs?\s+per\s+side",
            r"(\d+)\s+overs?\s+per\s+side\s+(?:due|after|following)",
        ]
        for pat in reduction_patterns:
            mm=re.search(pat,text,re.I)
            if mm:
                try:reduced_overs=int(mm.group(1)); reduction_text=mm.group(0)
                except:pass
                break

        revised_target=None
        tm=re.search(r"(?:revised|DLS)\s+target\s*(?:of|:)?\s*(\d+)",text,re.I)
        if tm:
            try:revised_target=int(tm.group(1))
            except:pass

        # Explicit powerplay information, when source commentary states it.
        pp_overs=None
        ppm=re.search(r"(?:mandatory\s+)?powerplay(?:\s+ended)?(?:\s+after|\s*:)?\s*(\d+(?:\.\d+)?)\s*overs?",text,re.I)
        if ppm:
            try:pp_overs=float(ppm.group(1))
            except:pass

        # Live event/status text: review, boundary check, wide, DRS, rain, etc.
        event_keywords=("review","third umpire","boundary check","checking boundary","wide",
                        "no ball","no-ball","drs","rain","delay","appeal","run out check",
                        "batting team review","bowling team review")
        live_events=[]
        for ln in lines:
            lowln=ln.lower()
            if any(k in lowln for k in event_keywords):
                live_events.append(ln)
        live_events=live_events[-12:]

        # Commentary lines: delivery text plus nearby descriptive lines.
        commentary=[]
        for i,ln in enumerate(lines):
            if re.match(r"^\d{1,2}\.\d\s+.+?\s+to\s+.+",ln,re.I):
                block=[ln]
                for nxt in lines[i+1:i+4]:
                    if re.match(r"^\d{1,2}\.\d\s+",nxt):break
                    block.append(nxt)
                commentary.append(" | ".join(block))
        commentary=commentary[-18:]

        # Batters from page title; very stable on CREX live detail.
        batters=[]
        pair_m=re.search(
            r"\(([^(),]+?)\s+(\d+)\((\d+)\),\s*([^(),]+?)\s+(\d+)\((\d+)\)\)",
            title
        )
        if pair_m:
            batters=[
                {"name":pair_m.group(1).strip(),"runs":int(pair_m.group(2)),"balls":int(pair_m.group(3))},
                {"name":pair_m.group(4).strip(),"runs":int(pair_m.group(5)),"balls":int(pair_m.group(6))}
            ]

        # Current bowler block: Ajay Yadav 3-31(2.4) Econ:
        bowler=None
        bm=re.search(r"([A-Z][A-Za-z .'-]{2,40})\s+(\d+)-(\d+)\((\d+(?:\.\d+)?)\)\s+Econ\s*:\s*([0-9.]+)",text)
        if bm:
            bowler={"name":bm.group(1).strip(),"wickets":int(bm.group(2)),"runs":int(bm.group(3)),
                    "overs":bm.group(4),"econ":float(bm.group(5))}

        ps_m=re.search(r"P['’]?ship\s*:\s*(\d+)\((\d+)\)",text,re.I)
        partnership={"runs":int(ps_m.group(1)),"balls":int(ps_m.group(2))} if ps_m else {}

        # Parse CREX ball commentary conservatively.
        # IMPORTANT: a nearby standalone "W" elsewhere on the page is NOT accepted as
        # a wicket for this delivery. Wicket is accepted only when explicitly attached
        # to this ball's inline result or immediate commentary phrase.
        deliveries=[]
        def outcome_from_text(s,allow_single_token=False):
            t=" ".join(str(s or "").strip().split())
            u=t.upper()
            if not t:return ("",0,False,False,False)
            # Exact standalone result tokens are accepted only for the immediate result line.
            if allow_single_token and re.fullmatch(r"W|OUT|WICKET",u):
                return ("W",0,True,False,False)
            if re.search(r"\b(?:OUT|WICKET)\b",u) and not re.search(r"\bNO\s+WICKET\b",u):
                return ("W",0,True,False,False)
            if re.search(r"\bSIX\b",u):return ("6",6,False,True,False)
            if re.search(r"\bFOUR\b",u):return ("4",4,False,True,False)
            if re.search(r"\bNO[- ]?BALL\b|\bNB\b",u):
                m=re.search(r"\b([1-6])\s*(?:RUNS?)?\b",u)
                return ("nb",int(m.group(1)) if m else 1,False,False,False)
            if re.search(r"\bWIDE\b|\bWD\b",u):
                m=re.search(r"\b([1-6])\s*WIDES?\b",u)
                return ("wd",int(m.group(1)) if m else 1,False,False,False)
            if re.search(r"\bDOT\b|\bNO RUN\b",u):return ("0",0,False,False,True)
            # Exact run-result phrase only; don't mine arbitrary numbers from commentary.
            m=re.fullmatch(r"([0-6])(?:\s+RUNS?)?",u)
            if m:
                rr=int(m.group(1));return (str(rr),rr,False,rr in (4,6),rr==0)
            return ("",0,False,False,False)

        for i,ln in enumerate(lines):
            mm=re.match(r"^(\d{1,2}\.\d)\s+(.+?)\s+to\s+(.+?)(?:\s*[,|]\s*(.*))?$",ln.strip(),re.I)
            if not mm:continue
            batter_part=mm.group(3).strip()
            inline=mm.group(4) or ""
            sm=re.match(r"^(.*?)(?:,\s*)(FOUR|SIX|OUT|WICKET|NO RUN|\d+\s*RUNS?|WD|WIDE|NB|NO BALL)$",
                        batter_part,re.I)
            if sm:
                batter_part=sm.group(1).strip();inline=sm.group(2)
            token,runs,wicket,boundary,dot=outcome_from_text(inline,True)
            # Only inspect the immediate next non-empty line. Never scan 6 lines ahead.
            if not token and i+1<len(lines) and not re.match(r"^\d{1,2}\.\d\s+",lines[i+1]):
                token,runs,wicket,boundary,dot=outcome_from_text(lines[i+1],True)
            deliveries.append({
                "ball":mm.group(1),"bowler":mm.group(2).strip(),"batter":batter_part,
                "token":token,"runs":runs,"wicket":wicket,"boundary":boundary,"dot":dot,
                "verified_outcome":bool(token),
                "source":"CREX FAST",
                "legal_delivery":str(token).upper() not in ("WD","NB"),
                "extra_delivery":str(token).upper() in ("WD","NB"),
                "extra_runs":runs if str(token).upper() in ("WD","NB") else 0
            })

        # De-duplicate by ball number preserving latest entry.
        dedup={}
        for d in deliveries:dedup[d["ball"]]=d
        deliveries=sorted(dedup.values(),key=lambda d:float(d["ball"]))

        # CREX frequently prints confirmed XI directly in live commentary:
        # "Jorhat Stallions Playing XI : A, B, C ..."
        playing_xi={}
        xi_pat=re.compile(r"([A-Za-z][A-Za-z .&'-]{2,60}?)\s+Playing XI\s*:\s*(.+)",re.I)
        for ln in lines:
            xm=xi_pat.search(ln)
            if not xm:
                continue
            team=" ".join(xm.group(1).split())
            raw=xm.group(2).strip()
            # Stop at common page-section markers if they are attached to the same line.
            raw=re.split(r"\s+(?:Hot Picks|Tournaments|Points Table|Commentary)\b",raw,1,flags=re.I)[0]
            players=[]
            for p in raw.split(","):
                p=re.sub(r"\s*\((?:c|wk|c\s*&\s*wk|wk\s*&\s*c)\)\s*"," ",p,flags=re.I)
                p=" ".join(p.split()).strip(" .")
                if p and len(p)<60:
                    players.append(p)
            if players:
                playing_xi[team]=players[:11]

        # If CREX's dedicated bowler card was not matched, the bowler in the latest
        # ball commentary is the best live source.
        if not bowler and deliveries:
            latest=deliveries[-1]
            bname=latest.get("bowler","").strip()
            if bname:
                bowler={"name":bname,"wickets":0,"runs":0,"overs":"0.0","econ":0.0,
                        "figures_verified":False}

        # Extract a full batting-team name from the latest over summary when possible.
        batting_team_full=""
        for i,ln in enumerate(lines):
            if re.fullmatch(r"\d+/\d+",ln.strip()) and i>0:
                prev=lines[i-1].strip()
                if prev and len(prev)<60 and not re.match(r"^\d",prev):
                    batting_team_full=prev
        return {
            "title":title,
            "state":state,
            "batters":batters,
            "bowler":bowler,
            "partnership":partnership,
            "deliveries":deliveries[-30:],
            "playing_xi":playing_xi,
            "batting_team_full":batting_team_full,
            "venue":venue,
            "toss":toss,
            "reduced_overs":reduced_overs,
            "reduction_text":reduction_text,
            "revised_target":revised_target,
            "pp_overs":pp_overs,
            "live_events":live_events,
            "commentary":commentary,
            "text":text[:30000]
        }

class DirectCricbuzzClient:
    """
    Direct local scraper: your laptop fetches Cricbuzz public pages itself.
    No API key and no hosted intermediary.
    """
    BASE="https://www.cricbuzz.com"
    HEADERS={
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                     "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Referer":"https://www.cricbuzz.com/"
    }

    def _text(self,url):
        req=urllib.request.Request(url,headers=self.HEADERS)
        with urllib.request.urlopen(req,timeout=8) as r:
            return r.read().decode("utf-8","ignore")

    def _json(self,url):
        req=urllib.request.Request(url,headers=self.HEADERS)
        with urllib.request.urlopen(req,timeout=8) as r:
            return json.loads(r.read().decode("utf-8","ignore"))

    def _embedded_json(self,page_html,marker):
        idx=page_html.find(marker)
        if idx<0:
            return None
        start=page_html.rfind("self.__next_f.push",0,idx)
        if start<0:
            start=max(0,idx-5000)
        chunk=page_html[start:]
        q=chunk.find('"')
        if q<0:return None
        end_idx=chunk.find('"]\n',q+1)
        if end_idx<0:end_idx=chunk.find('"])',q+1)
        if end_idx<0:return None
        raw=chunk[q+1:end_idx]
        try:
            decoded=bytes(raw,"utf-8").decode("unicode_escape")
        except Exception:
            decoded=raw.replace('\\"','"').replace("\\\\","\\")
        mi=decoded.find(marker)
        if mi<0:return None
        brace=decoded.find("{",mi)
        if brace<0:return None
        depth=0
        in_string=False
        escape=False
        end=None
        for i,ch in enumerate(decoded[brace:],brace):
            if in_string:
                if escape: escape=False
                elif ch=="\\": escape=True
                elif ch=='"': in_string=False
                continue
            if ch=='"':
                in_string=True; continue
            if ch=="{": depth+=1
            elif ch=="}":
                depth-=1
                if depth==0:
                    end=i;break
        if end is None:return None
        try:return json.loads(decoded[brace:end+1])
        except Exception:return None

    def live_matches(self):
        page=self._text(self.BASE+"/cricket-match/live-scores")
        # discover unique live-score links and IDs
        pat=re.compile(r'href=["\'](/live-cricket-scores/(\d+)/([^"\']+))["\']',re.I)
        found=[]
        seen=set()
        for href,mid,slug in pat.findall(page):
            if mid in seen:continue
            seen.add(mid)
            title=html.unescape(slug.replace("-"," ")).strip().title()
            found.append({
                "id":mid,
                "name":title,
                "status":"Live",
                "matchStarted":True,
                "matchEnded":False,
                "_source":"DirectCricbuzz",
                "_url":self.BASE+href
            })
        return {"status":"success","data":found}

    def _plain_lines(self,page):
        txt=re.sub(r"(?is)<script.*?</script>|<style.*?</style>"," ",page)
        txt=re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</tr>|</td>|</th>|</h\d>","\n",txt)
        txt=re.sub(r"(?s)<[^>]+>"," ",txt)
        txt=html.unescape(txt)
        return [" ".join(x.split()) for x in txt.splitlines() if " ".join(x.split())]

    def match_facts(self,match_id):
        """
        Cricbuzz match-info page is authoritative for venue, toss and confirmed XIs.
        This deliberately parses labeled sections only; it never searches generic
        commentary text for a 'venue-like' sentence.
        """
        page=self._text(f"{self.BASE}/cricket-match-facts/{match_id}/match")
        lines=self._plain_lines(page)
        out={"venue":"","toss":"","teams":[],"playing_xi":{},"bench":{},"profiles":{},"raw_lines":lines[:260]}

        # Player-profile links on the verified match page are the safest way to
        # resolve unfamiliar/local-league player identities without web search.
        for href,body in re.findall(r'<a[^>]+href=["\'](/profiles/\d+/[^"\']+)["\'][^>]*>(.*?)</a>',page,re.I|re.S):
            nm=self._clean_cricket_player_name(body)
            if nm and len(nm)<=80:
                out["profiles"][player_key(nm)]={"name":nm,"url":self.BASE+href}

        # exact labeled fields
        for i,ln in enumerate(lines):
            key=ln.strip().lower()
            if key=="toss" and i+1<len(lines):
                out["toss"]=lines[i+1].strip()
            elif key=="venue" and i+1<len(lines):
                cand=lines[i+1].strip()
                if 3<len(cand)<140:
                    out["venue"]=cand

        # fallback header line "Venue: X" only
        if not out["venue"]:
            for ln in lines[:120]:
                mm=re.match(r"^Venue\s*:\s*(.+)$",ln,re.I)
                if mm:
                    out["venue"]=mm.group(1).strip(); break

        # Parse "[Team] squad" -> Players -> Bench blocks.
        i=0
        while i<len(lines):
            mm=re.match(r"^(.+?)\s+squad$",lines[i],re.I)
            if not mm:
                i+=1;continue
            team=mm.group(1).strip()
            out["teams"].append(team)
            players=[]; bench=[]
            mode=None
            j=i+1
            while j<len(lines):
                if re.match(r"^.+?\s+squad$",lines[j],re.I):break
                l=lines[j].strip()
                if l.lower()=="players":
                    mode="players"; j+=1;continue
                if l.lower()=="bench":
                    mode="bench"; j+=1;continue
                if l.lower() in ("featured videos","latest news","apps","follow us","company"):break
                # Player links are rendered as comma-separated names on the current page,
                # but parser also accepts one name per line.
                if mode and l:
                    chunks=[x.strip(" ,") for x in l.split(",") if x.strip(" ,")]
                    for p in chunks:
                        # avoid obvious section labels / metadata
                        if len(p)<2 or len(p)>70:continue
                        if re.search(r"\b(?:match|series|date|time|venue|umpire|referee)\b",p,re.I):continue
                        clean=self._clean_cricket_player_name(p)
                        if clean:
                            (players if mode=="players" else bench).append(clean)
                j+=1
            # de-duplicate preserving order
            players=list(dict.fromkeys(players))[:11]
            bench=list(dict.fromkeys(bench))
            if players: out["playing_xi"][team]=players
            if bench: out["bench"][team]=bench
            i=j
        # Flexible fallback: many Cricbuzz layouts label the confirmed teams as
        # "Playing XI" rather than "Players". Parse team headings + profile links/text.
        for i,ln in enumerate(lines):
            if "playing xi" not in ln.lower():continue
            window=lines[i:min(len(lines),i+90)]
            # collect plausible team names around the heading
            candidate_teams=[]
            for x in window[:20]:
                if re.search(r"\b(?:playing xi|bench|toss|venue|umpire|referee)\b",x,re.I):continue
                if 3<=len(x)<=80 and not re.search(r"\d",x):
                    candidate_teams.append(x.strip())
            # collect player-like names. Profiles already provide strong identity filtering.
            prof_names=[v.get("name","") for v in out.get("profiles",{}).values() if v.get("name")]
            if len(prof_names)>=22 and len(out.get("playing_xi",{}))<2:
                # Only use the first 22 when the page explicitly contains Playing XI.
                # Bench/profile extras later on the page are therefore excluded.
                teams=list(dict.fromkeys(out.get("teams",[])))
                if len(teams)>=2:
                    out["playing_xi"].setdefault(teams[0],prof_names[:11])
                    out["playing_xi"].setdefault(teams[1],prof_names[11:22])
            break
        out["teams"]=list(dict.fromkeys(out["teams"]))
        return out

    def _clean_cricket_player_name(self,name):
        s=html.unescape(re.sub(r"(?s)<[^>]+>"," ",str(name or "")))
        s=" ".join(s.split()).strip(" ,:-")
        s=re.sub(r"\s*\((?:c|wk|c\s*&\s*wk|wk\s*&\s*c|captain|keeper)\)\s*"," ",s,flags=re.I)
        s=re.sub(r"\s+\((?:Impact Player|Substitute)\)\s*$","",s,flags=re.I)
        s=" ".join(s.split()).strip()
        bad={
            "view profile","profile","player profile","career","batting","bowling",
            "recent matches","more","info","information","full profile","details",
            "playing xi","players","bench","squad"
        }
        if s.lower() in bad:return ""
        if re.fullmatch(r"(?:view|see|read|show)\s+(?:profile|details|more)",s,re.I):return ""
        return s

    def _player_name_from_obj(self,obj):
        if not isinstance(obj,dict):return ""
        for k in ("playerName","fullName","name","batName","bowlName","player","shortName"):
            v=obj.get(k)
            if isinstance(v,str):
                nm=self._clean_cricket_player_name(v)
                if 2<=len(nm)<=70 and not re.search(r"\b(?:team|squad|playing xi|bench)\b",nm,re.I):
                    return nm
        return ""

    def _team_name_from_obj(self,obj):
        if not isinstance(obj,dict):return ""
        for k in ("teamName","batTeamName","bowlTeamName","team","name"):
            v=obj.get(k)
            if isinstance(v,str):
                nm=" ".join(v.split()).strip()
                if 2<=len(nm)<=90 and not re.search(r"\b(?:player|venue|match|innings)\b",nm,re.I):
                    return nm
        return ""

    def _recursive_xi_candidates(self,data):
        """Best-effort extraction of full XI arrays from structured Cricbuzz JSON."""
        found=[]
        def walk(node,parent_team="",path=""):
            if isinstance(node,dict):
                team=self._team_name_from_obj(node) or parent_team
                for k,v in node.items():
                    kl=str(k).lower()
                    p2=f"{path}/{kl}"
                    if isinstance(v,list) and any(x in kl for x in ("playing","players","playerdetails","teamplayers","squad","lineup","xi")) and "bench" not in kl:
                        names=[]
                        for item in v:
                            if isinstance(item,str):nm=self._clean_cricket_player_name(item)
                            else:nm=self._player_name_from_obj(item)
                            if nm:names.append(nm)
                        names=list(dict.fromkeys(names))
                        if 7<=len(names)<=15:
                            found.append((team,names,p2))
                    walk(v,team,p2)
            elif isinstance(node,list):
                for i,item in enumerate(node):walk(item,parent_team,f"{path}/{i}")
        walk(data)
        return found

    def resolve_playing_xi(self,facts,scorecard,raw_scorecard=None,expected_match=""):
        """
        Resolve BOTH confirmed XIs from multiple verified Cricbuzz representations.
        Priority: Match Facts confirmed XI -> structured JSON arrays -> scorecard evidence.
        Partial scorecard players are never silently labelled a full XI.
        """
        result={}
        sources={}
        for team,players in (facts.get("playing_xi",{}) or {}).items():
            p=list(dict.fromkeys(self._clean_cricket_player_name(x) for x in players if self._clean_cricket_player_name(x)))
            if len(p)>=11:
                result[team]=p[:11]; sources[team]="CRICBUZZ MATCH FACTS"

        candidates=self._recursive_xi_candidates(raw_scorecard or {})
        candidates+=self._recursive_xi_candidates((scorecard or {}).get("header",{}))
        known_teams=list(dict.fromkeys((facts.get("teams",[]) or []) + [x for inn in (scorecard.get("innings",[]) or []) for x in (inn.get("batting_team",""),inn.get("bowling_team","")) if x]))
        exp=[]
        mm=re.search(r"(.+?)\s+(?:vs\.?|v)\s+(.+?)(?:,|\s+\d+(?:st|nd|rd|th)?\s+match|$)",str(expected_match or ""),re.I)
        if mm:exp=[mm.group(1).strip(),mm.group(2).strip()]
        for team,names,path in candidates:
            if len(names)<11:continue
            target=team
            if target and known_teams:
                best=max(known_teams,key=lambda t:difflib.SequenceMatcher(None,player_key(target),player_key(t)).ratio())
                if difflib.SequenceMatcher(None,player_key(target),player_key(best)).ratio()>=.45:target=best
            if not target and len(known_teams)==1:target=known_teams[0]
            if target and target not in result:
                result[target]=names[:11];sources[target]="CRICBUZZ STRUCTURED LINEUP"

        # Scorecard rows are valuable evidence. Only promote to full XI if 11 distinct
        # names are actually present for a side; otherwise keep them as partial evidence.
        partial={}
        for inn in scorecard.get("innings",[]) or []:
            bt=inn.get("batting_team",""); ot=inn.get("bowling_team","")
            bnames=list(dict.fromkeys(x.get("name","") for x in inn.get("batsmen",[]) if x.get("name")))
            onames=list(dict.fromkeys(x.get("name","") for x in inn.get("bowlers",[]) if x.get("name")))
            if bt:partial.setdefault(bt,[]);partial[bt]=list(dict.fromkeys(partial[bt]+bnames))
            if ot:partial.setdefault(ot,[]);partial[ot]=list(dict.fromkeys(partial[ot]+onames))
        for team,names in partial.items():
            if len(names)>=11 and team not in result:
                result[team]=names[:11];sources[team]="CRICBUZZ SCORECARD FULL XI"
        return {"xi":result,"sources":sources,"partial":partial}

    def search_player_profile(self,name):
        """Resolve a missing XI player's Cricbuzz profile directly by name."""
        q=urllib.parse.quote(str(name or "").strip())
        if not q:return ""
        urls=[f"{self.BASE}/search?q={q}",f"{self.BASE}/search?search={q}"]
        best="";best_score=0
        for url in urls:
            try:page=self._text(url)
            except Exception:continue
            for href,body in re.findall(r'<a[^>]+href=["\'](/profiles/\d+/[^"\']+)["\'][^>]*>(.*?)</a>',page,re.I|re.S):
                nm=self._clean_cricket_player_name(body)
                slug_name=href.rsplit("/",1)[-1].replace("-"," ")
                score=identity_score(name,nm if nm else slug_name)
                if score>best_score:
                    best_score=score;best=self.BASE+href
            if best_score>=.88:break
        return best if best_score>=.68 else ""

    def _short_format_name(self,s):
        u=str(s or "").strip().upper()
        return u in ("T20","T20I","100","100B","HUNDRED") or "HUNDRED" in u

    def _parse_player_all_matches_batting(self,page):
        lines=self._plain_lines(page)
        rows=[]
        for i,ln in enumerate(lines):
            m=re.fullmatch(r"(\d+)(\*)?\((\d+)\)",ln.strip())
            if not m or i+7>=len(lines):continue
            opp=lines[i+1].strip(); fmt=lines[i+2].strip(); venue=lines[i+3].strip(); dt=lines[i+4].strip()
            if not self._short_format_name(fmt):continue
            try:
                sr=float(lines[i+5]); fours=int(float(lines[i+6])); sixes=int(float(lines[i+7]))
            except Exception:continue
            rows.append({"runs":int(m.group(1)),"not_out":bool(m.group(2)),"balls":int(m.group(3)),
                         "opponent":opp,"format":fmt,"venue":venue,"date":dt,
                         "sr":sr,"fours":fours,"sixes":sixes})
        # Fallback for pages rendered with one entire table row per line.
        if not rows:
            for ln in lines:
                m=re.match(r"^(\d+)(\*)?\((\d+)\)\s+(.+?)\s+(T20I?|100|100B)\s+(.+?)\s+(\d{1,2}\s+[A-Za-z]{3}\s+\d{2})\s+([\d.]+)\s+(\d+)\s+(\d+)$",ln,re.I)
                if m:
                    rows.append({"runs":int(m.group(1)),"not_out":bool(m.group(2)),"balls":int(m.group(3)),
                                 "opponent":m.group(4),"format":m.group(5),"venue":m.group(6),"date":m.group(7),
                                 "sr":float(m.group(8)),"fours":int(m.group(9)),"sixes":int(m.group(10))})
        return rows

    def _parse_player_all_matches_bowling(self,page):
        lines=self._plain_lines(page)
        rows=[]
        for i,ln in enumerate(lines):
            m=re.fullmatch(r"(\d+)-(\d+)",ln.strip())
            if not m or i+7>=len(lines):continue
            opp=lines[i+1].strip(); fmt=lines[i+2].strip(); venue=lines[i+3].strip(); dt=lines[i+4].strip()
            if not self._short_format_name(fmt):continue
            try:
                econ=float(lines[i+5]); overs=float(lines[i+6]); maidens=int(float(lines[i+7]))
            except Exception:continue
            rows.append({"wickets":int(m.group(1)),"runs":int(m.group(2)),"opponent":opp,"format":fmt,
                         "venue":venue,"date":dt,"econ":econ,"overs":overs,"maidens":maidens})
        if not rows:
            for ln in lines:
                m=re.match(r"^(\d+)-(\d+)\s+(.+?)\s+(T20I?|100|100B)\s+(.+?)\s+(\d{1,2}\s+[A-Za-z]{3}\s+\d{2})\s+([\d.]+)\s+([\d.]+)\s+(\d+)$",ln,re.I)
                if m:
                    rows.append({"wickets":int(m.group(1)),"runs":int(m.group(2)),"opponent":m.group(3),
                                 "format":m.group(4),"venue":m.group(5),"date":m.group(6),"econ":float(m.group(7)),
                                 "overs":float(m.group(8)),"maidens":int(m.group(9))})
        return rows

    def player_online_history(self,profile_url):
        base=str(profile_url or "").split("/all-matches/")[0].rstrip("/")
        if not re.search(r"/profiles/\d+/",base):
            raise RuntimeError("Invalid Cricbuzz player profile URL")
        profile_page=self._text(base)
        profile_lines=self._plain_lines(profile_page)
        name=""
        role=""
        for i,ln in enumerate(profile_lines[:180]):
            if i<120 and not name and ln and ln.lower() not in ("menu","matches"):
                # Profile heading is generally the first plausible human name near the profile body.
                if re.fullmatch(r"[A-Za-z][A-Za-z .'-]{2,60}",ln) and ln.lower() not in ("personal information","batting form","bowling form"):
                    if i>20:name=ln
            if ln.strip().lower()=="role" and i+1<len(profile_lines):
                role=profile_lines[i+1].strip()
        bat_page=self._text(base+"/all-matches/batting")
        bowl_page=self._text(base+"/all-matches/bowling")
        batting=self._parse_player_all_matches_batting(bat_page)
        bowling=self._parse_player_all_matches_bowling(bowl_page)
        return {"name":name,"role":role,"profile_url":base,"source":"CRICBUZZ PUBLIC PROFILE",
                "fetched_at":time.time(),"batting":batting,"bowling":bowling}

    def scorecard_raw(self,match_id):
        page=self._text(f"{self.BASE}/live-cricket-scorecard/{match_id}")
        return self._embedded_json(page,"scorecardApiData")

    def commentary_raw(self,match_id,innings_id):
        # Current public mcenter endpoint used by active open-source implementation.
        return self._json(f"{self.BASE}/api/mcenter/{match_id}/full-commentary/{innings_id}")

    def health(self):
        result={}
        for name,url in [
            ("Cricbuzz home",self.BASE+"/"),
            ("Cricbuzz live page",self.BASE+"/cricket-match/live-scores")
        ]:
            try:
                txt=self._text(url)
                result[name]={"ok":True,"bytes":len(txt)}
            except Exception as e:
                result[name]={"ok":False,"error":str(e)}
        return result

    def parse_scorecard(self,data):
        if not isinstance(data,dict):return {}
        cards=data.get("scoreCard",[]) or []
        header=data.get("matchHeader",{}) or {}
        out={"header":header,"innings":[],"playing_eleven":{}}
        for inn in cards:
            if not isinstance(inn,dict):continue
            iid=inn.get("inningsId")
            sd=inn.get("scoreDetails",{}) or {}
            bat=inn.get("batTeamDetails",{}) or {}
            bowl=inn.get("bowlTeamDetails",{}) or {}
            bats=bat.get("batsmenData",{}) or {}
            bowlers=bowl.get("bowlersData",{}) or {}
            bat_rows=[]
            extras=inn.get("extrasData",{}) or {}
            partnerships=inn.get("partnershipsData",{}) or inn.get("partnershipData",{}) or {}
            for _,b in bats.items():
                if not isinstance(b,dict):continue
                bat_rows.append({
                    "id":b.get("batId") or b.get("id"),
                    "name":b.get("batName",""),
                    "runs":b.get("runs",0) or 0,
                    "balls":b.get("balls",0) or 0,
                    "fours":b.get("fours",0) or 0,
                    "sixes":b.get("sixes",0) or 0,
                    "dismissal":b.get("outDesc",""),
                    "strike_rate":b.get("strikeRate",0) or safe_div((b.get("runs",0) or 0)*100,(b.get("balls",0) or 0),0)
                })
            bowl_rows=[]
            for _,bw in bowlers.items():
                if not isinstance(bw,dict):continue
                bowl_rows.append({
                    "id":bw.get("bowlerId") or bw.get("bowlId") or bw.get("id"),
                    "name":bw.get("bowlName",""),
                    "overs":bw.get("overs",0) or 0,
                    "runs":bw.get("runs",0) or 0,
                    "wickets":bw.get("wickets",0) or 0,
                    "economy":bw.get("economy",0) or 0,
                    "maidens":bw.get("maidens",0) or 0,
                    "dots":bw.get("dots",0) or bw.get("dotBalls",0) or 0,
                    "wides":bw.get("wides",0) or 0,
                    "noballs":bw.get("noBalls",0) or 0,
                })
            team=bat.get("batTeamName","")
            players=[x["name"] for x in bat_rows if x["name"]]
            if team and players:
                out["playing_eleven"][team]=players
            out["innings"].append({
                "inningsId":iid,
                "batting_team":team,
                "bowling_team":bowl.get("bowlTeamName",""),
                "runs":sd.get("runs",0) or 0,
                "wickets":sd.get("wickets",0) or 0,
                "overs":sd.get("overs",0) or 0,
                "batsmen":bat_rows,
                "bowlers":bowl_rows,
                "extras":{
                    "total":extras.get("total",extras.get("totalExtras",0)) or 0,
                    "wides":extras.get("wides",0) or 0,
                    "noballs":extras.get("noBalls",extras.get("noballs",0)) or 0,
                    "byes":extras.get("byes",0) or 0,
                    "legbyes":extras.get("legByes",extras.get("legbyes",0)) or 0,
                    "penalty":extras.get("penalty",0) or 0,
                },
                "partnerships":partnerships
            })
        return out

    def parse_commentary(self,raw):
        entries=[]
        try:
            blocks=raw.get("commentary",[]) or []
            lst=blocks[0].get("commentaryList",[]) if blocks and isinstance(blocks[0],dict) else []
            for e in lst:
                if not isinstance(e,dict):continue
                ob=e.get("overNumber")
                if ob is None:continue
                bs=e.get("batsmanStriker",{}) or {}
                bn=e.get("batsmanNonStriker",{}) or e.get("batsmanNonStrikerDetails",{}) or {}
                bw=e.get("bowlerStriker",{}) or {}
                _runs=e.get("totalRuns",0) or 0
                _event=str(e.get("event","NONE") or "NONE").upper()
                _comment=e.get("commText","") or e.get("commentary","") or e.get("text","") or ""
                _ct=" ".join(str(_comment).lower().split())
                _wide=e.get("wides",0) or 0
                _nb=e.get("noBalls",0) or 0

                # Some Cricbuzz commentary payloads omit explicit extras fields even
                # though the text clearly says wide/no-ball. Recover them from text.
                if not _wide:
                    _wm=re.search(r"\b(\d+)\s+wides?\b",_ct)
                    if _wm:
                        _wide=int(_wm.group(1))
                    elif re.search(r"\bwide\b|\bwides\b|\bwd\b",_ct):
                        _wide=max(1,int(_runs or 1))
                if not _nb and re.search(r"\bno[- ]?ball\b|\bnb\b",_ct):
                    _nb=1

                _wicket=_event in ("WICKET","OUT") or "WICKET" in _event
                _boundary=_event in ("FOUR","SIX") or (_runs in (4,6) and _event in ("FOUR","SIX"))
                if _wicket:
                    _token="W"
                elif _wide:
                    _token=(f"{int(_wide)}WD" if int(_wide)>1 else "WD")
                elif _nb:
                    # No-ball may include bat runs; keep total event runs visible.
                    _token=("NB" if int(_runs)<=1 else f"NB+{int(_runs)}")
                elif _event=="SIX":
                    _token="6"
                elif _event=="FOUR":
                    _token="4"
                else:
                    _token=str(_runs)
                entries.append({
                    "over_ball":ob,
                    "ball":ob,
                    "innings_id":e.get("inningsId"),
                    "runs":_runs,
                    "event":_event,
                    "token":_token,
                    "wicket":_wicket,
                    "boundary":_boundary,
                    "dot":(_runs==0 and not _wicket and not _wide and not _nb),
                    "verified_outcome":True,
                    "structured_verified":True,
                    "source":"CRICBUZZ STRUCTURED",
                    "comment":_comment,
                    "team_score":e.get("batTeamScore",0),
                    "wides":_wide,
                    "noballs":_nb,
                    "legal_delivery":not bool(_wide or _nb),
                    "extra_delivery":bool(_wide or _nb),
                    "extra_runs":int(_wide or 0)+int(_nb or 0),
                    "batter":bs.get("batName",""),
                    "bowler_name":bw.get("bowlName",""),
                    "striker":{
                        "name":bs.get("batName",""),
                        "runs":bs.get("batRuns",0) or 0,
                        "balls":bs.get("batBalls",0) or 0,
                        "fours":bs.get("batFours",0) or 0,
                        "sixes":bs.get("batSixes",0) or 0,
                    },
                    "non_striker":{
                        "name":bn.get("batName","") or bn.get("playerName",""),
                        "runs":bn.get("batRuns",0) or 0,
                        "balls":bn.get("batBalls",0) or 0,
                    },
                    "bowler":{
                        "name":bw.get("bowlName",""),
                        "overs":bw.get("bowlOvs",0) or 0,
                        "runs":bw.get("bowlRuns",0) or 0,
                        "wickets":bw.get("bowlWkts",0) or 0,
                    }
                })
            entries.reverse()
        except Exception:
            pass
        return entries

class NoKeyLiveClient:
    """
    No-key unofficial live source.
    Uses the open-source cricbuzz-live public service documented at:
      /v1/matches/live?type=...
      /v1/score/{matchId}
    No API key is required.
    """
    BASE="https://cricbuzz-live.vercel.app"

    def _get_url(self,url):
        req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 CricketProAI/1.0"})
        with urllib.request.urlopen(req,timeout=20) as r:
            return json.loads(r.read().decode("utf-8"))

    def live_matches(self):
        all_matches=[]
        seen=set()
        raw=[]
        # Query all documented categories so league/domestic/women matches are not missed.
        for typ in ("international","league","domestic","women"):
            try:
                url=f"{self.BASE}/v1/matches/live?"+urllib.parse.urlencode({"type":typ})
                payload=self._get_url(url)
                raw.append({"type":typ,"payload":payload})
                data=payload.get("data",{}) if isinstance(payload,dict) else {}
                matches=data.get("matches",[]) if isinstance(data,dict) else []
                if isinstance(matches,dict): matches=[matches]
                for m in matches or []:
                    if not isinstance(m,dict): continue
                    mid=str(m.get("id") or "")
                    if not mid or mid in seen: continue
                    seen.add(mid)
                    mm=dict(m)
                    mm["_source"]="NoKey"
                    mm["_type"]=typ
                    all_matches.append(mm)
            except Exception:
                continue
        return {"status":"success","data":all_matches,"raw":raw}

    def score(self, match_id):
        return self._get_url(f"{self.BASE}/v1/score/{urllib.parse.quote(str(match_id))}")

class MultiSourceLive:
    def __init__(self, apikey=""):
        self.apikey=(apikey or "").strip()
        self.nokey=NoKeyLiveClient()
        self.cric=LiveCricketClient(self.apikey) if self.apikey else None

    def live_matches(self, prefer_no_key=True):
        errors=[]
        if prefer_no_key:
            try:
                r=self.nokey.live_matches()
                if r.get("data"):
                    return "No-Key Live",r
            except Exception as e:
                errors.append(f"No-key: {e}")
        if self.cric:
            try:
                r=self.cric.current_matches(offset=0)
                return "CricAPI fallback",r
            except Exception as e:
                errors.append(f"CricAPI: {e}")
        if not prefer_no_key:
            try:
                r=self.nokey.live_matches()
                return "No-Key Live",r
            except Exception as e:
                errors.append(f"No-key: {e}")
        raise RuntimeError("All live sources failed. "+" | ".join(errors))

class LiveCricketClient:
    """CricketData/CricAPI v1 connector using only Python standard library."""
    BASE="https://api.cricapi.com/v1"

    def __init__(self, apikey):
        self.apikey=(apikey or "").strip()

    def _get(self, endpoint, **params):
        if not self.apikey:
            raise ValueError("Enter your CricketData/CricAPI API key first.")
        q={"apikey":self.apikey,"offset":0}
        q.update({k:v for k,v in params.items() if v not in (None,"")})
        url=f"{self.BASE}/{endpoint}?"+urllib.parse.urlencode(q)
        req=urllib.request.Request(url,headers={"User-Agent":"CricketProAI-V6/1.0"})
        with urllib.request.urlopen(req,timeout=20) as r:
            data=json.loads(r.read().decode("utf-8"))
        if isinstance(data,dict):
            status=str(data.get("status","")).lower()
            if status and status not in ("success","ok"):
                reason=data.get("reason") or data.get("message") or data.get("error")
                if reason: raise RuntimeError(str(reason))
        return data

    def current_matches(self, offset=0):
        try:
            return self._get("currentMatches", offset=offset)
        except Exception:
            return self._get("matches", offset=offset)

    def scorecard(self, match_id):
        return self._get("match_scorecard",id=match_id)

    def squad(self, match_id):
        return self._get("match_squad",id=match_id)

def _walk(obj):
    if isinstance(obj,dict):
        yield obj
        for v in obj.values():
            yield from _walk(v)
    elif isinstance(obj,list):
        for x in obj:
            yield from _walk(x)

def _first_value(d, keys, default=None):
    if not isinstance(d,dict): return default
    lower={str(k).lower():v for k,v in d.items()}
    for k in keys:
        if k in d:return d[k]
        if k.lower() in lower:return lower[k.lower()]
    return default


class App:
    def __init__(self,root):
        self.root=root
        self.root.title(APP_TITLE)
        self.root.geometry("1180x860")
        self.root.minsize(1080,780)
        self.db=DB(DB_FILE)
        self.model=Model(self.db)
        self._online_player_cache=self._load_online_player_cache()
        self._online_profile_links={}
        self._online_enrich_busy=False
        self._online_enrich_match_key=""
        self._xi_watch_job=None
        self._xi_watch_started=0.0
        self.model.online_lookup=self._online_rating_lookup
        self.log=[]
        self.live_matches={}
        self.live_snapshots=[]
        self.live_ball_events=[]
        self.live_connected=False
        self.live_refresh_job=None
        self._async_queue=queue.Queue()
        self._crex_fetch_inflight=False
        self._deep_sync_busy=False
        self._prefetched_crex_detail=None
        self._last_prediction_refresh=0.0
        self._last_heavy_ui_refresh=0.0
        self._last_prediction_ball=-1
        self._last_dashboard_ball=-1
        self._cb_commentary_inflight=False
        self._last_cb_commentary_fetch=0.0
        self._advanced_tabs_visible=False
        self._prev_live_score_state=None
        self._inferred_ball_results={}
        self._scoreboard_extra_events=[]
        self._scoreboard_extra_seq=0
        self._current_ball_event=None
        self._confirmed_ball_ledger={}
        self._last_confirmed_ball_by_innings={}
        self._active_match_key=""
        self._active_match_name=""
        self._match_generation=0
        self._cricbuzz_match_key=""
        self._apply_ui_style()
        self.build()
        self.root.after(100,self._poll_async_results)

    def _load_online_player_cache(self):
        try:
            p=Path(ONLINE_PLAYER_CACHE_FILE)
            if p.exists():
                data=json.loads(p.read_text(encoding="utf-8"))
                return data if isinstance(data,dict) else {}
        except Exception:pass
        return {}

    def _save_online_player_cache(self):
        try:
            Path(ONLINE_PLAYER_CACHE_FILE).write_text(
                json.dumps(self._online_player_cache,ensure_ascii=False,indent=2),encoding="utf-8")
        except Exception:pass

    def _online_record(self,player):
        k=player_key(player)
        exact=self._online_player_cache.get(k)
        if exact:return exact
        best=None;bs=0
        for ck,v in self._online_player_cache.items():
            sc=identity_score(player,v.get("name") or ck)
            if sc>bs:bs=sc;best=v
        return best if bs>=0.90 else None

    def _online_short_rows(self,player,kind,fmt,limit=None):
        rec=self._online_record(player)
        if not rec:return []
        rows=list(rec.get("batting" if kind=="bat" else "bowling",[]) or [])
        if fmt=="Hundred":
            preferred=[r for r in rows if "100" in str(r.get("format","")).upper() or "HUNDRED" in str(r.get("format","")).upper()]
            if len(preferred)>=3:rows=preferred
            else:rows=[r for r in rows if str(r.get("format","")).upper() in ("T20","T20I","100","100B") or "HUNDRED" in str(r.get("format","")).upper()]
        else:
            rows=[r for r in rows if str(r.get("format","")).upper() in ("T20","T20I")]
        return rows[:limit] if limit else rows

    def _online_rating_lookup(self,player,fmt,kind):
        rows=self._online_short_rows(player,kind,fmt,10)
        if not rows:return None
        if kind=="bat":
            balls=sum(int(r.get("balls",0) or 0) for r in rows)
            runs=sum(int(r.get("runs",0) or 0) for r in rows)
            fours=sum(int(r.get("fours",0) or 0) for r in rows)
            sixes=sum(int(r.get("sixes",0) or 0) for r in rows)
            outs=sum(0 if r.get("not_out") else 1 for r in rows)
            if balls<=0:return None
            sr=safe_div(runs*100,balls); avg=safe_div(runs,outs,runs)
            bp=safe_div((fours+sixes)*100,balls)
            raw=50+(sr-(135 if fmt=="T20" else 140))*0.16+(avg-22)*0.28+(bp-13)*0.65
            raw=clamp(raw,15,90)
            # Online web sample is useful but deliberately lower confidence than ball-level local DB.
            reliability=min(0.58,len(rows)/10*0.58)
            score=50*(1-reliability)+raw*reliability
            stats={"matches":len(rows),"balls":balls,"runs":runs,"sr":sr,"avg":avg,
                   "boundary_pct":bp,"dot_pct":38.0,"matched_name":self._online_record(player).get("name",player),
                   "source":"ONLINE CRICBUZZ","online":True}
            return round(score,1),stats,reliability
        overs=[];runs=0;wk=0
        for r in rows:
            ov=float(r.get("overs",0) or 0); whole=int(ov); frac=int(round((ov-whole)*10)); b=whole*6+min(frac,5)
            overs.append(b);runs+=int(r.get("runs",0) or 0);wk+=int(r.get("wickets",0) or 0)
        balls=sum(overs)
        if balls<=0:return None
        econ=safe_div(runs*6,balls,99); sr=safe_div(balls,wk,999)
        raw=50+((8.4 if fmt=="T20" else 8.7)-econ)*4.6+(24-min(sr,40))*0.42
        raw=clamp(raw,15,90)
        reliability=min(0.55,len(rows)/10*0.55)
        score=50*(1-reliability)+raw*reliability
        stats={"matches":len(rows),"balls":balls,"runs":runs,"wickets":wk,"econ":econ,"sr":sr,
               "dot_pct":35.0,"boundary_pct":12.0,"matched_name":self._online_record(player).get("name",player),
               "source":"ONLINE CRICBUZZ","online":True}
        return round(score,1),stats,reliability

    def _seed_online_profile_links(self,facts,scorecard):
        for k,v in (facts.get("profiles",{}) or {}).items():
            if isinstance(v,dict) and v.get("url"):
                self._online_profile_links[k]=v
        for inn in (scorecard.get("innings",[]) or []):
            for row in list(inn.get("batsmen",[]) or [])+list(inn.get("bowlers",[]) or []):
                pid=row.get("id"); name=str(row.get("name","") or "").strip()
                if pid and name:
                    slug=re.sub(r"[^a-z0-9]+","-",player_key(name)).strip("-") or "player"
                    self._online_profile_links[player_key(name)]={"name":name,"url":f"https://www.cricbuzz.com/profiles/{pid}/{slug}"}

    def _players_needing_online_enrichment(self):
        # Professional priority: confirmed 22 first. Impact/subs can be enriched later.
        names=[]
        names.extend(self.names(self.bat_xi))
        names.extend(self.names(self.bowl_xi))
        names += [self.striker.get().strip(),self.non_striker.get().strip(),self.current_bowler.get().strip()]
        out=[];seen=set();now=time.time()
        bad={"viewprofile","profile","playerprofile","details","more"}
        for p in names:
            p=norm_name(p)
            k=player_key(p)
            if not k or k in bad or k in seen:continue
            seen.add(k)
            if self.db.player_batting(p,self.format_var.get()) or self.db.player_bowling(p,self.format_var.get()):
                continue
            cached=self._online_record(p)
            if cached and now-float(cached.get("fetched_at",0) or 0)<14*86400:
                continue
            link=self._online_profile_links.get(k)
            if not link:
                best=None;bs=0
                for lk,v in self._online_profile_links.items():
                    sc=identity_score(p,v.get("name") or lk)
                    if sc>bs:bs=sc;best=v
                link=best if bs>=0.90 else None
            out.append((p,link.get("url") if link else ""))
        return out[:22]

    def _online_enrich_worker(self,targets,match_key,generation):
        results=[];errors=[]
        c=DirectCricbuzzClient()
        for p,url in targets:
            try:
                if not url:
                    url=c.search_player_profile(p)
                if not url:
                    raise RuntimeError("Cricbuzz profile not found by name")
                rec=c.player_online_history(url)
                rec["name"]=rec.get("name") or p
                rec["requested_name"]=p
                results.append((p,rec))
            except Exception as e:
                errors.append((p,str(e)))
        self._async_queue.put(("online_enrich",{"results":results,"errors":errors,
                                                "match_key":match_key,"generation":generation}))

    def start_online_player_enrichment(self,force=False):
        if self._online_enrich_busy:return
        targets=self._players_needing_online_enrichment()
        if not targets:
            try:self.player_online_status.set("Online enrichment: no missing linked players to fetch.")
            except Exception:pass
            return
        self._online_enrich_busy=True
        self._online_enrich_match_key=self._active_match_key
        try:self.player_online_status.set(f"Online enrichment: fetching {len(targets)} missing player profile(s) in background…")
        except Exception:pass
        threading.Thread(target=self._online_enrich_worker,
                         args=(targets,self._active_match_key,self._match_generation),daemon=True).start()

    def _apply_ui_style(self):
        try:
            style=ttk.Style()
            if "vista" in style.theme_names():
                style.theme_use("vista")
            style.configure("TNotebook.Tab",padding=(14,8),font=("Arial",10,"bold"))
            style.configure("TLabelframe.Label",font=("Arial",11,"bold"))
            style.configure("TButton",padding=(10,6),font=("Arial",9,"bold"))
            style.configure("TLabel",font=("Arial",10))
        except Exception:
            pass

    def build(self):
        nb=ttk.Notebook(self.root)
        self.nb=nb
        nb.pack(fill="both",expand=True,padx=8,pady=8)
        self.tab_home=ttk.Frame(nb,padding=14)
        self.tab_data=ttk.Frame(nb,padding=10)
        self.tab_live=ttk.Frame(nb,padding=10)
        self.tab_match=ttk.Frame(nb,padding=10)
        self.tab_live_center=ttk.Frame(nb,padding=8)
        self.tab_players=ttk.Frame(nb,padding=10)
        self.tab_coach=ttk.Frame(nb,padding=10)
        self.tab_xi=ttk.Frame(nb,padding=10)
        self.tab_technical=ttk.Frame(nb,padding=10)
        self.tab_compare=ttk.Frame(nb,padding=10)
        self.tab_trend=ttk.Frame(nb,padding=10)
        self.tab_squad=ttk.Frame(nb,padding=10)
        self.tab_advanced=ttk.Frame(nb,padding=10)
        self.tab_player_intel=ttk.Frame(nb,padding=10)
        self.tab_market=ttk.Frame(nb,padding=10)
        self.tab_possibility=ttk.Frame(nb,padding=10)
        nb.add(self.tab_home,text="HOME")
        nb.add(self.tab_live,text="LIVE SETUP")
        nb.add(self.tab_live_center,text="LIVE CENTER")
        nb.add(self.tab_match,text="PREDICTION")
        nb.add(self.tab_advanced,text="ANALYSIS")
        nb.add(self.tab_player_intel,text="PLAYERS")
        nb.add(self.tab_market,text="EXCHANGE")
        nb.add(self.tab_possibility,text="POSSIBILITIES")
        # Advanced/maintenance tabs are created but hidden by default.
        nb.add(self.tab_data,text="Data")
        nb.add(self.tab_technical,text="Technical")
        nb.add(self.tab_compare,text="Comparison")
        nb.add(self.tab_trend,text="Trend")
        nb.add(self.tab_coach,text="Coach")
        nb.add(self.tab_squad,text="Squad")
        nb.add(self.tab_xi,text="XI Report")
        nb.add(self.tab_players,text="Lookup")
        self.build_home()
        self.build_data()
        self.build_live_source()
        self.build_live_center()
        self.build_match()
        self.build_technical_analysis()
        self.build_advanced_analyst()
        self.build_team_comparison()
        self.build_match_trend()
        self.build_coach()
        self.build_squad_intelligence()
        self.build_player_intelligence()
        self.build_xi_report()
        self.build_market_intelligence()
        self.build_possibilities()
        self.build_players()
        self._set_advanced_tabs(False)

    def build_possibilities(self):
        top=ttk.Frame(self.tab_possibility);top.pack(fill="x")
        ttk.Label(top,text="Custom Fancy Probability Analyzer",
                  font=("Arial",20,"bold")).pack(side="left",pady=8)
        ttk.Button(top,text="REFRESH MATCH MODEL",command=self.refresh_possibilities).pack(side="right",padx=6)

        ttk.Label(self.tab_possibility,
                  text="Enter any fancy line from the live market. The app compares it with the current match model and explains the probability.",
                  font=("Arial",10)).pack(anchor="w",pady=(0,8))

        form=ttk.LabelFrame(self.tab_possibility,text="CUSTOM FANCY INPUT",padding=10)
        form.pack(fill="x",pady=6)

        self.fancy_type=tk.StringVar(value="Checkpoint Team Score")
        self.fancy_horizon=tk.StringVar(value="10 Overs")
        self.fancy_line=tk.StringVar(value="80")
        self.fancy_side=tk.StringVar(value="Over / Yes")
        self.fancy_note=tk.StringVar(value="")

        ttk.Label(form,text="Fancy type").grid(row=0,column=0,sticky="w",padx=4,pady=3)
        ttk.Combobox(form,textvariable=self.fancy_type,state="readonly",width=28,values=[
            "Checkpoint Team Score",
            "Next Over Runs",
            "Next 2 Overs Runs",
            "Next 6 Legal Balls Runs",
            "Next 12 Legal Balls Runs",
            "Team Wickets by Checkpoint",
            "Boundaries by Checkpoint",
            "Boundaries Next 6 Balls",
            "Boundaries Next 12 Balls",
            "Current Partnership Runs",
            "Batter Runs"
        ]).grid(row=1,column=0,sticky="ew",padx=4)

        ttk.Label(form,text="Horizon / checkpoint").grid(row=0,column=1,sticky="w",padx=4,pady=3)
        ttk.Combobox(form,textvariable=self.fancy_horizon,width=22,values=[
            "6 Overs","10 Overs","15 Overs","20 Overs",
            "Next 1 Over","Next 2 Overs","Next 6 Balls","Next 12 Balls"
        ]).grid(row=1,column=1,sticky="ew",padx=4)

        ttk.Label(form,text="Fancy line").grid(row=0,column=2,sticky="w",padx=4,pady=3)
        ttk.Entry(form,textvariable=self.fancy_line,width=12).grid(row=1,column=2,sticky="ew",padx=4)

        ttk.Label(form,text="Market side").grid(row=0,column=3,sticky="w",padx=4,pady=3)
        ttk.Combobox(form,textvariable=self.fancy_side,state="readonly",width=16,
                     values=["Over / Yes","Under / No"]).grid(row=1,column=3,sticky="ew",padx=4)

        ttk.Button(form,text="ANALYZE THIS FANCY",command=self.analyze_custom_fancy).grid(row=1,column=4,padx=8)
        ttk.Button(form,text="ADD TO COMPARISON",command=self.add_fancy_to_comparison).grid(row=1,column=5,padx=4)
        ttk.Button(form,text="CLEAR COMPARISON",command=self.clear_fancy_comparison).grid(row=1,column=6,padx=4)

        for c in range(7): form.columnconfigure(c,weight=1 if c in (0,1) else 0)

        self.fancy_result=tk.Text(self.tab_possibility,height=12,font=("Consolas",10),wrap="word")
        self.fancy_result.pack(fill="x",pady=6)

        ttk.Separator(self.tab_possibility,orient="horizontal").pack(fill="x",pady=4)
        self.poss_status=tk.StringVar(value="Connect a live match, then enter a fancy line.")
        ttk.Label(self.tab_possibility,textvariable=self.poss_status,font=("Arial",10,"bold")).pack(anchor="w")

        self.fancy_compare=[]
        self.fancy_compare_out=tk.Text(self.tab_possibility,height=12,font=("Consolas",10),wrap="word")
        self.fancy_compare_out.pack(fill="both",expand=True,pady=6)

        # Retain the automatic checkpoint report below custom analysis.
        self.poss_out=tk.Text(self.tab_possibility,height=14,font=("Consolas",9),wrap="word")
        self.poss_out.pack(fill="both",expand=True,pady=6)


    @staticmethod
    def _normal_cdf(x,mu,sd):
        if sd<=0:return 1.0 if x>=mu else 0.0
        return 0.5*(1.0+math.erf((x-mu)/(sd*math.sqrt(2))))

    def _checkpoint_probability(self,current_score,current_balls,checkpoint_balls,projected_final,total_balls,wkts,line):
        """Probability of reaching >= line by checkpoint, conservative normal approximation."""
        if checkpoint_balls<=current_balls:
            return 100.0 if current_score>=line else 0.0
        rem_to=checkpoint_balls-current_balls
        rem_all=max(1,total_balls-current_balls)
        future_total=max(0.0,projected_final-current_score)
        mu=current_score+future_total*(rem_to/rem_all)
        # uncertainty falls as more of the innings is observed; wickets widen downside risk
        frac=rem_to/max(1,total_balls)
        sd=max(4.0,math.sqrt(rem_to)*1.45*(1.0+wkts*0.025)*(0.85+frac))
        p=(1.0-self._normal_cdf(line-0.5,mu,sd))*100
        return clamp(p,1,99)

    def _fancy_checkpoint_balls(self,horizon,fmt):
        h=str(horizon or "").lower()
        if fmt=="Hundred":
            m=re.search(r"(\d+)\s*balls?",h)
            if m:return int(m.group(1))
        m=re.search(r"(\d+)\s*overs?",h)
        if m:return int(m.group(1))*6
        m=re.search(r"(\d+)\s*balls?",h)
        if m:return int(m.group(1))
        if "next 2" in h:return self._live_int(self.balls)+12
        if "next 1" in h:return self._live_int(self.balls)+6
        return None

    def _safe_widget_text(self,widget):
        try:return widget.get("1.0","end").strip()
        except Exception:return ""

    def _refresh_fancy_evidence_sources(self):
        """
        Manual fancy analysis is allowed to refresh the analyst modules because
        the user explicitly requested a full assessment. Errors in one module do
        not block the others.
        """
        self._hydrate_live_matchup_from_sources()
        refreshers=[
            self.refresh_technical_analysis,
            self.refresh_advanced_analyst,
            self.refresh_team_comparison,
            self.refresh_match_trend,
            self.refresh_player_intelligence,
            self.refresh_squad_intelligence,
        ]
        for fn in refreshers:
            try:fn()
            except Exception:pass
        # Coach report also updates the live prediction snapshot. It is now
        # tolerant of partial matchup data in V17+.
        try:self.coach_report()
        except Exception:pass

    def _text_sentiment(self,text):
        """
        Convert analyst prose to a very small bounded directional signal.
        This is NOT used alone; it only acts as one vote in the ensemble.
        """
        t=(" "+str(text or "").lower()+" ")
        pos=[
            "above par","well above","strong","excellent","positive","rising",
            "accelerating","high threat","dangerous","healthy","advantage",
            "favourable","favorable","good wickets in hand","hot","ahead of"
        ]
        neg=[
            "below par","well below","weak","negative","falling","under pressure",
            "fragile","targetable","disadvantage","poor","low threat","behind",
            "collapse","wicket pressure"
        ]
        score=sum(t.count(x) for x in pos)-sum(t.count(x) for x in neg)
        return clamp(score,-4,4)

    def _integrated_fancy_evidence(self,projected=None):
        fmt=self.format_var.get()
        s=self._live_int(self.score); w=self._live_int(self.wkts); b=self._live_int(self.balls)
        total=self._effective_total_balls(fmt)
        venue=self.venue.get().strip()
        bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
        v=self.db.venue_stats(venue,fmt)
        bp=self.model.xi_profile(bx,fmt) if bx else {"batting":50,"coverage":0}
        op=self.model.xi_profile(ox,fmt) if ox else {"bowling":50,"coverage":0}

        # Live recent windows.
        deliveries=getattr(self,"_latest_deliveries",[]) or []
        l6,l12=self._recent_ball_metrics(deliveries)
        r6=float(l6.get("runs",0) or 0) if l6 else 0.0
        r12=float(l12.get("runs",0) or 0) if l12 else 0.0
        l6n=max(1,int(l6.get("legal",0) or 0)) if l6 else 1
        l12n=max(1,int(l12.get("legal",0) or 0)) if l12 else 1
        recent_rpb=(0.6*(r6/l6n)+0.4*(r12/l12n)) if (l6 or l12) else safe_div(s,b,1.0)
        innings_rpb=safe_div(s,b,1.0)

        # Venue/team capacity.
        scheduled=100 if fmt=="Hundred" else 120
        scale=total/max(1,scheduled)
        venue_par=float(v["avg"])*scale
        capacity_par=venue_par+(bp["batting"]-op["bowling"])*0.42*scale
        expected_now=capacity_par*b/max(1,total)
        tempo=s-expected_now

        # Current matchup strength.
        striker=self.striker.get().strip()
        non=self.non_striker.get().strip()
        bowler=self.current_bowler.get().strip()
        sr=self.model.batter_score(striker,fmt) if striker and "unknown" not in striker.lower() else None
        nr=self.model.batter_score(non,fmt) if non and "unknown" not in non.lower() else None
        br=self.model.bowler_score(bowler,fmt) if bowler and "unknown" not in bowler.lower() else None
        batting_matchup=statistics.mean([x[0] for x in (sr,nr) if x]) if any((sr,nr)) else 50.0
        bowling_matchup=br[0] if br else 50.0

        # Phase.
        pp=self._effective_pp_balls(fmt)
        death=int(total*0.80)
        phase="POWERPLAY" if b<=pp else "DEATH" if b>=death else "MIDDLE"

        # Pull the actual reports generated by other tabs.
        texts={
            "technical":self._safe_widget_text(getattr(self,"technical_out",None)),
            "advanced":self._safe_widget_text(getattr(self,"advanced_out",None)),
            "comparison":self._safe_widget_text(getattr(self,"compare_out",None)),
            "trend":self._safe_widget_text(getattr(self,"trend_out",None)),
            "coach":self._safe_widget_text(getattr(self,"coach_out",None)),
            "players":self._safe_widget_text(getattr(self,"player_intel_out",None)),
            "squad":self._safe_widget_text(getattr(self,"squad_out",None)),
        }
        sentiments={k:self._text_sentiment(vv) for k,vv in texts.items()}

        # Detailed remaining resources and live pressure.
        resources=self._remaining_resource_matrix(fmt)
        pressure=self._pressure_momentum_matrix(fmt,s,w,b,total)

        # Reliability: historical coverage + live evidence + matchup availability.
        xi_cov=(float(bp.get("coverage",0))+float(op.get("coverage",0)))/2
        live_cov=min(100.0,b/max(1,total)*100*1.6)
        matchup_cov=(25 if sr else 0)+(20 if nr else 0)+(25 if br else 0)
        structured_cov=30 if getattr(self,"latest_scorecard",None) else 0
        quality=clamp(0.42*xi_cov+0.28*live_cov+0.18*matchup_cov+0.12*structured_cov,8,100)

        return {
            "score":s,"wkts":w,"balls":b,"total":total,"phase":phase,
            "venue_par":venue_par,"capacity_par":capacity_par,"expected_now":expected_now,
            "tempo":tempo,"innings_rpb":innings_rpb,"recent_rpb":recent_rpb,
            "batting_xi":bp["batting"],"bowling_xi":op["bowling"],"xi_coverage":xi_cov,
            "batting_matchup":batting_matchup,"bowling_matchup":bowling_matchup,
            "striker":striker,"non":non,"bowler":bowler,
            "quality":quality,"texts":texts,"sentiments":sentiments,
            "resources":resources,"pressure":pressure,
            "projected":projected
        }

    def _fancy_ensemble_adjust(self,p_raw,r,evidence):
        """
        Blend the mathematical line probability with independent analyst votes.
        Low-quality data automatically shrinks the answer toward 50%.
        """
        p0=clamp(float(p_raw),1,99)
        side_over=str(r.get("side","")).lower().startswith("over")

        votes=[]
        # 1. Base line model vote. It is deliberately not dominant.
        votes.append(("Resource-calibrated line model",p0,0.78))

        # 2. Tempo vs team-capacity par.
        tempo=float(evidence["tempo"])
        tempo_p=50+clamp(tempo*2.0,-28,28)
        if not side_over:tempo_p=100-tempo_p
        votes.append(("Venue/team-capacity par",tempo_p,0.85))

        # 3. Recent momentum vs innings pace.
        diff=(evidence["recent_rpb"]-evidence["innings_rpb"])*18
        mom_p=50+clamp(diff,-24,24)
        if not side_over:mom_p=100-mom_p
        votes.append(("Recent 6/12-ball momentum",mom_p,0.80))

        # 4. Remaining wickets / batting resources.
        wh=max(0,10-evidence["wkts"])
        resource_p={10:66,9:64,8:62,7:60,6:57,5:53,4:48,3:42,2:35,1:27,0:5}.get(wh,42)
        if not side_over:resource_p=100-resource_p
        votes.append(("Wickets / batting resources",resource_p,0.92))

        # Remaining personnel quality: yet-to-bat against bowlers still available.
        res=evidence.get("resources",{})
        personnel_edge=float(res.get("remaining_bat_rating",50))-(
            0.55*float(res.get("future_bowl_rating",50))+0.45*float(res.get("future_control",50))
        )
        personnel_p=50+clamp(personnel_edge*0.55,-24,24)
        if not side_over:personnel_p=100-personnel_p
        votes.append(("Remaining personnel quality",personnel_p,0.95))

        # Pressure / momentum vote.
        pm=evidence.get("pressure",{})
        pm_p=50+clamp((float(pm.get("momentum",50))-float(pm.get("pressure",50)))*0.42,-24,24)
        if not side_over:pm_p=100-pm_p
        votes.append(("Pressure / momentum state",pm_p,0.90))

        # 7. XI batting-v-bowling edge.
        xi_edge=(evidence["batting_xi"]-evidence["bowling_xi"])*0.55
        xi_p=50+clamp(xi_edge,-22,22)
        if not side_over:xi_p=100-xi_p
        votes.append(("XI strength matchup",xi_p,0.65))

        # 5. Current batter/bowler matchup.
        matchup_edge=(evidence["batting_matchup"]-evidence["bowling_matchup"])*0.45
        matchup_p=50+clamp(matchup_edge,-20,20)
        if not side_over:matchup_p=100-matchup_p
        votes.append(("Current player matchup",matchup_p,0.60))

        # 6. Analyst-tab consensus.
        sent=sum(evidence["sentiments"].values())
        analyst_p=50+clamp(sent*2.5,-20,20)
        if not side_over:analyst_p=100-analyst_p
        votes.append(("Coach/technical/trend consensus",analyst_p,0.70))

        weighted=sum(p*w for _,p,w in votes)/sum(w for _,_,w in votes)

        # Count agreement with selected side.
        agree=sum(1 for _,p,_ in votes if p>=55)
        oppose=sum(1 for _,p,_ in votes if p<=45)
        neutral=len(votes)-agree-oppose
        conflict=min(1.0,oppose/max(1,len(votes)))

        # Data quality shrink + conflict penalty.
        q=evidence["quality"]/100.0
        shrink=0.30+0.70*q
        adjusted=50+(weighted-50)*shrink
        adjusted=50+(adjusted-50)*(1-0.35*conflict)

        # Never advertise extreme confidence from weak evidence.
        max_dev=12+38*q
        adjusted=clamp(adjusted,50-max_dev,50+max_dev)

        return clamp(adjusted,1,99),votes,agree,oppose,neutral

    def _resource_run_factor(self,wkts_in_hand):
        """
        Remaining batting resource multiplier.
        10 wickets in hand ~= full freedom; 3 wickets in hand materially constrains
        sustainable acceleration.
        """
        table={10:1.08,9:1.06,8:1.04,7:1.02,6:1.00,5:0.96,4:0.90,3:0.82,2:0.70,1:0.56,0:0.0}
        return table.get(max(0,min(10,int(wkts_in_hand))),0.82)

    def _phase_run_factor(self,balls,total,fmt):
        pp=self._effective_pp_balls(fmt)
        if balls<pp:return 1.04
        if balls>=int(total*0.80):return 1.12
        return 0.98

    def _overs_to_legal_balls_simple(self,overs):
        try:
            s=str(overs or "0")
            if "." in s:
                a,b=s.split(".",1)
                return int(a)*6+int(re.sub(r"\D","",b)[:1] or 0)
            return int(float(s))*6
        except Exception:
            return 0

    def _live_bowler_delivery_stats(self):
        """
        Today's delivery-level stats per bowler from the verified ledger.
        Returns legal balls, runs, wickets, dots, boundaries, dot%, boundary%.
        """
        out={}
        deliveries=self._apply_ledger_to_deliveries(getattr(self,"_latest_deliveries",[]) or [])
        for d in deliveries:
            bow=self._delivery_bowler_name(d).strip()
            if not bow:continue
            k=player_key(bow)
            r=out.setdefault(k,{"name":bow,"legal":0,"runs":0,"wkts":0,"dots":0,"boundaries":0})
            token=self._strict_ball_token(d,str(d.get("source","")))
            legal=bool(d.get("legal_delivery",True))
            runs=int(d.get("runs",0) or 0)
            if legal:
                r["legal"]+=1
                if runs==0 and token not in ("W","WD","NB"):r["dots"]+=1
            r["runs"]+=runs
            if token=="W":r["wkts"]+=1
            if legal and runs in (4,6):r["boundaries"]+=1
        for r in out.values():
            r["dot_pct"]=safe_div(r["dots"]*100,r["legal"],0)
            r["boundary_pct"]=safe_div(r["boundaries"]*100,r["legal"],0)
            r["econ"]=safe_div(r["runs"]*6,r["legal"],0)
        return out

    def _remaining_resource_matrix(self,fmt):
        """
        Build professional remaining-resource intelligence for the current innings.
        """
        curr=self._current_scorecard_innings()
        bats=list(curr.get("batsmen",[]) or [])
        bowls=list(curr.get("bowlers",[]) or [])
        bx=self.names(self.bat_xi)
        ox=self.names(self.bowl_xi)

        appeared={player_key(x.get("name","")) for x in bats}
        dismissed={
            player_key(x.get("name","")) for x in bats
            if str(x.get("dismissal","") or "").strip()
        }
        active=[x for x in bats if player_key(x.get("name","")) not in dismissed and str(x.get("name","") or "").strip()]
        yet=[p for p in bx if player_key(p) not in appeared]

        # Active/current batters.
        active_info=[]
        for row in active[-2:]:
            name=str(row.get("name","") or "").strip()
            runs=int(row.get("runs",0) or 0); balls=int(row.get("balls",0) or 0)
            fours=int(row.get("fours",row.get("4s",0)) or 0)
            sixes=int(row.get("sixes",row.get("6s",0)) or 0)
            sr=safe_div(runs*100,balls,0)
            boundary_runs=fours*4+sixes*6
            boundary_share=safe_div(boundary_runs*100,max(1,runs),0) if runs else 0
            hist=self.db.recent_batting_form(name,fmt,10) if name else None
            rating=self.model.batter_score(name,fmt) if name else None
            active_info.append({
                "name":name,"runs":runs,"balls":balls,"sr":sr,"fours":fours,"sixes":sixes,
                "boundary_share":boundary_share,
                "rating":rating[0] if rating else 50.0,
                "recent_sr":float(hist["sr"]) if hist else None,
                "recent_avg":float(hist["avg_score"]) if hist else None
            })

        yet_info=[]
        for p in yet:
            rating=self.model.batter_score(p,fmt)
            hist=self.db.recent_batting_form(p,fmt,10)
            career_sr=(rating[1].get("sr") if rating else None)
            death_sr=(rating[1].get("death_sr") if rating else None)
            yet_info.append({
                "name":p,
                "rating":rating[0] if rating else 50.0,
                "career_sr":float(career_sr) if career_sr is not None else None,
                "death_sr":float(death_sr) if death_sr is not None else None,
                "recent_sr":float(hist["sr"]) if hist else None,
                "recent_avg":float(hist["avg_score"]) if hist else None,
            })
        yet_info.sort(key=lambda x:x["rating"],reverse=True)

        # Today's bowling and overs remaining.
        live_stats=self._live_bowler_delivery_stats()
        scorecard_by={player_key(x.get("name","")):x for x in bowls if str(x.get("name","") or "").strip()}
        used_info=[];unused_info=[]
        for p in ox:
            k=player_key(p)
            row=scorecard_by.get(k,{})
            live=live_stats.get(k,{})
            used_balls=max(self._overs_to_legal_balls_simple(row.get("overs",0)),int(live.get("legal",0) or 0))
            max_balls=20 if fmt=="Hundred" else 24
            balls_left=max(0,max_balls-used_balls)
            hist=self.db.recent_bowling_form(p,fmt,10)
            rating=self.model.bowler_score(p,fmt)
            info={
                "name":p,
                "used_balls":used_balls,
                "balls_left":balls_left,
                "today_econ":float(live.get("econ",row.get("economy",0)) or 0),
                "today_wkts":int(live.get("wkts",row.get("wickets",0)) or 0),
                "today_dot_pct":float(live.get("dot_pct",0) or 0),
                "today_boundary_pct":float(live.get("boundary_pct",0) or 0),
                "rating":rating[0] if rating else 50.0,
                "recent_econ":float(hist["econ"]) if hist else None,
                "recent_wkts":int(hist["wickets"]) if hist else None,
                "death_econ":float(rating[1].get("death_econ")) if rating and rating[1].get("death_econ") is not None else None
            }
            (used_info if used_balls>0 else unused_info).append(info)

        # Future bowling quality weighted by balls still available.
        available=[x for x in used_info+unused_info if x["balls_left"]>0]
        if available:
            denom=sum(x["balls_left"] for x in available)
            future_bowl_rating=sum(x["rating"]*x["balls_left"] for x in available)/max(1,denom)
            control_scores=[]
            for x in available:
                c=50.0
                if x["today_dot_pct"]>0:c+=clamp((x["today_dot_pct"]-35)*0.8,-12,16)
                if x["today_boundary_pct"]>0:c-=clamp((x["today_boundary_pct"]-12)*0.9,-8,18)
                if x["today_econ"]>0:c+=clamp((8.5-x["today_econ"])*2.2,-15,15)
                if x["recent_econ"] is not None:c+=clamp((8.5-x["recent_econ"])*1.2,-10,10)
                control_scores.append((c,x["balls_left"]))
            future_control=sum(c*w for c,w in control_scores)/max(1,sum(w for _,w in control_scores))
        else:
            future_bowl_rating=50.0;future_control=50.0

        # Remaining batting quality: current pair + yet-to-bat.
        bat_scores=[x["rating"] for x in active_info]+[x["rating"] for x in yet_info[:4]]
        remaining_bat_rating=statistics.mean(bat_scores) if bat_scores else 50.0

        return {
            "active":active_info,"yet":yet_info,
            "used_bowlers":used_info,"unused_bowlers":unused_info,
            "future_bowl_rating":future_bowl_rating,
            "future_control":future_control,
            "remaining_bat_rating":remaining_bat_rating,
        }

    def _pressure_momentum_matrix(self,fmt,score,wkts,balls,total):
        deliveries=getattr(self,"_latest_deliveries",[]) or []
        l6,l12=self._recent_ball_metrics(deliveries)
        idx=self._technical_indices(l6,l12,score,wkts,balls,
                                    self._live_int(self.target) if self.innings_var.get()=="2nd Innings" else None,
                                    total)
        recent_rr=float(l12.get("rr") or safe_div(score*6,balls,0)) if l12 else safe_div(score*6,balls,0)
        crr=safe_div(score*6,balls,0)
        wicket_recent=int(l12.get("wickets",0) or 0) if l12 else 0
        pressure=0.0
        pressure+=float(idx.get("dot_pressure") or 0)*0.32
        pressure+=float(idx.get("wicket_pressure") or 0)*0.42
        pressure+=max(0.0,(crr-recent_rr))*5.0
        pressure+=max(0,wkts-5)*5.0
        pressure=clamp(pressure,0,100)
        momentum=clamp(50+(recent_rr-crr)*5.5-float(idx.get("wicket_pressure") or 0)*0.18,0,100)
        return {
            "dot_pressure":idx.get("dot_pressure"),
            "boundary_threat":idx.get("boundary_threat"),
            "wicket_pressure":idx.get("wicket_pressure"),
            "acceleration":idx.get("acceleration_index"),
            "pressure":pressure,"momentum":momentum,
            "recent_rr":recent_rr,"crr":crr,"recent_wickets":wicket_recent
        }

    def _resource_calibrated_future_rpb(self,fmt,score,wkts,balls,total,projected_hint=None):
        deliveries=getattr(self,"_latest_deliveries",[]) or []
        l6,l12=self._recent_ball_metrics(deliveries)
        inn_rpb=safe_div(score,balls,1.0)
        r6=(float(l6.get("runs",0))/max(1,int(l6.get("legal",0) or 0))) if l6 and l6.get("legal") else inn_rpb
        r12=(float(l12.get("runs",0))/max(1,int(l12.get("legal",0) or 0))) if l12 and l12.get("legal") else inn_rpb

        resources=self._remaining_resource_matrix(fmt)
        pm=self._pressure_momentum_matrix(fmt,score,wkts,balls,total)

        # Live pace and momentum.
        base=0.34*inn_rpb+0.34*r6+0.22*r12

        # Final model projection is only a small hint.
        if projected_hint is not None and total>balls:
            hint=max(0.0,(float(projected_hint)-score)/(total-balls))
            base=0.90*base+0.10*hint

        wickets_in_hand=max(0,10-wkts)
        base*=self._resource_run_factor(wickets_in_hand)
        base*=self._phase_run_factor(balls,total,fmt)

        # Actual quality of batting resources remaining.
        batq=resources["remaining_bat_rating"]
        base*=clamp(1.0+(batq-50)*0.0055,0.78,1.24)

        # Quality/control of bowlers that can still bowl.
        bowlq=resources["future_bowl_rating"]
        control=resources["future_control"]
        base*=clamp(1.0-(bowlq-50)*0.0040-(control-50)*0.0035,0.72,1.23)

        # Current active batter live strike rates versus historical ability.
        active=resources["active"]
        if active:
            live_srs=[x["sr"] for x in active if x["balls"]>=4]
            if live_srs:
                live_sr=statistics.mean(live_srs)
                base*=clamp(1.0+(live_sr-130)*0.0018,0.86,1.15)

        # Pressure/momentum.
        base*=clamp(1.0+(pm["momentum"]-50)*0.0035-(pm["pressure"]-50)*0.0030,0.78,1.20)

        # Current batter/bowler matchup.
        striker=self.striker.get().strip()
        non=self.non_striker.get().strip()
        bowler=self.current_bowler.get().strip()
        bat_scores=[]
        for p in (striker,non):
            if p and "unknown" not in p.lower():
                x=self.model.batter_score(p,fmt)
                if x:bat_scores.append(x[0])
        bowl_score=50.0
        if bowler and "unknown" not in bowler.lower():
            x=self.model.bowler_score(bowler,fmt)
            if x:bowl_score=x[0]
        if bat_scores:
            edge=(statistics.mean(bat_scores)-bowl_score)/100.0
            base*=clamp(1.0+edge*0.18,0.88,1.12)

        return clamp(base,0.28,2.35)

    def _checkpoint_distribution(self,fmt,score,wkts,balls,total,checkpoint_balls,projected_hint=None):
        """
        Expected checkpoint score and uncertainty based only on the balls remaining
        TO THAT CHECKPOINT, not a linear interpolation from a potentially unstable
        final-innings prediction.
        """
        if checkpoint_balls<=balls:
            return float(score),1.0

        rem=checkpoint_balls-balls
        future_rpb=self._resource_calibrated_future_rpb(
            fmt,score,wkts,balls,total,projected_hint
        )

        # As wickets fall, both mean and downside uncertainty change.
        wickets_in_hand=max(0,10-wkts)
        mean_add=rem*future_rpb
        mu=score+mean_add

        # Variance per ball rises with attacking phase but wicket scarcity adds
        # downside risk rather than simply increasing the mean.
        sd_per_ball=1.22
        if balls>=int(total*0.80):sd_per_ball=1.42
        sd=math.sqrt(max(1,rem))*sd_per_ball
        if wickets_in_hand<=4:sd*=1.18
        if wickets_in_hand<=2:sd*=1.28

        # Resource ceiling: extremely high checkpoint jumps become less plausible
        # with few wickets remaining.
        if wickets_in_hand<=3:
            max_reasonable_add=rem*(1.75 if wickets_in_hand==3 else 1.45 if wickets_in_hand==2 else 1.15)
            mu=min(mu,score+max_reasonable_add)

        return mu,max(3.0,sd)

    def _resource_calibrated_finish(self,fmt,score,wkts,balls,total,projected_hint=None):
        if balls>=total:return float(score)
        rpb=self._resource_calibrated_future_rpb(fmt,score,wkts,balls,total,projected_hint)
        rem=total-balls
        finish=score+rem*rpb

        # Harder upper envelopes by wickets in hand. These are not caps on cricket
        # outcomes; they are anti-extrapolation guards for the model estimate.
        wh=max(0,10-wkts)
        if wh<=3:
            upper=score+rem*(1.90 if wh==3 else 1.55 if wh==2 else 1.20)
            finish=min(finish,upper)
        return max(float(score),finish)

    def _fancy_probability_engine(self,ftype,horizon,line,side):
        self._refresh_fancy_evidence_sources()
        self._hydrate_live_matchup_from_sources()
        fmt=self.format_var.get()
        s=self._live_int(self.score); w=self._live_int(self.wkts); b=self._live_int(self.balls)
        total=self._effective_total_balls(fmt)
        venue=self.venue.get().strip()
        bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
        last=self._live_int(self.last)

        if self.innings_var.get()=="2nd Innings":
            target=self._live_int(self.target)
            base=self.model.chase(fmt,venue,bx,ox,s,w,b,target,last,total_balls=total)
            # Derive neutral projected finish for line analysis.
            req=max(0,target-s); rem=max(1,total-b)
            raw_projected=s+rem*max(0.45,req/rem)
            projected=self._resource_calibrated_finish(fmt,s,w,b,total,raw_projected)
        else:
            base=self.model.live_first(fmt,venue,bx,ox,s,w,b,last,total_balls=total,
                                       pp_balls=self._effective_pp_balls(fmt))
            raw_projected=float(base.get("pred",s))
            projected=self._resource_calibrated_finish(fmt,s,w,b,total,raw_projected)

        deliveries=getattr(self,"_latest_deliveries",[]) or []
        l6,l12=self._recent_ball_metrics(deliveries)
        recent6=float(l6.get("runs",0) or 0) if l6 else 0.0
        recent12=float(l12.get("runs",0) or 0) if l12 else 0.0
        recent6_legal=int(l6.get("legal",0) or 0) if l6 else 0
        recent12_legal=int(l12.get("legal",0) or 0) if l12 else 0

        f=ftype.lower()
        h=str(horizon or "").lower()
        reasons=[]
        p_over=50.0
        model_center=None
        uncertainty=8.0

        if "checkpoint team score" in f:
            cb=self._fancy_checkpoint_balls(horizon,fmt)
            if cb is None: raise ValueError("Choose a checkpoint such as 6/10/15/20 Overs.")
            cb=min(cb,total)
            rem=cb-b
            if rem<=0:
                p_over=100.0 if s>=line else 0.0
                model_center=float(s)
                uncertainty=1.0
            else:
                model_center,uncertainty=self._checkpoint_distribution(
                    fmt,s,w,b,total,cb,projected
                )
                p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100

            need=max(0.0,line-s)
            req_rpb=safe_div(need,max(1,rem),0) if rem>0 else 0
            sustainable=self._resource_calibrated_future_rpb(fmt,s,w,b,total,projected)
            reasons += [
                f"Checkpoint model center {model_center:.1f}",
                f"Resource-calibrated innings finish {projected:.0f}",
                f"Current score {s}/{w} after {b} legal balls",
                f"Runs needed for line {need:.1f} from {max(0,rem)} balls ({req_rpb:.2f} r/ball)",
                f"Model sustainable future pace {sustainable:.2f} r/ball",
                f"Wickets in hand {max(0,10-w)}"
            ]

        elif "next over runs" in f and "2" not in f:
            n=6
            base_rpb=self._resource_calibrated_future_rpb(fmt,s,w,b,total,projected)
            recent_rpb=(recent6/max(1,recent6_legal)) if recent6_legal else base_rpb
            model_center=n*(0.60*base_rpb+0.40*recent_rpb)
            uncertainty=3.4
            p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100
            reasons += [f"Next-over run center {model_center:.1f}",
                        f"Recent 6-ball runs {recent6:.0f}",
                        f"Current RR {safe_div(s*6,b,0):.2f}"]

        elif "next 2 overs" in f:
            n=12
            base_rpb=self._resource_calibrated_future_rpb(fmt,s,w,b,total,projected)
            recent_rpb=(recent12/max(1,recent12_legal)) if recent12_legal else base_rpb
            model_center=n*(0.60*base_rpb+0.40*recent_rpb)
            uncertainty=5.2
            p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100
            reasons += [f"Next-12-ball run center {model_center:.1f}",
                        f"Recent 12-ball runs {recent12:.0f}",
                        f"Wickets in hand {max(0,10-w)}"]

        elif "next 6 legal balls runs" in f:
            n=6
            base_rpb=self._resource_calibrated_future_rpb(fmt,s,w,b,total,projected)
            recent_rpb=(recent6/max(1,recent6_legal)) if recent6_legal else base_rpb
            model_center=n*(0.60*base_rpb+0.40*recent_rpb)
            uncertainty=3.2
            p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100
            reasons += [f"Next 6 legal balls center {model_center:.1f}",f"Last 6 runs {recent6:.0f}"]

        elif "next 12 legal balls runs" in f:
            n=12
            base_rpb=self._resource_calibrated_future_rpb(fmt,s,w,b,total,projected)
            recent_rpb=(recent12/max(1,recent12_legal)) if recent12_legal else base_rpb
            model_center=n*(0.60*base_rpb+0.40*recent_rpb)
            uncertainty=5.0
            p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100
            reasons += [f"Next 12 legal balls center {model_center:.1f}",f"Last 12 runs {recent12:.0f}"]

        elif "team wickets by checkpoint" in f:
            cb=self._fancy_checkpoint_balls(horizon,fmt)
            if cb is None: raise ValueError("Choose a wicket checkpoint such as 10 or 15 Overs.")
            future=max(0,cb-b)
            current_w=w
            # Simple hazard calibrated by current wickets and innings phase.
            base_hazard=0.045
            if w>=4:base_hazard*=1.15
            if b>total*0.75:base_hazard*=1.20
            expected_w=current_w+future*base_hazard
            model_center=expected_w
            sd=max(0.9,math.sqrt(max(1,future*base_hazard))*0.95)
            p_over=(1-self._normal_cdf(line-0.5,expected_w,sd))*100
            reasons += [f"Expected wickets by checkpoint {expected_w:.2f}",
                        f"Current wickets {w}",f"Future balls to checkpoint {future}"]

        elif "boundaries" in f:
            # Boundary event model from recent legal-ball windows.
            boundary_count=0; legal_count=0
            for d in deliveries[-30:]:
                if d.get("legal_delivery",True):
                    legal_count+=1
                    if d.get("boundary") or int(d.get("runs",0) or 0) in (4,6):
                        boundary_count+=1
            rate=boundary_count/max(1,legal_count)
            if "next 6" in f:n=6
            elif "next 12" in f:n=12
            else:
                cb=self._fancy_checkpoint_balls(horizon,fmt)
                n=max(0,(cb or b)-b)
            expected=n*rate
            model_center=expected
            sd=max(0.8,math.sqrt(max(0.2,expected*(1-rate))))
            p_over=(1-self._normal_cdf(line-0.5,expected,sd))*100
            reasons += [f"Recent boundary-ball rate {rate*100:.1f}%",
                        f"Expected boundaries in window {expected:.2f}",
                        f"Window {n} legal balls"]

        elif "current partnership" in f:
            pr=self._live_int(self.partnership_runs)
            pb=self._live_int(self.partnership_balls)
            # Estimate additional partnership runs from current pair tempo and wicket hazard.
            pair_rpb=safe_div(pr,pb,safe_div(s,b,1.0))
            expected_add=pair_rpb*8.0
            model_center=pr+expected_add
            uncertainty=max(5.0,expected_add*0.7)
            p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100
            reasons += [f"Current partnership {pr} from {pb} balls",
                        f"Pair scoring rate {pair_rpb:.2f} runs/ball",
                        f"Partnership model center {model_center:.1f}"]

        elif "batter runs" in f:
            sr=self._live_int(self.striker_runs); sb=self._live_int(self.striker_balls)
            striker=self.striker.get().strip()
            hist=self.db.recent_batting_form(striker,fmt,10) if striker else None
            live_sr=safe_div(sr*100,sb,0)
            hist_sr=float(hist["sr"]) if hist else 130.0
            expected_sr=0.65*max(70.0,live_sr if sb>=5 else hist_sr)+0.35*hist_sr
            expected_add=max(4.0,(expected_sr/100)*10)
            model_center=sr+expected_add
            uncertainty=max(5.0,expected_add*0.65)
            p_over=(1-self._normal_cdf(line-0.5,model_center,uncertainty))*100
            reasons += [f"{striker or 'Striker'} currently {sr}({sb})",
                        f"Live SR {live_sr:.1f}",f"Recent historical SR {hist_sr:.1f}"]

        else:
            raise ValueError("This fancy type is not yet supported.")

        p_over=clamp(p_over,1,99)
        chosen_over=str(side).lower().startswith("over")
        p_raw=p_over if chosen_over else 100-p_over

        evidence=self._integrated_fancy_evidence(projected)
        shell={"side":side}
        p,votes,agree,oppose,neutral=self._fancy_ensemble_adjust(p_raw,shell,evidence)
        opposite=100-p

        # Recommendation must be consistent with BOTH probability and evidence quality.
        q=evidence["quality"]
        if q<25:
            rec="PASS — INSUFFICIENT VERIFIED DATA"
        elif oppose>=3:
            rec="PASS — ANALYST MODULES CONFLICT"
        elif p>=80 and q>=65 and oppose<=1:
            rec="STRONG ANALYST LEAN"
        elif p>=68 and q>=50 and oppose<=2:
            rec="ANALYST LEAN"
        elif p>=58 and q>=35:
            rec="SLIGHT LEAN"
        else:
            rec="PASS / NO CLEAR EDGE"

        return {
            "probability":p,
            "raw_probability":p_raw,
            "opposite":opposite,
            "over_probability":p_over,
            "recommendation":rec,
            "model_center":model_center,
            "reasons":reasons,
            "coverage":evidence["xi_coverage"],
            "quality":q,
            "projected":projected,
            "type":ftype,"horizon":horizon,"line":line,"side":side,
            "evidence":evidence,"votes":votes,
            "agree":agree,"oppose":oppose,"neutral":neutral
        }

    def analyze_custom_fancy(self):
        try:
            line=float(self.fancy_line.get().strip())
            r=self._fancy_probability_engine(
                self.fancy_type.get(),self.fancy_horizon.get(),line,self.fancy_side.get()
            )
            e=r["evidence"]
            vote_lines=[]
            for name,p,w in r["votes"]:
                tag="SUPPORTS" if p>=55 else "OPPOSES" if p<=45 else "NEUTRAL"
                vote_lines.append(f"• {name:32} {p:5.1f}%  {tag}")

            sent=e["sentiments"]
            strongest_positive=sorted(sent.items(),key=lambda x:x[1],reverse=True)[:3]
            strongest_negative=sorted(sent.items(),key=lambda x:x[1])[:3]

            txt=[
                "ADVANCED CUSTOM FANCY ASSESSMENT",
                "="*96,
                f"Fancy               : {r['type']}",
                f"Horizon              : {r['horizon']}",
                f"Market line          : {r['line']}",
                f"Selected side        : {r['side']}",
                "",
                f"FINAL ENSEMBLE PROB. : {r['probability']:.1f}%",
                f"Opposite side        : {r['opposite']:.1f}%",
                f"Raw line model       : {r['raw_probability']:.1f}%  (before analyst integration)",
                f"Assessment           : {r['recommendation']}",
                f"Evidence quality     : {r['quality']:.1f}/100",
                f"Module agreement     : {r['agree']} support / {r['oppose']} oppose / {r['neutral']} neutral",
                (f"Fancy model center   : {r['model_center']:.1f}" if r['model_center'] is not None else ""),
                "",
                "1. LIVE MATCH STATE",
                "-"*96,
                f"Score {e['score']}/{e['wkts']} after {e['balls']} legal balls | phase {e['phase']}",
                f"Innings pace {e['innings_rpb']:.2f} r/ball | recent momentum {e['recent_rpb']:.2f} r/ball",
                f"Resource-calibrated innings projection {r['projected']:.1f}",
                "",
                "2. VENUE / PAR / TEAM CAPACITY",
                "-"*96,
                f"Venue historical par {e['venue_par']:.1f}",
                f"XI-adjusted team-capacity par {e['capacity_par']:.1f}",
                f"Expected score at current ball {e['expected_now']:.1f}",
                f"Actual tempo vs team-capacity curve {e['tempo']:+.1f} runs",
                "",
                "3. XI & CURRENT PLAYER MATCHUP",
                "-"*96,
                f"Batting XI strength {e['batting_xi']:.1f}/100",
                f"Opposition bowling strength {e['bowling_xi']:.1f}/100",
                f"Historical XI coverage {e['xi_coverage']:.1f}%",
                f"Current batter matchup {e['batting_matchup']:.1f}/100 vs bowler {e['bowling_matchup']:.1f}/100",
                f"Striker: {e['striker'] or '--'} | Non-striker: {e['non'] or '--'} | Bowler: {e['bowler'] or '--'}",
                "",
                "4. REMAINING BATTING RESOURCES",
                "-"*96,
                f"Remaining batting quality: {e['resources']['remaining_bat_rating']:.1f}/100",
                *([
                    f"ACTIVE {x['name']}: {x['runs']}({x['balls']}) SR {x['sr']:.1f} | "
                    f"4s {x['fours']} 6s {x['sixes']} | rating {x['rating']:.0f}/100"
                    for x in e['resources']['active']
                ] or ["No active-batter scorecard detail available"]),
                *([
                    f"YET {i+1}. {x['name']}: rating {x['rating']:.0f}/100 | "
                    f"Career SR {x['career_sr'] if x['career_sr'] is not None else '--'} | "
                    f"Recent SR {x['recent_sr'] if x['recent_sr'] is not None else '--'} | "
                    f"Death SR {x['death_sr'] if x['death_sr'] is not None else '--'}"
                    for i,x in enumerate(e['resources']['yet'][:6])
                ] or ["No yet-to-bat players identified"]),
                "",
                "5. BOWLING RESOURCES STILL AVAILABLE",
                "-"*96,
                f"Future bowling rating: {e['resources']['future_bowl_rating']:.1f}/100 | "
                f"Future control: {e['resources']['future_control']:.1f}/100",
                *([
                    f"USED {x['name']}: {x['today_wkts']} wkts | Econ {x['today_econ']:.2f} | "
                    f"Dot {x['today_dot_pct']:.1f}% | Boundary {x['today_boundary_pct']:.1f}% | "
                    f"Balls left {x['balls_left']} | Rating {x['rating']:.0f}/100"
                    for x in e['resources']['used_bowlers']
                ] or ["No used-bowler figures exposed"]),
                *([
                    f"YET/UNUSED {x['name']}: Balls available {x['balls_left']} | "
                    f"Rating {x['rating']:.0f}/100 | Recent Econ "
                    f"{x['recent_econ'] if x['recent_econ'] is not None else '--'} | Death Econ "
                    f"{x['death_econ'] if x['death_econ'] is not None else '--'}"
                    for x in e['resources']['unused_bowlers']
                ] or ["No unused bowler information identified"]),
                "",
                "6. PRESSURE / MOMENTUM",
                "-"*96,
                f"Pressure index {e['pressure']['pressure']:.1f}/100 | "
                f"Momentum {e['pressure']['momentum']:.1f}/100",
                f"Dot-ball pressure {e['pressure']['dot_pressure']} | "
                f"Boundary threat {e['pressure']['boundary_threat']} | "
                f"Wicket pressure {e['pressure']['wicket_pressure']}",
                f"Current RR {e['pressure']['crr']:.2f} | Recent RR {e['pressure']['recent_rr']:.2f} | "
                f"Recent wickets {e['pressure']['recent_wickets']}",
                "",
                "7. INDEPENDENT ANALYST VOTES",
                "-"*96,
                *vote_lines,
                "",
                "8. LINE-SPECIFIC REASONS",
                "-"*96,
                *[f"• {x}" for x in r["reasons"]],
                "",
                "9. COACH / TECHNICAL / TREND CONSENSUS",
                "-"*96,
                f"Technical sentiment {sent['technical']:+d} | Advanced {sent['advanced']:+d} | "
                f"Comparison {sent['comparison']:+d} | Trend {sent['trend']:+d}",
                f"Coach sentiment {sent['coach']:+d} | Player intelligence {sent['players']:+d} | "
                f"Squad/resources {sent['squad']:+d}",
                "",
                "10. PROFESSIONAL INTERPRETATION",
                "-"*96,
            ]

            if r["recommendation"].startswith("PASS"):
                txt += [
                    "Recommendation: PASS.",
                    "Reason: the combined analyst system does not have enough independent agreement and/or "
                    "verified data quality to justify a confident line call.",
                ]
            else:
                txt += [
                    f"Recommendation: {r['recommendation']}.",
                    f"The selected side is supported by {r['agree']} independent evidence modules, "
                    f"with {r['oppose']} materially opposing.",
                ]

            if r["quality"]<40:
                txt.append(
                    "Important: low evidence quality materially reduced the final probability toward 50%; "
                    "the raw mathematical line probability was NOT trusted by itself."
                )
            if r["oppose"]>=2:
                txt.append(
                    "Contradiction warning: multiple analyst modules oppose the selected side, so confidence "
                    "was reduced even if the raw projection looked attractive."
                )

            txt += [
                "",
                "The final percentage is an ensemble estimate from the same live match. "
                "It is not a guarantee and intentionally becomes conservative when evidence conflicts."
            ]
            self.fancy_result.delete("1.0","end")
            self.fancy_result.insert("1.0","\n".join(x for x in txt if x!=""))
            self.poss_status.set(
                f"Integrated analyst assessment {time.strftime('%H:%M:%S')} • "
                f"quality {r['quality']:.0f}/100 • {r['agree']}/{len(r['votes'])} modules support"
            )
        except Exception as e:
            self.fancy_result.delete("1.0","end")
            self.fancy_result.insert("1.0","Fancy analysis error: "+str(e))

    def add_fancy_to_comparison(self):
        try:
            line=float(self.fancy_line.get().strip())
            r=self._fancy_probability_engine(self.fancy_type.get(),self.fancy_horizon.get(),line,self.fancy_side.get())
            self.fancy_compare.append(r)
            self.fancy_compare=self.fancy_compare[-12:]
            rows=["FANCY COMPARISON BOARD","="*98]
            for i,x in enumerate(sorted(self.fancy_compare,key=lambda z:z["probability"],reverse=True),1):
                rows.append(
                    f"{i:>2}. {x['type'][:24]:24} | {x['horizon'][:12]:12} | "
                    f"{x['side'][:10]:10} {x['line']:>6.1f} | "
                    f"P {x['probability']:>5.1f}% | Q {x.get('quality',0):>4.0f} | {x['recommendation']}"
                )
            self.fancy_compare_out.delete("1.0","end");self.fancy_compare_out.insert("1.0","\n".join(rows))
        except Exception as e:
            self.fancy_compare_out.delete("1.0","end");self.fancy_compare_out.insert("1.0","Comparison error: "+str(e))

    def clear_fancy_comparison(self):
        self.fancy_compare=[]
        self.fancy_compare_out.delete("1.0","end")
        self.fancy_compare_out.insert("1.0","No fancy lines added yet.")

    def refresh_possibilities(self):
        try:
            self._hydrate_live_matchup_from_sources()
            fmt=self.format_var.get()
            s=self._live_int(self.score); w=self._live_int(self.wkts); b=self._live_int(self.balls)
            total=self._effective_total_balls(fmt)
            venue=self.venue.get().strip()
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
            last=self._live_int(self.last)
            if self.innings_var.get()=="2nd Innings":
                target=self._live_int(self.target)
                chase=self.model.chase(fmt,venue,bx,ox,s,w,b,target,last,total_balls=total)
                projected=s+max(0,total-b)*max(0.35,(target-s)/max(1,total-b))
                headline=f"CHASE WIN PROBABILITY: {chase.get('win',50):.1f}%"
            else:
                pred=self.model.live_first(fmt,venue,bx,ox,s,w,b,last,total_balls=total,
                                           pp_balls=self._effective_pp_balls(fmt))
                projected=float(pred.get("pred",s))
                headline=f"PROJECTED FINISH: {projected:.0f}  | model range {pred.get('low','--')}–{pred.get('high','--')}"

            v=self.db.venue_stats(venue,fmt)
            bp=self.model.xi_profile(bx,fmt) if bx else {"batting":50,"coverage":0}
            op=self.model.xi_profile(ox,fmt) if ox else {"bowling":50,"coverage":0}
            rr=safe_div(s*6,b,0)
            checkpoints=[("6 OVERS",36),("10 OVERS",60),("15 OVERS",90),("20 OVERS",120)] if fmt=="T20" else [
                ("25 BALLS",25),("50 BALLS",50),("75 BALLS",75),("100 BALLS",100)]
            checkpoints=[x for x in checkpoints if x[1]<=total]

            lines=[
                "LIVE POSSIBILITIES — PROFESSIONAL TECHNICAL ASSESSMENT",
                "="*84,
                f"{self.bat_team.get() or 'Batting side'} {s}/{w} after {b} legal balls | RR {rr:.2f}",
                f"Venue: {venue or '--'} | Historical avg {v['avg']:.0f} | sample {v['n']}",
                f"Batting strength {bp['batting']:.1f}/100 ({bp['coverage']:.0f}% coverage) | "
                f"Opposition bowling {op['bowling']:.1f}/100 ({op['coverage']:.0f}% coverage)",
                headline,"",
                "CHECKPOINT SCORE-LINE PROBABILITIES",
                "-"*84,
            ]
            for label,cb in checkpoints:
                if cb<=b:
                    lines.append(f"{label}: completed — actual score {s if cb==b else 'see scorecard'}")
                    continue
                rem=cb-b
                mean=s+(projected-s)*(rem/max(1,total-b))
                # practical nearby lines in 5-run steps around expected checkpoint
                center=int(round(mean/5)*5)
                candidates=sorted(set([max(s,center-15),max(s,center-10),max(s,center-5),
                                       max(s,center),max(s,center+5),max(s,center+10),max(s,center+15)]))
                lines.append(f"{label} — model center ≈ {mean:.1f}")
                for ln in candidates:
                    p=self._checkpoint_probability(s,b,cb,projected,total,w,ln)
                    band=("HIGH" if p>=72 else "LEAN" if p>=58 else "BALANCED" if p>=42 else
                          "LOW" if p>=25 else "VERY LOW")
                    lines.append(f"  Reach {ln:>3}+ : {p:5.1f}%  [{band}]")
                lines.append("")

            # Event possibilities from live model / historical strength.
            if self.innings_var.get()!="2nd Innings":
                ev=pred
                lines += [
                    "NEXT-BLOCK POSSIBILITIES",
                    "-"*84,
                    f"Next {ev.get('next_n',6)} legal balls expected runs: {ev.get('next_runs','--')}",
                    f"At least one boundary: {ev.get('boundary_pct','--')}%",
                    f"At least one wicket:   {ev.get('wicket_pct','--')}%",
                    "",
                ]

            # Coach/technical assessment, without forcing a popup or manual player entry.
            try:
                a=self.model.technical_assessment(fmt,venue,bx,ox,s,w,b,
                    self._live_int(self.target) if self.innings_var.get()=="2nd Innings" else None,last)
            except Exception:
                a={}
            lines += [
                "COACH + TECHNICAL READ",
                "-"*84,
                f"Batting unit: {a.get('batting_band','--')} | Bowling unit: {a.get('bowling_band','--')}",
                f"Venue type: {a.get('venue_type','--')} | Tempo: {a.get('tempo','--')}",
                f"Wicket state: {a.get('wicket_state','--')} | Momentum: {a.get('momentum','--')}",
            ]
            if self.innings_var.get()=="2nd Innings":
                lines.append(f"Chase pressure: {a.get('chase_pressure','--')}")
            lines += ["",
                "DECISION GUIDANCE",
                "-"*84,
                "≥72%  Strong statistical possibility — conditions support the line.",
                "58–71% Lean possibility — supported, but keep uncertainty in view.",
                "42–57% Balanced / no clear edge — PASS rather than force a call.",
                "25–41% Low possibility — conditions currently oppose the line.",
                "<25%   Very low possibility from the present evidence.",
                "",
                "The app reports model probability, not certainty. A PASS is a valid recommendation "
                "when evidence is weak, data coverage is poor, or the probability is near 50%.",
            ]
            # Data-quality recommendation.
            cov=(bp.get("coverage",0)+op.get("coverage",0))/2
            if cov<35:
                lines += ["","DATA QUALITY WARNING: XI historical coverage is low. Recommendation: PASS on marginal lines."]
            elif b<12:
                lines += ["","EARLY-INNINGS WARNING: limited live evidence. Prefer only high-probability lines or PASS."]
            else:
                lines += ["",f"MODEL CONFIDENCE CONTEXT: XI coverage {cov:.0f}% and {b} live legal balls observed."]

            txt="\n".join(lines)
            self.poss_out.delete("1.0","end");self.poss_out.insert("1.0",txt)
            self.poss_status.set(f"Updated {time.strftime('%H:%M:%S')} • probabilities recomputed from current match state")
        except Exception as e:
            self.poss_status.set("Analysis unavailable")
            self.poss_out.delete("1.0","end")
            self.poss_out.insert("1.0","Possibilities analysis could not be generated: "+str(e))

    def build_home(self):
        top=ttk.Frame(self.tab_home)
        top.pack(fill="x",pady=(8,18))
        ttk.Label(top,text="CRICKET PRO AI",font=("Arial",26,"bold")).pack(anchor="w")
        ttk.Label(top,text="Professional live analysis — simplified for match-day use",
                  font=("Arial",12)).pack(anchor="w",pady=(2,0))

        self.home_status=tk.StringVar(value="Ready. Open LIVE SETUP to connect a match.")
        ttk.Label(self.tab_home,textvariable=self.home_status,font=("Arial",12,"bold")).pack(anchor="w",pady=(0,14))

        cards=ttk.Frame(self.tab_home);cards.pack(fill="x",pady=6)
        actions=[
            ("1  CONNECT LIVE","Choose a live match and connect the fast feed.",self.tab_live),
            ("2  LIVE CENTER","Score, current over, commentary and conditions.",self.tab_live_center),
            ("3  PREDICTION","First-innings projection or chase probability.",self.tab_match),
            ("4  ANALYSIS","Confidence, phase strength and forecast drivers.",self.tab_advanced),
            ("5  PLAYERS","Player form, last-10 and phase intelligence.",self.tab_player_intel),
            ("6  EXCHANGE","Read-only exchange/fancy live data.",self.tab_market),
        ]
        for i,(title,desc,target) in enumerate(actions):
            box=ttk.LabelFrame(cards,text=title,padding=12)
            box.grid(row=i//3,column=i%3,sticky="nsew",padx=6,pady=6)
            ttk.Label(box,text=desc,wraplength=260,justify="left").pack(anchor="w",pady=(0,10))
            ttk.Button(box,text="OPEN",command=lambda t=target:self.nb.select(t)).pack(anchor="w")
        for c in range(3):cards.columnconfigure(c,weight=1)

        tools=ttk.LabelFrame(self.tab_home,text="TOOLS",padding=12)
        tools.pack(fill="x",pady=12)
        ttk.Button(tools,text="Data / Import",command=lambda:self._open_hidden_tab(self.tab_data)).pack(side="left",padx=4)
        ttk.Button(tools,text="Show Advanced Tools",command=self.toggle_advanced_tabs).pack(side="left",padx=4)
        ttk.Button(tools,text="Diagnostics",command=self.toggle_live_diagnostics).pack(side="left",padx=4)
        ttk.Button(tools,text="Possibilities",command=lambda:self.nb.select(self.tab_possibility)).pack(side="left",padx=4)
        ttk.Label(tools,text="Advanced tools stay hidden during normal live use.").pack(side="left",padx=14)

    def _hidden_tabs(self):
        return [
            self.tab_data,self.tab_technical,self.tab_compare,self.tab_trend,
            self.tab_coach,self.tab_squad,self.tab_xi,self.tab_players
        ]

    def _set_advanced_tabs(self,visible):
        self._advanced_tabs_visible=bool(visible)
        for tab in self._hidden_tabs():
            try:
                if visible:self.nb.add(tab)
                else:self.nb.hide(tab)
            except Exception:pass

    def toggle_advanced_tabs(self):
        self._set_advanced_tabs(not self._advanced_tabs_visible)
        self.home_status.set(
            "Advanced tools are visible." if self._advanced_tabs_visible
            else "Advanced tools hidden — match-day interface simplified."
        )

    def _open_hidden_tab(self,tab):
        self._set_advanced_tabs(True)
        self.nb.select(tab)

    def toggle_live_diagnostics(self):
        if not hasattr(self,"live_raw_frame"):return
        try:
            if self.live_raw_frame.winfo_ismapped():
                self.live_raw_frame.pack_forget()
            else:
                self.live_raw_frame.pack(fill="both",expand=True,pady=6)
        except Exception:pass

    def build_data(self):
        ttk.Label(self.tab_data,text="Historical Data Engine",font=("Arial",18,"bold")).pack(pady=8)
        ttk.Label(self.tab_data,text="Import Cricsheet-style JSON files. The app automatically builds player batting/bowling and venue profiles.").pack()
        fr=ttk.Frame(self.tab_data); fr.pack(pady=12)
        ttk.Button(fr,text="Import JSON Files",command=self.import_json_files).pack(side="left",padx=6)
        ttk.Button(fr,text="Import JSON Folder",command=self.import_folder).pack(side="left",padx=6)
        ttk.Button(fr,text="Import ZIP of JSON Files",command=self.import_zip).pack(side="left",padx=6)
        ttk.Button(fr,text="Refresh Database Summary",command=self.refresh_summary).pack(side="left",padx=6)
        self.data_status=tk.StringVar(value="Ready")
        ttk.Label(self.tab_data,textvariable=self.data_status,font=("Arial",11,"bold")).pack(pady=5)
        self.summary=tk.Text(self.tab_data,height=18,font=("Consolas",12))
        self.summary.pack(fill="both",expand=True,pady=10)
        self.refresh_summary()

    def refresh_summary(self):
        c=self.db.counts()
        txt=(f"Database: {Path(DB_FILE).resolve()}\n\n"
             f"Matches imported : {c['matches']}\n"
             f"Innings           : {c['innings']}\n"
             f"Batters profiled  : {c['batters']}\n"
             f"Bowlers profiled  : {c['bowlers']}\n\n"
             "Recommended before serious use:\n"
             "- Import the historical matches for the relevant league/players.\n"
             "- More balls per player = stronger confidence.\n"
             "- Unknown players fall back toward neutral league-average strength.\n")
        self.summary.delete("1.0","end"); self.summary.insert("1.0",txt)

    def optimize_large_database(self):
        def worker():
            try:
                self.data_status.set("Optimizing database indexes/cache…")
                self.db.conn.execute("PRAGMA optimize")
                self.db.conn.execute("ANALYZE")
                self.db.conn.commit()
                self.db.invalidate_caches()
                self.root.after(0,lambda:self.data_status.set("Database optimized for large historical datasets."))
            except Exception as e:
                self.root.after(0,lambda:self.data_status.set("Optimize error: "+str(e)))
        # SQLite connection was created on main thread, so do this deferred on main
        # rather than a worker unless check_same_thread=False is introduced.
        try:
            self.data_status.set("Optimizing database indexes/cache…")
            self.db.conn.execute("ANALYZE")
            self.db.conn.execute("PRAGMA optimize")
            self.db.conn.commit()
            self.db.invalidate_caches()
            self.data_status.set("Database optimized for large historical datasets.")
            messagebox.showinfo("Database optimized","Indexes/statistics refreshed. Restart once for best performance.")
        except Exception as e:
            messagebox.showerror("Optimize database",str(e))

    def _finish_historical_import(self,ok,bad,errors):
        try:self.db.invalidate_caches()
        except Exception:pass
        self.refresh_summary()
        self.refresh_dropdowns()
        self.data_status.set(f"Import complete • new {ok} • errors {bad}")
        detail=""
        if errors:
            detail="\n\nFirst errors:\n"+"\n".join(errors[:12])
        messagebox.showinfo("Import complete",f"New matches: {ok}\nErrors: {bad}{detail}")

    def _run_historical_import(self,paths=None,zip_path=None):
        """Import on an independent WAL connection so live monitoring stays usable."""
        if getattr(self,"_historical_import_running",False):
            messagebox.showinfo("Import running","A historical-data import is already running.")
            return
        self._historical_import_running=True
        self.data_status.set("Preparing historical JSON import…")

        def progress(msg):
            try:self.root.after(0,lambda m=str(msg):self.data_status.set(m))
            except Exception:pass

        def worker():
            local_db=None
            try:
                local_db=DB(str(Path(DB_FILE).resolve()))
                imp=Importer(local_db,progress)
                if zip_path:
                    ok,bad=imp.import_zip(zip_path)
                else:
                    ok,bad=imp.import_paths(paths or [])
                errors=list(imp.last_errors)
                self.root.after(0,lambda:self._finish_historical_import(ok,bad,errors))
            except Exception as e:
                msg=str(e)
                self.root.after(0,lambda:self.data_status.set("Import failed: "+msg))
                self.root.after(0,lambda:messagebox.showerror("Import failed",msg))
            finally:
                try:
                    if local_db:local_db.conn.close()
                except Exception:pass
                self._historical_import_running=False
        threading.Thread(target=worker,daemon=True).start()

    def import_json_files(self):
        paths=filedialog.askopenfilenames(
            title="Select Cricsheet JSON match files",
            filetypes=[("JSON match files","*.json"),("All files","*.*")]
        )
        if not paths:return
        self._run_historical_import(paths=list(paths))

    def import_folder(self):
        folder=filedialog.askdirectory()
        if not folder:return
        paths=list(Path(folder).rglob("*.json"))
        if not paths:
            messagebox.showwarning("No JSON","No JSON files found."); return
        self._run_historical_import(paths=paths)

    def import_zip(self):
        p=filedialog.askopenfilename(filetypes=[("ZIP","*.zip")])
        if not p:return
        self._run_historical_import(zip_path=p)

    def _load_api_config(self):
        try:
            return json.loads(Path(API_CONFIG_FILE).read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_api_config(self):
        try:
            Path(API_CONFIG_FILE).write_text(json.dumps({
                "provider":"CricketData/CricAPI",
                "apikey":self.api_key.get().strip(),
                "refresh_seconds":self.refresh_seconds.get().strip(),
                "source_mode":self.live_source_mode.get() if hasattr(self,"live_source_mode") else "CREX + Cricbuzz Deep"
            },indent=2),encoding="utf-8")
        except Exception:
            pass

    def build_live_source(self):
        cfg=self._load_api_config()
        ttk.Label(self.tab_live,text="Automatic Live Cricket Data",font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_live,text="CREX Fast Live is the primary low-latency source. Only T20 and Hundred matches are shown; Test/ODI/One-Day matches are filtered out.").pack()

        setup=ttk.LabelFrame(self.tab_live,text="Live Source Connection",padding=8)
        setup.pack(fill="x",pady=8)
        self.api_key=tk.StringVar(value=cfg.get("apikey",""))
        self.refresh_seconds=tk.StringVar(value=str(cfg.get("refresh_seconds","5")))
        self.auto_refresh=tk.BooleanVar(value=False)
        self.live_source_mode=tk.StringVar(value=cfg.get("source_mode","CREX + Cricbuzz Deep"))
        ttk.Label(setup,text="Source").grid(row=0,column=0,sticky="w")
        ttk.Combobox(setup,textvariable=self.live_source_mode,
                     values=["CREX Fast Live","CREX + Cricbuzz Deep","Direct Cricbuzz Local","CricAPI First"],
                     width=19,state="readonly").grid(row=0,column=1,padx=4)
        ttk.Label(setup,text="CricAPI Key (optional fallback)").grid(row=1,column=0,sticky="w")
        ttk.Entry(setup,textvariable=self.api_key,width=46,show="•").grid(row=1,column=1,padx=4)
        ttk.Label(setup,text="Refresh sec").grid(row=0,column=2,sticky="w",padx=(12,2))
        ttk.Combobox(setup,textvariable=self.refresh_seconds,values=["5","8","10","15","20"],width=8,state="readonly").grid(row=0,column=3,padx=4)
        ttk.Checkbutton(setup,text="Auto refresh",variable=self.auto_refresh,command=self.toggle_auto_refresh).grid(row=0,column=4,padx=8)
        ttk.Button(setup,text="SAVE SETTINGS",command=self._save_api_config).grid(row=0,column=5,padx=4)
        ttk.Button(setup,text="TEST SOURCES",command=self.test_live_sources).grid(row=1,column=5,padx=4)

        pick=ttk.LabelFrame(self.tab_live,text="Current Match",padding=8)
        pick.pack(fill="x",pady=6)
        self.live_match_var=tk.StringVar()
        self.live_match_box=ttk.Combobox(pick,textvariable=self.live_match_var,width=75,state="readonly")
        self.live_match_box.grid(row=0,column=0,columnspan=4,sticky="ew",padx=4)
        ttk.Button(pick,text="FIND LIVE MATCHES NOW",command=self.fetch_live_matches).grid(row=1,column=0,padx=4,pady=6)
        ttk.Button(pick,text="CONNECT + AUTO FILL",command=self.connect_selected_live).grid(row=1,column=1,padx=4,pady=6)
        ttk.Button(pick,text="REFRESH NOW",command=self.refresh_connected_live).grid(row=1,column=2,padx=4,pady=6)
        ttk.Button(pick,text="STOP LIVE",command=self.stop_live).grid(row=1,column=3,padx=4,pady=6)
        pick.columnconfigure(0,weight=1)

        self.live_status=tk.StringVar(value="Not connected")
        ttk.Label(self.tab_live,textvariable=self.live_status,font=("Arial",11,"bold")).pack(pady=4)

        coverage=ttk.LabelFrame(self.tab_live,text="Automatic Live Data Coverage",padding=8)
        coverage.pack(fill="x",pady=6)
        self.live_coverage_text=tk.StringVar(value="No live feed yet.")
        ttk.Label(coverage,textvariable=self.live_coverage_text,justify="left").pack(anchor="w")

        simple=ttk.LabelFrame(self.tab_live,text="Live Status",padding=10)
        simple.pack(fill="x",pady=6)
        self.live_simple_summary=tk.StringVar(value="Connect a match to begin.")
        ttk.Label(simple,textvariable=self.live_simple_summary,font=("Arial",11),justify="left").pack(anchor="w")
        ttk.Button(simple,text="Show / Hide Diagnostics",command=self.toggle_live_diagnostics).pack(anchor="e",pady=(6,0))

        self.live_raw_frame=ttk.LabelFrame(self.tab_live,text="Diagnostics (normally hidden)",padding=6)
        self.live_raw=tk.Text(self.live_raw_frame,height=14,font=("Consolas",9),wrap="word")
        self.live_raw.pack(fill="both",expand=True)
        # intentionally NOT packed by default

    def _api_client(self):
        self._save_api_config()
        return LiveCricketClient(self.api_key.get())

    def _is_completed_status(self,status):
        s=str(status or "").lower().strip()
        completed_tokens=[
            " won by ","won the match","match won","lost by","abandoned",
            "no result","drawn","match tied","cancelled","canceled",
            "awarded the match","refused to play","completed"
        ]
        return any(x in f" {s} " for x in completed_tokens)

    def _is_upcoming_status(self,status):
        s=str(status or "").lower().strip()
        return any(x in s for x in [
            "starts at","scheduled","yet to begin","not started","starts in","upcoming"
        ])

    def _is_live_match(self,m):
        # Prefer explicit API booleans when present.
        started=m.get("matchStarted",m.get("match_started",None))
        ended=m.get("matchEnded",m.get("match_ended",None))
        if started is True and ended is False:
            return True
        if ended is True:
            return False

        status=str(m.get("status") or "")
        if self._is_completed_status(status) or self._is_upcoming_status(status):
            return False

        # Short-format live status frequently contains chase/innings text.
        s=status.lower()
        live_words=[
            "need ","requires ","require ","trail by","lead by",
            "innings break","strategic timeout","drinks","rain delay",
            "delayed due to rain","bad light","live"
        ]
        if any(x in s for x in live_words):
            return True

        # A started match normally exposes at least one score object.
        scores=m.get("score") or m.get("scores") or []
        if isinstance(scores,dict): scores=[scores]
        has_score=bool(scores)
        if started is True and has_score:
            return True

        # Conservative fallback: score exists and status is not a result/upcoming text.
        if has_score and status and not self._is_completed_status(status):
            return True
        return False

    def _live_match_label(self,m):
        name=str(m.get("name") or m.get("match") or "Unknown match")
        mt=str(m.get("matchType") or m.get("match_type") or "")
        status=str(m.get("status") or "LIVE")
        scores=m.get("score") or m.get("scores") or []
        if isinstance(scores,dict):scores=[scores]
        scorebits=[]
        for sc in scores[-2:]:
            if isinstance(sc,dict):
                r=_first_value(sc,["r","runs","score"],None)
                w=_first_value(sc,["w","wickets"],None)
                o=_first_value(sc,["o","overs","over"],None)
                inn=_first_value(sc,["inning","innings","inningName"],"")
                if r is not None:
                    bit=(f"{inn}: " if inn else "")+str(r)
                    if w is not None:bit+=f"/{w}"
                    if o is not None:bit+=f" ({o})"
                    scorebits.append(bit)
        scoretxt=" | ".join(scorebits)
        return f"🔴 LIVE | {name} | {mt} | {scoretxt or status}"[:220]

    def test_live_sources(self):
        report=[]
        try:
            client=DirectCrexClient()
            h=client.health()
            for k,v in h.items():
                report.append(f"{k}: {'OK' if v.get('ok') else 'FAILED'} {v.get('error','')}")
            edge=client._find_edge()
            report.append(f"Edge renderer: {'OK' if edge else 'NOT FOUND'} {edge or ''}")
        except Exception as e:
            report.append(f"CREX direct: FAILED {e}")
        try:
            h=DirectCricbuzzClient().health()
            for k,v in h.items():
                report.append(f"{k}: {'OK' if v.get('ok') else 'FAILED'} {v.get('error','')}")
        except Exception as e:
            report.append(f"Cricbuzz direct: FAILED {e}")
        if self.api_key.get().strip():
            try:
                LiveCricketClient(self.api_key.get()).current_matches(0)
                report.append("CricAPI: OK")
            except Exception as e:
                report.append(f"CricAPI: FAILED {e}")
        else:
            report.append("CricAPI: skipped (no key)")
        self.live_raw.delete("1.0","end")
        self.live_raw.insert("1.0","\\n".join(report))
        self.live_status.set("Source health test complete.")

    def _multi_client(self):
        return MultiSourceLive(self.api_key.get())

    def _normalize_nokey_match(self,m):
        # Convert no-key live-match row into app's general match structure.
        title=str(m.get("title") or m.get("name") or "")
        teams_raw=m.get("teams") or []
        teams=[]
        score_rows=[]
        if isinstance(teams_raw,list):
            for t in teams_raw:
                if isinstance(t,dict):
                    name=str(t.get("team") or t.get("name") or "").strip()
                    run=str(t.get("run") or t.get("score") or "").strip()
                    if name: teams.append(name)
                    if run:
                        mt=re.search(r"(\\d+)(?:/(\\d+))?\\s*\\(([^)]*)\\)",run)
                        if mt:
                            score_rows.append({
                                "r":int(mt.group(1)),
                                "w":int(mt.group(2)) if mt.group(2) else 10 if "/" not in run else 0,
                                "o":mt.group(3).replace("Ovs","").replace("Ov","").strip(),
                                "inning":name
                            })
                elif isinstance(t,str):
                    teams.append(t.strip())
        return {
            "id":str(m.get("id") or ""),
            "name":title,
            "matchType":"t20" if "t20" in title.lower() or m.get("_type") in ("league","domestic","women") else "",
            "status":str(m.get("overview") or m.get("update") or "Live"),
            "teams":teams,
            "score":score_rows,
            "venue":str(m.get("place") or m.get("venue") or ""),
            "matchStarted":True,
            "matchEnded":False,
            "_source":"NoKey"
        }

    def _parse_nokey_score(self,payload):
        d=payload.get("data",{}) if isinstance(payload,dict) else {}
        live=str(d.get("liveScore") or "")
        mt=re.search(r"(.+?)\\s+(\\d+)/(\\d+)\\s*\\(([^)]*)\\)",live)
        state={}
        if mt:
            state={"team_short":mt.group(1).strip(),"score":int(mt.group(2)),
                   "wickets":int(mt.group(3)),"overs":mt.group(4).strip()}
        def num(x):
            try:return int(re.sub(r"\\D","",str(x)) or 0)
            except:return 0
        b1={"name":str(d.get("batsmanOne") or ""),"r":num(d.get("batsmanOneRun")),"b":num(d.get("batsmanOneBall"))}
        b2={"name":str(d.get("batsmanTwo") or ""),"r":num(d.get("batsmanTwoRun")),"b":num(d.get("batsmanTwoBall"))}
        bow={"name":str(d.get("bowlerOne") or ""),"r":num(d.get("bowlerOneRun")),
             "w":num(d.get("bowlerOneWickets") or d.get("bowlerOneWicket")),
             "overs":str(d.get("bowlerOneOver") or "")}
        return state,b1,b2,bow,d

    def _supported_short_format_match(self,m):
        txt=" ".join([
            str(m.get("name") or ""),
            str(m.get("status") or ""),
            str(m.get("matchType") or m.get("match_type") or "")
        ]).lower()

        # Explicitly reject formats our model is not designed for.
        reject=[
            "test match"," test ","odi","one day","one-day","one day cup",
            "one-day cup","list a","50 over","50-over","first class","first-class"
        ]
        if any(x in f" {txt} " for x in reject):
            return False

        # Explicit supported markers.
        accept=[
            "t20","twenty20","twenty 20","premier league","hundred",
            "100-ball","100 ball","100b"
        ]
        if any(x in txt for x in accept):
            return True

        # Conservative fallback: if source explicitly says t20.
        mt=str(m.get("matchType") or m.get("match_type") or "").lower()
        return mt in ("t20","t20i","hundred")

    def _make_match_key(self,m):
        source=str(m.get("_source","") or "")
        mid=str(m.get("id","") or "")
        url=str(m.get("_url","") or "")
        name=player_key(str(m.get("name","") or ""))
        stable=mid or url or name
        return f"{source}|{stable}"

    def _clear_text_widget(self,w):
        try:
            w.delete("1.0","end")
        except Exception:
            pass

    def _reset_match_scoped_state(self,match_key="",match_name=""):
        """Hard reset of every field that belongs to one specific live match."""
        self._active_match_key=str(match_key or "")
        self._active_match_name=str(match_name or "")
        self._match_generation+=1

        # invalidate all old asynchronous source associations
        self._cricbuzz_match_id=""
        self._cricbuzz_match_key=""
        self._cricbuzz_verified_name=""
        self._canonical_match_name=""
        self._canonical_teams=[]
        self._team_alias_map={}
        self._canonical_source_ids={}
        self._deep_sync_fail_count=0
        self._deep_sync_retry_after=0
        self._current_innings_id=1
        self._deep_sync_busy=False
        self._crex_fetch_inflight=False
        self._cb_commentary_inflight=False
        self._prefetched_crex_detail=None
        self._last_deep_sync=0
        self._last_cb_commentary_fetch=0
        self._active_innings_number=1
        self._last_wicket_score=0
        self._last_wicket_balls=0
        self._last_matchup_ball=-1

        # ball/innings state
        self._prev_live_score_state=None
        self._inferred_ball_results={}
        self._scoreboard_extra_events=[]
        self._scoreboard_extra_seq=0
        self._current_ball_event=None
        self._confirmed_ball_ledger={}
        self._last_confirmed_ball_by_innings={}
        self._latest_crex_deliveries=[]
        self._latest_deliveries=[]
        self.latest_cb_commentary=[]
        self.latest_commentary=[]
        self.latest_live_events=[]
        self.latest_scorecard={}
        self._online_profile_links={}
        self._online_enrich_busy=False
        self._online_enrich_match_key=""
        if getattr(self,"_xi_watch_job",None):
            try:self.root.after_cancel(self._xi_watch_job)
            except Exception:pass
        self._xi_watch_job=None
        self._xi_watch_started=time.time()
        self.live_snapshots=[]
        self.live_ball_events=[]

        # structured metadata must NEVER carry across matches
        try:self.venue.set("")
        except Exception:pass
        try:self.toss_var.set("")
        except Exception:pass
        self.toss_text=""
        self.reduction_text=""
        self.dls_text=""
        try:self.bat_team.set("")
        except Exception:pass
        try:self.bowl_team.set("")
        except Exception:pass
        try:self.current_bowler.set("")
        except Exception:pass
        try:self.striker.set("")
        except Exception:pass
        try:self.non_striker.set("")
        except Exception:pass
        for attr in ("bat_xi","bowl_xi","yet_to_bat","available_bowlers","bat_impact","bowl_impact"):
            self._clear_text_widget(getattr(self,attr,None))

        # clear visible match-specific panels immediately
        for attr in ("lc_over","lc_commentary","lc_resources","lc_par","lc_scorecard","lc_all_overs","lc_rankings"):
            self._clear_text_widget(getattr(self,attr,None))
        try:self.lc_current_ball.set("--")
        except Exception:pass
        try:self.lc_current_result.set("--")
        except Exception:pass
        try:self.lc_current_detail.set("Waiting for current match delivery.")
        except Exception:pass
        try:self.lc_match.set(match_name or "Waiting for current match data")
        except Exception:pass
        # Team names are available from the selected live event immediately.
        # This prevents blank team dropdowns while toss/XI metadata is resolving.
        try:
            _a,_b=self._split_match_sides(match_name or "")
            if _a and _b:
                self.bat_team.set(_a)
                self.bowl_team.set(_b)
        except Exception:pass
        try:self.lc_score.set("Waiting for live score…")
        except Exception:pass
        try:self.lc_conditions.set("Venue / toss / XI waiting for same-match verification")
        except Exception:pass
        try:self.live_center_status.set("New match selected • previous match state cleared")
        except Exception:pass
        try:self.live_simple_summary.set("New match selected. Fetching current-match data only.")
        except Exception:pass
        try:self.xi_auto_status.set("Automatic XI: waiting for toss/confirmed lineups from verified same-match sources…")
        except Exception:pass

    def _payload_is_current_match(self,payload):
        return (str(payload.get("match_key","") or "")==self._active_match_key and
                int(payload.get("generation",-1))==int(self._match_generation))

    def _match_core_text(self,name):
        s=" ".join(str(name or "").split())
        # Remove generic live/status decorations but keep teams + competition.
        s=re.sub(r"\|\s*live.*$","",s,flags=re.I)
        s=re.sub(r"\blive\b"," ",s,flags=re.I)
        return " ".join(s.split())

    def _split_match_sides(self,name):
        s=self._match_core_text(name)
        # Only use the opening matchup portion, before common match-number metadata.
        head=re.split(r",|\b\d+(?:st|nd|rd|th)?\s+match\b|\bmatch\b",s,1,flags=re.I)[0]
        mm=re.search(r"(.+?)\s+(?:vs\.?|v)\s+(.+)",head,re.I)
        if not mm:return ("","")
        return (" ".join(mm.group(1).split()).strip(), " ".join(mm.group(2).split()).strip())

    def _team_token_signature(self,name):
        words=[w for w in re.findall(r"[a-z0-9]+",player_key(name)) if len(w)>=2]
        stop={"the","women","woman","men","team","xi","cricket","club","cc"}
        return [w for w in words if w not in stop]

    def _team_alias_signatures(self,name):
        """
        Universal abbreviation signatures for domestic/franchise teams.
        Examples:
          Nellai Royal Kings -> nrk, rk
          SKM Salem Spartans -> skm, ss, sss
          Guyana Amazon Warriors -> gaw, aw
          Saint Lucia Kings -> slk, lk
        Sponsor prefixes do not prevent suffix-initial matching.
        """
        raw=player_key(name)
        compact=re.sub(r"[^a-z0-9]","",raw)
        toks=self._team_token_signature(name)
        sig=set()
        if compact:sig.add(compact)
        for t in toks:
            if len(t)>=2:sig.add(t)

        # initials of all contiguous token windows
        for i in range(len(toks)):
            for j in range(i+2,len(toks)+1):
                s="".join(x[0] for x in toks[i:j] if x)
                if len(s)>=2:sig.add(s)

        # initials of all tokens, plus common suffix/team-name portions.
        if toks:
            sig.add("".join(x[0] for x in toks if x))
            if len(toks)>=2:
                sig.add("".join(x[0] for x in toks[-2:]))
            if len(toks)>=3:
                sig.add("".join(x[0] for x in toks[-3:]))

        # Common source abbreviations retain digits too.
        return {x for x in sig if len(x)>=2}

    def _team_side_score(self,expected,candidate):
        e=player_key(expected); c=player_key(candidate)
        if not e or not c:return 0.0
        if e==c:return 1.0
        if e in c or c in e:
            # Exact containment is good only when the shorter item is not a
            # one-character/generic fragment.
            short=min(len(re.sub(r"\\W","",e)),len(re.sub(r"\\W","",c)))
            if short>=3:return 0.96

        ew=self._team_token_signature(expected)
        cw=self._team_token_signature(candidate)
        common=set(ew)&set(cw)
        score=0.0
        if common:
            if any(len(x)>=5 for x in common):score=max(score,0.92)
            elif any(len(x)>=4 for x in common):score=max(score,0.88)
            elif len(common)>=2:score=max(score,0.86)

        es=self._team_alias_signatures(expected)
        cs=self._team_alias_signatures(candidate)
        inter=es & cs
        if inter:
            longest=max(len(x) for x in inter)
            if longest>=4:score=max(score,0.97)
            elif longest==3:score=max(score,0.94)
            elif longest==2:score=max(score,0.82)

        # Fuzzy similarity remains secondary.
        sim=difflib.SequenceMatcher(None,re.sub(r"\\W","",e),re.sub(r"\\W","",c)).ratio()
        if sim>=.82:score=max(score,sim*0.95)
        return score

    def _team_side_match(self,expected,candidate):
        return self._team_side_score(expected,candidate)>=0.80

    def _best_team_mapping(self,source_pair,candidate_pair):
        """
        Map source team labels/abbreviations to candidate full names.
        Returns (ok, mapping, confidence).
        """
        if len(source_pair)<2 or len(candidate_pair)<2:
            return False,{},0.0
        a,b=source_pair[:2]; x,y=candidate_pair[:2]
        d1=self._team_side_score(a,x)+self._team_side_score(b,y)
        d2=self._team_side_score(a,y)+self._team_side_score(b,x)
        if d2>d1:
            total=d2; mapping={a:y,b:x}
        else:
            total=d1; mapping={a:x,b:y}
        conf=total/2.0
        return conf>=0.80,mapping,conf

    def _canonicalize_team_name(self,name):
        if not name:return ""
        k=player_key(name)
        # exact alias lookup first
        if k in getattr(self,"_team_alias_map",{}):
            return self._team_alias_map[k]
        # score against canonical teams
        best="";bs=0.0
        for t in getattr(self,"_canonical_teams",[]) or []:
            sc=self._team_side_score(name,t)
            if sc>bs:bs=sc;best=t
        return best if bs>=0.80 else str(name).strip()

    def _register_canonical_teams(self,source_name,full_teams,matched_name=""):
        """
        Lock full official team names for the active match and register every
        source abbreviation as an alias.
        """
        full=[str(x).strip() for x in (full_teams or []) if str(x).strip()]
        if len(full)<2:
            return False
        source_pair=list(self._split_match_sides(source_name or self._active_match_name))
        matched_pair=list(self._split_match_sides(matched_name or ""))
        mapping={}
        confidence=0.0

        if all(source_pair):
            ok,m,confidence=self._best_team_mapping(source_pair,full[:2])
            if ok:mapping.update(m)
        if not mapping and all(matched_pair):
            ok,m,confidence=self._best_team_mapping(matched_pair,full[:2])
            if ok:mapping.update(m)

        # The structured full names themselves are always aliases to themselves.
        self._canonical_teams=full[:2]
        for t in self._canonical_teams:
            self._team_alias_map[player_key(t)]=t
            for sig in self._team_alias_signatures(t):
                # Only register signatures when they uniquely identify one of the
                # two teams in this active match.
                other=[u for u in self._canonical_teams if u!=t and sig in self._team_alias_signatures(u)]
                if not other:self._team_alias_map[sig]=t

        for alias,canon in mapping.items():
            self._team_alias_map[player_key(alias)]=canon
            for sig in self._team_alias_signatures(alias):
                self._team_alias_map[sig]=canon

        # Also register matched-title abbreviations/full forms.
        if all(matched_pair):
            ok,m,_=self._best_team_mapping(matched_pair,self._canonical_teams)
            if ok:
                for alias,canon in m.items():
                    self._team_alias_map[player_key(alias)]=canon
                    for sig in self._team_alias_signatures(alias):
                        self._team_alias_map[sig]=canon

        self._canonical_match_name=f"{self._canonical_teams[0]} vs {self._canonical_teams[1]}"
        return True


    def _competition_guard(self,expected_name,candidate_name):
        """
        Strong negative guard for named competitions.
        If the selected match explicitly says Assam Premier League, CPL, Hundred,
        etc., an unrelated competition cannot be accepted.
        """
        e=player_key(expected_name); c=player_key(candidate_name)
        keyphrases=[
            "assam premier league","caribbean premier league","delhi premier league",
            "tamil nadu premier league","the hundred","hundred","big bash",
            "womens premier league","indian premier league","major league cricket",
            "t20 blast","super smash","sa20","ilt20","lanka premier league"
        ]
        named=[k for k in keyphrases if k in e]
        if named and not any(k in c for k in named):
            return False
        return True

    def _strict_same_match_names(self,expected_name,candidate_name):
        if not expected_name or not candidate_name:return False
        if not self._competition_guard(expected_name,candidate_name):
            return False

        ea,eb=self._split_match_sides(expected_name)
        ca,cb=self._split_match_sides(candidate_name)
        if ea and eb and ca and cb:
            direct=self._team_side_match(ea,ca) and self._team_side_match(eb,cb)
            reverse=self._team_side_match(ea,cb) and self._team_side_match(eb,ca)
            if direct or reverse:
                return True

        # Fallback only when full title similarity is very strong.
        return self._name_similarity(expected_name,candidate_name)>=0.78

    def _crex_detail_matches_selected(self,detail,selected_match):
        """
        CREX URL/ID is the primary identity for a CREX-connected match.
        The rendered title may be abbreviated, sponsor-renamed, or stale. When the
        detail came from the exact selected URL, use it rather than rejecting the
        source because another website uses different team names.
        """
        selected_url=str((selected_match or {}).get("_url","") or "")
        selected_id=str((selected_match or {}).get("id","") or "")
        if selected_url or selected_id:
            return True
        selected=str((selected_match or {}).get("name","") or self._active_match_name or "")
        title=str((detail or {}).get("title","") or "")
        if not selected or not title:
            return False
        return self._strict_same_match_names(selected,title)


    def _name_similarity(self,a,b):
        return difflib.SequenceMatcher(None,player_key(str(a or "")),player_key(str(b or ""))).ratio()

    def fetch_live_matches(self):
        try:
            mode=self.live_source_mode.get()
            self.live_status.set("Searching live matches...")
            self.root.update_idletasks()
            rows=[]; source=""

            if mode in ("CREX Fast Live","CREX + Cricbuzz Deep"):
                payload=DirectCrexClient().live_matches()
                rows=[m for m in payload.get("data",[]) if isinstance(m,dict) and self._supported_short_format_match(m)]
                source=mode
            elif mode=="Direct Cricbuzz Local":
                payload=DirectCricbuzzClient().live_matches()
                rows=payload.get("data",[])
                source="Direct Cricbuzz Local"
            else:
                # CricAPI first, then CREX fallback.
                try:
                    if not self.api_key.get().strip():raise RuntimeError("No CricAPI key")
                    payload=LiveCricketClient(self.api_key.get()).current_matches(0)
                    raw=payload.get("data",[]) if isinstance(payload,dict) else []
                    rows=[m for m in raw if isinstance(m,dict) and self._is_live_match(m)]
                    source="CricAPI"
                except Exception:
                    payload=DirectCrexClient().live_matches()
                    rows=[m for m in payload.get("data",[]) if isinstance(m,dict) and self._supported_short_format_match(m)]
                    source="CREX fallback"

            self.live_matches={}
            labels=[]
            for m in rows:
                if not isinstance(m,dict):continue
                if m.get("_source") in ("CREX","DirectCricbuzz") or self._is_live_match(m):
                    label=self._live_match_label(m)
                    mid=str(m.get("id") or "")
                    if label in self.live_matches:label+=f" | {mid[:8]}"
                    self.live_matches[label]=m
                    labels.append(label)
            self.live_match_box["values"]=labels
            if labels:self.live_match_var.set(labels[0])
            else:self.live_match_var.set("")
            self.live_status.set(f"{source}: found {len(labels)} live match(es).")
            self.live_raw.delete("1.0","end")
            self.live_raw.insert("1.0",json.dumps({"source":source,"matches":rows},indent=2)[:50000])
        except Exception as e:
            self.live_status.set("Live search failed — run TEST SOURCES")
            messagebox.showerror("Live source",str(e))

    def _poll_async_results(self):
        """Apply worker results only if they belong to the currently connected match."""
        try:
            while True:
                kind,payload=self._async_queue.get_nowait()
                if kind in ("crex_detail","metadata_fast","deep_sync","cb_commentary") and not self._payload_is_current_match(payload):
                    # An old worker finished after the user switched matches. Ignore it completely.
                    continue
                if kind=="metadata_fast":
                    self._apply_fast_metadata_payload(payload)
                elif kind=="crex_detail":
                    self._crex_fetch_inflight=False
                    self._prefetched_crex_detail=payload.get("detail")
                    if payload.get("error"):
                        self.live_status.set("CREX background refresh failed: "+str(payload["error"])[:180])
                    elif self.live_connected or payload.get("manual"):
                        self.refresh_connected_live(silent=not payload.get("manual",False))
                elif kind=="deep_sync":
                    self._deep_sync_busy=False
                    if payload.get("error"):
                        self._deep_sync_error=str(payload["error"])
                        self._deep_sync_fail_count=int(getattr(self,"_deep_sync_fail_count",0) or 0)+1
                        # Exponential-ish backoff. CREX remains fully live.
                        wait=min(120,15*(2**min(3,self._deep_sync_fail_count-1)))
                        self._deep_sync_retry_after=time.time()+wait
                        self.live_center_status.set(
                            "CREX PRIMARY LIVE • optional Cricbuzz enrichment unavailable • "
                            f"retry in {wait}s"
                        )
                        try:
                            bcnt=len(self.names(self.bat_xi));ocnt=len(self.names(self.bowl_xi))
                            self.xi_auto_status.set(
                                f"CREX primary • XI {bcnt}/11 + {ocnt}/11 • "
                                "Cricbuzz enrichment optional/unavailable"
                            )
                        except Exception:pass
                    else:
                        self._deep_sync_error=""
                        self._deep_sync_fail_count=0
                        self._deep_sync_retry_after=0
                        self._apply_deep_sync_payload(payload)
                elif kind=="cb_commentary":
                    self._cb_commentary_inflight=False
                    payload_inn=int(payload.get("innings_id") or 1)
                    current_inn=int(getattr(self,"_current_innings_id",1) or 1)
                    if payload_inn!=current_inn:
                        # Worker started for previous innings; never apply it.
                        continue
                    if not payload.get("error"):
                        incoming=self._fill_inferred_tokens(payload.get("commentary",[]) or [])
                        self._update_confirmed_ball_ledger(incoming,payload_inn)
                        self.latest_cb_commentary=self._apply_ledger_to_deliveries(incoming,payload_inn)
                        crex=self._fill_inferred_tokens(getattr(self,"_latest_crex_deliveries",[]) or [])
                        merged=self._merged_verified_deliveries(crex,self.latest_cb_commentary)
                        self._latest_deliveries=self._apply_ledger_to_deliveries(merged,payload_inn)
                        self._hydrate_live_matchup_from_sources(force_latest=True)
                        self.refresh_live_center(fast_only=True)
                        # Matchup + Coach/Prediction should follow new balls, not wait 15–20 sec.
                        self._maybe_refresh_prediction()
                elif kind=="online_enrich":
                    self._online_enrich_busy=False
                    if self._payload_is_current_match(payload):
                        for requested,rec in payload.get("results",[]):
                            self._online_player_cache[player_key(requested)]=rec
                            if rec.get("name"):
                                self._online_player_cache[player_key(rec["name"])]=rec
                        self._save_online_player_cache()
                        try:
                            self.player_online_status.set(
                                f"Online enrichment: {len(payload.get('results',[]))} new online profile(s) • "
                                f"{len(payload.get('errors',[]))} not found online • local/cache retained"
                            )
                            self.refresh_player_intelligence()
                            if self._xi_complete():
                                self.xi_auto_status.set(
                                    f"Automatic XI: 22/22 loaded • {len(payload.get('results',[]))} online profile(s) added • "
                                    f"{len(payload.get('errors',[]))} rely on local/current-match data"
                                )
                        except Exception:pass
                elif kind=="worker_status":
                    self.live_status.set(str(payload))
        except queue.Empty:
            pass
        except Exception as e:
            self.live_status.set("Async apply issue: "+str(e)[:160])
        finally:
            try:self.root.after(100,self._poll_async_results)
            except Exception:pass

    def _fetch_crex_worker(self,url,manual=False,match_key="",generation=0):
        try:
            detail=DirectCrexClient().detail(url)
            self._async_queue.put(("crex_detail",{
                "detail":detail,"manual":manual,"match_key":match_key,"generation":generation
            }))
        except Exception as e:
            self._async_queue.put(("crex_detail",{
                "detail":None,"error":str(e),"manual":manual,"match_key":match_key,"generation":generation
            }))

    def _start_crex_background(self,url,manual=False):
        if self._crex_fetch_inflight:return
        self._crex_fetch_inflight=True
        key=self._active_match_key;gen=self._match_generation
        self.live_status.set("⚡ Fetching current match CREX data in background…")
        threading.Thread(target=self._fetch_crex_worker,args=(url,manual,key,gen),daemon=True).start()

    def _commentary_fast_worker(self,match_id,innings_id,match_key,generation):
        try:
            c=DirectCricbuzzClient()
            raw=c.commentary_raw(match_id,innings_id)
            comm=c.parse_commentary(raw)
            self._async_queue.put(("cb_commentary",{
                "commentary":comm,"innings_id":int(innings_id or 1),
                "match_key":match_key,"generation":generation
            }))
        except Exception as e:
            self._async_queue.put(("cb_commentary",{
                "error":str(e),"innings_id":int(innings_id or 1),
                "match_key":match_key,"generation":generation
            }))

    def _start_fast_commentary_sync(self):
        mid=getattr(self,"_cricbuzz_match_id","")
        if not mid or self._cb_commentary_inflight:return
        if self._cricbuzz_match_key!=self._active_match_key:return
        now=time.time()
        if now-self._last_cb_commentary_fetch<2.5:return
        self._last_cb_commentary_fetch=now
        self._cb_commentary_inflight=True
        iid=int(getattr(self,"_current_innings_id",1) or 1)
        key=self._active_match_key;gen=self._match_generation
        threading.Thread(target=self._commentary_fast_worker,args=(mid,iid,key,gen),daemon=True).start()

    def _apply_crex_primary_metadata(self,detail,selected_match):
        """
        Build as much metadata as possible directly from the selected CREX page.
        This path works even when Cricbuzz has no matching event.
        """
        if not isinstance(detail,dict):
            return
        xi=detail.get("playing_xi",{}) or {}
        xi_teams=[str(k).strip() for k,v in xi.items() if str(k).strip() and v]
        bat_full=str(detail.get("batting_team_full","") or "").strip()

        # Full XI headings are the strongest team-name evidence on CREX.
        if len(xi_teams)>=2:
            self._register_canonical_teams(
                str((selected_match or {}).get("name","") or self._active_match_name),
                xi_teams[:2],
                str(detail.get("title","") or "")
            )
        elif bat_full:
            # At least lock the batting team's full label as an alias.
            short_bat=str((detail.get("state",{}) or {}).get("team_short","") or "")
            if short_bat:
                self._team_alias_map[player_key(short_bat)]=bat_full

        if detail.get("venue"):
            self.venue.set(str(detail["venue"]).strip())
        if detail.get("toss"):
            self.toss_var.set(str(detail["toss"]).strip())
            self.toss_text=str(detail["toss"]).strip()

        # Determine batting/bowling roles from the live batting-team label first.
        canonical=self._canonical_teams or xi_teams
        if bat_full:
            bat_name=self._canonicalize_team_name(bat_full)
            self.bat_team.set(bat_name)
            if len(canonical)>=2:
                other=next((x for x in canonical if not self._team_side_match(x,bat_name)), "")
                if other:self.bowl_team.set(other)
        elif len(canonical)>=2:
            short=str((detail.get("state",{}) or {}).get("team_short","") or "")
            bat_name=self._canonicalize_team_name(short) if short else ""
            if bat_name in canonical:
                self.bat_team.set(bat_name)
                other=next((x for x in canonical if x!=bat_name),"")
                if other:self.bowl_team.set(other)

        # Apply both XIs by team-role matching; never assume dictionary order.
        def xi_for(team):
            best=[];bs=0.0
            for k,v in xi.items():
                sc=self._team_side_score(team,k)
                if sc>bs:
                    bs=sc;best=v
            return list(best[:11]) if bs>=0.70 else []

        bt=self.bat_team.get().strip()
        ot=self.bowl_team.get().strip()
        bp=xi_for(bt) if bt else []
        op=xi_for(ot) if ot else []

        # If roles are not yet resolved but there are exactly two XI headings,
        # show both rather than leaving the UI blank.
        if len(xi_teams)>=2 and not bp and not op:
            first=list(xi.get(xi_teams[0],[])[:11])
            second=list(xi.get(xi_teams[1],[])[:11])
            if first:
                self.bat_team.set(self._canonicalize_team_name(xi_teams[0]))
                self.bat_xi.delete("1.0","end");self.bat_xi.insert("1.0","\n".join(first))
            if second:
                self.bowl_team.set(self._canonicalize_team_name(xi_teams[1]))
                self.bowl_xi.delete("1.0","end");self.bowl_xi.insert("1.0","\n".join(second))
        else:
            if bp:
                self.bat_xi.delete("1.0","end");self.bat_xi.insert("1.0","\n".join(bp))
            if op:
                self.bowl_xi.delete("1.0","end");self.bowl_xi.insert("1.0","\n".join(op))

        if getattr(self,"_canonical_teams",None):
            self._canonical_match_name=" vs ".join(self._canonical_teams[:2])

        try:
            bcnt=len(self.names(self.bat_xi)); ocnt=len(self.names(self.bowl_xi))
            parts=[
                "CREX primary",
                "venue ✓" if self.venue.get().strip() else "venue …",
                "toss ✓" if self.toss_var.get().strip() else "toss …",
                f"XI {bcnt}/11 + {ocnt}/11"
            ]
            self.xi_auto_status.set(" • ".join(parts))
        except Exception:
            pass

    def _team_pair_verified(self,expected_name,candidate_name):
        ea,eb=self._split_match_sides(expected_name)
        ca,cb=self._split_match_sides(candidate_name)
        if not (ea and eb and ca and cb):
            return False
        ok,_,_=self._best_team_mapping([ea,eb],[ca,cb])
        return ok


    def _apply_fast_metadata_payload(self,payload):
        if not self._payload_is_current_match(payload):
            return
        matched=str(payload.get("matched_name","") or "")
        expected=self._active_match_name
        if not (self._strict_same_match_names(expected,matched) or
                self._team_pair_verified(expected,matched)):
            return

        facts=payload.get("facts",{}) or {}
        self._cricbuzz_match_id=str(payload.get("match_id","") or self._cricbuzz_match_id)
        self._cricbuzz_match_key=self._active_match_key
        self._cricbuzz_verified_name=matched
        self._canonical_source_ids["cricbuzz"]=self._cricbuzz_match_id
        teams=[str(x).strip() for x in (facts.get("teams",[]) or []) if str(x).strip()]
        if len(teams)>=2:
            self._register_canonical_teams(expected,teams,matched)

        if facts.get("venue"):
            self.venue.set(facts["venue"])
        if facts.get("toss"):
            self.toss_var.set(facts["toss"])
            self.toss_text=facts["toss"]

        # Full team names replace short CREX abbreviations immediately.
        canonical=self._canonical_teams or teams
        if len(canonical)>=2:
            toss_low=player_key(str(facts.get("toss","") or ""))
            toss_team=""
            for t in canonical:
                if self._team_side_match(t,toss_low) or player_key(t) in toss_low:
                    toss_team=t;break

            if toss_team and ("bowl" in toss_low or "field" in toss_low):
                self.bowl_team.set(toss_team)
                self.bat_team.set(next((x for x in canonical if x!=toss_team),canonical[0]))
            elif toss_team and "bat" in toss_low:
                self.bat_team.set(toss_team)
                self.bowl_team.set(next((x for x in canonical if x!=toss_team),canonical[1]))
            else:
                # Do not infer batting role from title order. Keep canonical names
                # visible while scorecard establishes innings roles.
                cur_bat=self._canonicalize_team_name(self.bat_team.get())
                cur_bowl=self._canonicalize_team_name(self.bowl_team.get())
                if cur_bat in canonical and cur_bowl in canonical and cur_bat!=cur_bowl:
                    self.bat_team.set(cur_bat);self.bowl_team.set(cur_bowl)
                else:
                    self.bat_team.set(canonical[0]);self.bowl_team.set(canonical[1])

        # Match Facts XI.
        xi=facts.get("playing_xi",{}) or {}
        def best_list(team):
            best=[];bs=0
            for k,v in xi.items():
                sc=self._team_side_score(team,k)
                if sc>bs:bs=sc;best=v
            return best if bs>=.80 else []

        bt=self._canonicalize_team_name(self.bat_team.get().strip())
        ot=self._canonicalize_team_name(self.bowl_team.get().strip())
        if bt:self.bat_team.set(bt)
        if ot:self.bowl_team.set(ot)
        bp=best_list(bt);op=best_list(ot)
        if len(bp)>=11:
            self.bat_xi.delete("1.0","end");self.bat_xi.insert("1.0","\\n".join(bp[:11]))
        if len(op)>=11:
            self.bowl_xi.delete("1.0","end");self.bowl_xi.insert("1.0","\\n".join(op[:11]))

        pieces=[
            "teams ✓" if len(canonical)>=2 else "teams …",
            "toss ✓" if facts.get("toss") else "toss …",
            "venue ✓" if facts.get("venue") else "venue …",
            "XI ✓" if self._xi_complete() else "XI resolving…"
        ]
        try:self.xi_auto_status.set("Metadata: "+" • ".join(pieces))
        except Exception:pass
        try:
            if len(canonical)>=2:
                self.lc_match.set(f"{canonical[0]} vs {canonical[1]} | {self.venue.get() or 'venue resolving'}")
        except Exception:pass
        self.live_status.set("⚡ Universal identity resolver • "+" • ".join(pieces))


    def _deep_sync_worker(self,title,match_name,match_url,fmt,match_key,generation):
        try:
            cb_client=DirectCricbuzzClient()
            cb=cb_client.live_matches().get("data",[])

            # Build multiple identity hints. CREX display names are sometimes only
            # NRK vs SS, while the URL slug often carries the full team names.
            hints=[str(match_name or ""),str(title or "")]
            if match_url:
                slug=str(match_url).rstrip("/").split("/")[-1]
                slug=re.sub(r"-match-updates.*$","",slug,flags=re.I)
                slug=slug.replace("-vs-"," vs ").replace("-v-"," vs ").replace("-"," ")
                hints.append(" ".join(slug.split()))
            hints=[h for h in hints if h.strip()]

            best=None;best_score=0.0;best_hint=""
            rejected=[]
            for cm in cb:
                candidate=str(cm.get("name","") or "")
                local_best=0.0
                verified=False
                for hint in hints:
                    sim=self._name_similarity(hint,candidate)
                    pair=self._team_pair_verified(hint,candidate)
                    strict=self._strict_same_match_names(hint,candidate)
                    if pair or strict:
                        verified=True
                        # Team-pair verification is more important than title wording.
                        pair_bonus=0.25 if pair else 0
                        local_best=max(local_best,sim+pair_bonus)
                        if local_best>=best_score:best_hint=hint
                if verified and local_best>best_score:
                    best_score=local_best;best=cm
                elif not verified:
                    rejected.append((max([self._name_similarity(h,candidate) for h in hints] or [0]),candidate))

            if not best:
                closest=max(rejected,default=(0.0,""),key=lambda x:x[0])
                raise RuntimeError(
                    f"No canonical same-match event found. Closest: '{closest[1]}' ({closest[0]:.2f})."
                )

            mid=str(best["id"])
            matched_name=str(best.get("name","") or "")

            # Stage 1 metadata first.
            facts=cb_client.match_facts(mid)
            self._async_queue.put(("metadata_fast",{
                "match_id":mid,"facts":facts,"fmt":fmt,
                "matched_name":matched_name,
                "match_key":match_key,"generation":generation
            }))

            cb_raw=cb_client.scorecard_raw(mid)
            parsed=cb_client.parse_scorecard(cb_raw) if cb_raw else {}
            resolved_xi=cb_client.resolve_playing_xi(facts,parsed,cb_raw,matched_name)

            # Canonical structured-team verification. Short source abbreviations
            # are mapped to full structured names before rejection.
            structured_names=[]
            structured_names.extend(facts.get("teams",[]) or [])
            for inn in parsed.get("innings",[]) or []:
                for nm in (inn.get("batting_team",""),inn.get("bowling_team","")):
                    if nm:structured_names.append(nm)
            structured_names=list(dict.fromkeys(str(x).strip() for x in structured_names if str(x).strip()))

            fact_teams=[str(x).strip() for x in (facts.get("teams",[]) or []) if str(x).strip()]
            if len(fact_teams)>=2 and len(structured_names)>=2:
                ok,_,_=self._best_team_mapping(fact_teams[:2],structured_names[:2])
                if not ok:
                    raise RuntimeError("Structured scorecard team pair differs from verified Match Facts.")

            inns=parsed.get("innings",[])
            iid=int(inns[-1].get("inningsId") or len(inns) or 1) if inns else 1
            try:
                cbr=cb_client.commentary_raw(mid,iid)
                cbcomm=cb_client.parse_commentary(cbr)
            except Exception:
                cbcomm=[]

            self._async_queue.put(("deep_sync",{
                "match_id":mid,"facts":facts,"scorecard":parsed,"resolved_xi":resolved_xi,
                "commentary":cbcomm,"innings_id":iid,"fmt":fmt,
                "similarity":min(1.0,best_score),
                "matched_name":matched_name,
                "match_key":match_key,"generation":generation
            }))
        except Exception as e:
            self._async_queue.put(("deep_sync",{
                "error":str(e),"fmt":fmt,"match_key":match_key,"generation":generation
            }))


    def _start_deep_sync_async(self,detail,m,fmt):
        if self._deep_sync_busy:return
        self._deep_sync_busy=True
        self._last_deep_sync=time.time()
        key=self._active_match_key;gen=self._match_generation
        threading.Thread(
            target=self._deep_sync_worker,
            args=(detail.get("title",""),m.get("name",""),m.get("_url","") or m.get("url",""),fmt,key,gen),
            daemon=True
        ).start()

    def _apply_deep_sync_payload(self,payload):
        if not self._payload_is_current_match(payload):
            return
        expected=self._active_match_name
        matched=str(payload.get("matched_name","") or "")
        if not (self._strict_same_match_names(expected,matched) or
                self._team_pair_verified(expected,matched)):
            # Short source labels can be ambiguous. If fast metadata already locked
            # this exact Cricbuzz ID for the current generation, allow the payload.
            if str(payload.get("match_id",""))!=str(getattr(self,"_cricbuzz_match_id","") or ""):
                self.live_status.set("Structured data rejected: canonical match identity mismatch.")
                return
        facts=payload.get("facts",{}) or {}
        parsed=payload.get("scorecard",{}) or {}
        cbcomm=payload.get("commentary",[]) or []
        fmt=payload.get("fmt") or self.format_var.get()
        self._cricbuzz_match_id=str(payload.get("match_id",""))
        self._cricbuzz_match_key=self._active_match_key
        self._cricbuzz_verified_name=matched
        _payload_inn=int(payload.get("innings_id") or 1)
        self._switch_live_innings_if_needed(_payload_inn)
        self._current_innings_id=_payload_inn
        if facts.get("venue"):self.venue.set(facts["venue"])
        if facts.get("toss"):
            self.toss_var.set(facts["toss"]);self.toss_text=facts["toss"]

        teams=[str(x).strip() for x in (facts.get("teams",[]) or []) if str(x).strip()]
        if len(teams)>=2:
            self._register_canonical_teams(expected,teams,matched)
        _rx=payload.get("resolved_xi",{}) or {}
        xi_map=dict(facts.get("playing_xi",{}) or {})
        xi_map.update(_rx.get("xi",{}) or {})
        xi_sources=_rx.get("sources",{}) or {}
        xi_partial=_rx.get("partial",{}) or {}
        inns=parsed.get("innings",[]) or []
        if inns:
            curr=inns[-1]
            bt=self._canonicalize_team_name(curr.get("batting_team",""))
            ot=self._canonicalize_team_name(curr.get("bowling_team",""))
            if bt:self.bat_team.set(bt)
            if ot:self.bowl_team.set(ot)
        elif len(teams)>=2:
            toss_low=(facts.get("toss") or "").lower()
            toss_team=next((tn for tn in teams if self._team_side_match(tn,toss_low) or player_key(tn) in player_key(toss_low)),"")
            if toss_team and ("bowl" in toss_low or "field" in toss_low):
                self.bowl_team.set(toss_team)
                self.bat_team.set(next((x for x in teams if x!=toss_team),""))
            elif toss_team and "bat" in toss_low:
                self.bat_team.set(toss_team)
                self.bowl_team.set(next((x for x in teams if x!=toss_team),""))

        def lookup_xi(team):
            if team in xi_map:return xi_map[team]
            bestk=None;bs=0.0
            for k,v in xi_map.items():
                sim=self._team_side_score(team,k)
                if sim>bs:bs=sim;bestk=k
            return xi_map.get(bestk,[]) if bestk and bs>=.80 else []

        bt=self.bat_team.get().strip();ot=self.bowl_team.get().strip()
        if (not bt or not ot) and len(teams)>=2:
            # Preserve verified team identities even if toss wording was unavailable.
            bt=bt or teams[0]; ot=ot or teams[1]
            self.bat_team.set(bt); self.bowl_team.set(ot)
        bp=lookup_xi(bt);op=lookup_xi(ot)

        # If full XI is not yet available, expose scorecard-confirmed partial names
        # instead of leaving the boxes blank. Partial status is never called 11/11.
        if not bp:
            best=[]
            for k,v in xi_partial.items():
                sc=self._team_side_score(bt,k)
                if sc>=.80 and len(v)>len(best):best=v
            bp=best
        if not op:
            best=[]
            for k,v in xi_partial.items():
                sc=self._team_side_score(ot,k)
                if sc>=.80 and len(v)>len(best):best=v
            op=best

        if bp:
            self.bat_xi.delete("1.0","end");self.bat_xi.insert("1.0","\n".join(bp[:11]))
        if op:
            self.bowl_xi.delete("1.0","end");self.bowl_xi.insert("1.0","\n".join(op[:11]))

        try:
            if len(bp)>=11 and len(op)>=11:
                self.xi_auto_status.set("Automatic XI: 22/22 confirmed • metadata complete")
            else:
                self.xi_auto_status.set(
                    f"Automatic XI: batting {min(len(bp),11)}/11 • bowling {min(len(op),11)}/11 • "
                    "partial live evidence; resolver still retrying"
                )
        except Exception:pass

        bench=facts.get("bench",{}) or {}
        def lookup_bench(team):
            bestk=None;bs=0.0
            for k,v in bench.items():
                sim=self._team_side_score(team,k)
                if sim>bs:bs=sim;bestk=k
            return bench.get(bestk,[]) if bestk and bs>=.80 else []
        bbench=lookup_bench(bt);obench=lookup_bench(ot)
        if bbench:
            self.bat_impact.delete("1.0","end");self.bat_impact.insert("1.0","\n".join(bbench))
        if obench:
            self.bowl_impact.delete("1.0","end");self.bowl_impact.insert("1.0","\n".join(obench))

        self.latest_scorecard=parsed
        self._seed_online_profile_links(facts,parsed)
        self._update_confirmed_ball_ledger(cbcomm,payload.get("innings_id"))
        self.latest_cb_commentary=self._apply_ledger_to_deliveries(cbcomm,payload.get("innings_id"))

        if inns:
            curr=inns[-1]
            appeared={player_key(x.get("name","")) for x in curr.get("batsmen",[])}
            yet=[p for p in bp if player_key(p) not in appeared]
            self.yet_to_bat.delete("1.0","end")
            if yet:self.yet_to_bat.insert("1.0","\n".join(yet))

            used={player_key(x.get("name","")) for x in curr.get("bowlers",[])}
            likely=[p for p in op if self.db.player_bowling(p,fmt)]
            available=[p for p in likely if player_key(p) not in used]+[p for p in likely if player_key(p) in used]
            self.available_bowlers.delete("1.0","end")
            if available:self.available_bowlers.insert("1.0","\n".join(dict.fromkeys(available)))

        # Populate Prediction/Coach live-player fields immediately from structured data.
        self._hydrate_live_matchup_from_sources(force_latest=True)
        # Do not block UI rendering with scorecard/ranking work immediately.
        self.refresh_live_center(fast_only=True)
        self.root.after(250,self.start_online_player_enrichment)
        self._schedule_xi_watch()
        _canon=self._canonical_match_name or matched
        self.live_status.set(
            f"⚡ Live • canonical match locked: {_canon} • structured sync {time.strftime('%H:%M:%S')}"
        )

    def _xi_complete(self):
        return len(self.names(self.bat_xi))>=11 and len(self.names(self.bowl_xi))>=11

    def _schedule_xi_watch(self):
        if self._xi_complete():
            try:self.xi_auto_status.set("Automatic XI: both confirmed XIs loaded • player enrichment running/cached")
            except Exception:pass
            self.start_online_player_enrichment()
            return
        if not self.live_connected:return
        if self._xi_watch_job:
            try:self.root.after_cancel(self._xi_watch_job)
            except Exception:pass
        self._xi_watch_job=self.root.after(5000,self._xi_watch_tick)

    def _xi_watch_tick(self):
        self._xi_watch_job=None
        if not self.live_connected or self._xi_complete():
            if self._xi_complete():self.start_online_player_enrichment()
            return
        try:
            bcnt=len(self.names(self.bat_xi));ocnt=len(self.names(self.bowl_xi))
            self.xi_auto_status.set(
                f"CREX primary XI {bcnt}/11 + {ocnt}/11 • optional enrichment pending"
            )
        except Exception:pass
        # Force a fresh structured lookup without blocking UI.
        label=self.live_match_var.get();m=self.live_matches.get(label,{})
        if m and not self._deep_sync_busy and time.time()>=float(getattr(self,"_deep_sync_retry_after",0) or 0):
            fmt=self.format_var.get()
            detail=getattr(self,"_prefetched_crex_detail",None) or {"title":m.get("name","")}
            self._start_deep_sync_async(detail,m,fmt)
        self._schedule_xi_watch()

    def toggle_auto_refresh(self):
        if self.auto_refresh.get():
            self._schedule_live_refresh()
        else:
            if self.live_refresh_job:
                try:self.root.after_cancel(self.live_refresh_job)
                except:pass
                self.live_refresh_job=None

    def _schedule_live_refresh(self):
        if self.live_refresh_job:
            try:self.root.after_cancel(self.live_refresh_job)
            except:pass
        try:sec=max(5,int(self.refresh_seconds.get() or 5))
        except:sec=5
        self.live_refresh_job=self.root.after(sec*1000,self._auto_refresh_tick)

    def _auto_refresh_tick(self):
        if self.auto_refresh.get() and self.live_connected:
            try:
                label=self.live_match_var.get()
                m=self.live_matches.get(label,{})
                if m.get("_source")=="CREX" and m.get("_url"):
                    self._start_crex_background(m.get("_url"),manual=False)
                else:
                    # Non-CREX connectors retain their existing refresh path.
                    self.root.after_idle(lambda:self.refresh_connected_live(silent=True))
            except Exception:
                pass
            if self.live_connected:
                self._schedule_live_refresh()

    def stop_live(self):
        self.live_connected=False
        self._match_generation+=1
        self._active_match_key=""
        self._active_match_name=""
        self._cricbuzz_match_key=""
        self._prev_live_score_state=None
        self._inferred_ball_results={}
        self._scoreboard_extra_events=[]
        self._scoreboard_extra_seq=0
        self._current_ball_event=None
        self._confirmed_ball_ledger={}
        self._last_confirmed_ball_by_innings={}
        self.auto_refresh.set(False)
        if self.live_refresh_job:
            try:self.root.after_cancel(self.live_refresh_job)
            except:pass
            self.live_refresh_job=None
        self._prefetched_crex_detail=None
        self.live_status.set("Live connection stopped.")

    def _overs_to_balls(self, o, fmt):
        if o is None:return 0
        s=str(o).strip()
        try:
            if "." in s:
                whole,frac=s.split(".",1)
                a=int(float(whole or 0))
                b=int(re.sub(r"\\D","",frac)[:1] or 0)
                per=5 if fmt=="Hundred" else 6
                if b>=per:
                    # Some feeds may encode decimal overs rather than cricket notation.
                    return round(float(s)*per)
                return a*per+b
            val=float(s)
            # For Hundred a provider may return raw balls; >20 strongly suggests that.
            if fmt=="Hundred" and val>20:return min(100,int(val))
            return int(val)*(5 if fmt=="Hundred" else 6)
        except:return 0

    def _infer_format_from_match(self,m):
        mt=str(m.get("matchType") or m.get("match_type") or m.get("type") or "").lower()
        name=str(m.get("name") or "").lower()
        if "hundred" in mt or "hundred" in name:return "Hundred"
        return "T20"

    def _team_from_inning(self, inning, teams):
        txt=str(inning or "").lower()
        best=None
        for t in teams:
            if str(t).lower() in txt:
                best=t;break
        if best:return best
        clean=re.sub(r"\\binnings?\\b|\\binn\\b|\\b[12]\\b"," ",str(inning or ""),flags=re.I)
        clean=" ".join(clean.split())
        if clean:
            scored=sorted((difflib.SequenceMatcher(None,clean.lower(),str(t).lower()).ratio(),t) for t in teams)
            if scored and scored[-1][0]>.55:return scored[-1][1]
        return teams[0] if teams else ""

    def _score_state_from_match(self,m):
        fmt=self._infer_format_from_match(m)
        teams=m.get("teams") or []
        if isinstance(teams,str):teams=[x.strip() for x in teams.split(",") if x.strip()]
        scores=m.get("score") or m.get("scores") or []
        if isinstance(scores,dict):scores=[scores]
        current=scores[-1] if scores else {}
        prev=scores[-2] if len(scores)>1 else {}
        runs=int(_first_value(current,["r","runs","score"],0) or 0)
        wk=int(_first_value(current,["w","wickets"],0) or 0)
        ov=_first_value(current,["o","overs","over"],0)
        balls=self._overs_to_balls(ov,fmt)
        inning=_first_value(current,["inning","innings","inningName"],"")
        bat=self._team_from_inning(inning,teams)
        bowl=next((t for t in teams if str(t).lower()!=str(bat).lower()),teams[1] if len(teams)>1 else "")
        second=len(scores)>1 or bool(re.search(r"\\b2\\b",str(inning)))
        target=0
        if second and prev:
            try:target=int(_first_value(prev,["r","runs","score"],0) or 0)+1
            except:target=0
        return {"format":fmt,"teams":teams,"score":runs,"wickets":wk,"balls":balls,
                "batting_team":bat,"bowling_team":bowl,"second":second,"target":target,
                "venue":str(m.get("venue") or "")}

    def _extract_scorecard_current(self, payload, batting_team):
        data=payload.get("data",payload) if isinstance(payload,dict) else payload
        cards=[]
        if isinstance(data,list):cards=[x for x in data if isinstance(x,dict)]
        elif isinstance(data,dict):
            sc=data.get("scorecard") or data.get("scoreCard") or data.get("innings") or []
            cards=sc if isinstance(sc,list) else ([sc] if isinstance(sc,dict) else [])
        if not cards:
            # recursively look for dicts containing batting/bowling
            cards=[d for d in _walk(data) if isinstance(d,dict) and ("batting" in d or "bowling" in d)]
        if not cards:return {},[]
        # Prefer matching current batting team, else last card.
        chosen=None
        for c in cards:
            inn=str(_first_value(c,["inning","innings","inningName","team"],""))
            if batting_team and batting_team.lower() in inn.lower(): chosen=c
        chosen=chosen or cards[-1]
        return chosen,cards

    def _extract_players_from_squad(self,payload,teams):
        result={str(t):[] for t in teams}
        data=payload.get("data",payload) if isinstance(payload,dict) else payload
        blocks=data if isinstance(data,list) else []
        for block in blocks:
            if not isinstance(block,dict):continue
            tname=str(_first_value(block,["teamName","team","name"],""))
            best=next((t for t in teams if str(t).lower() in tname.lower() or tname.lower() in str(t).lower()),None)
            plist=block.get("players") or block.get("squad") or []
            names=[]
            if isinstance(plist,list):
                for p in plist:
                    if isinstance(p,str):names.append(p)
                    elif isinstance(p,dict):
                        n=_first_value(p,["name","playerName","player"],"")
                        # If API exposes playingXI flags, prefer true; otherwise include.
                        is_play=_first_value(p,["playingXI","playingXi","isPlaying","playing"],None)
                        if n and (is_play is not False):names.append(str(n))
            if best and names:result[best]=names
        return result

    def _extract_live_players(self,card):
        batting=card.get("batting") or card.get("batsmen") or card.get("batsman") or []
        bowling=card.get("bowling") or card.get("bowlers") or card.get("bowler") or []
        active=[]
        if isinstance(batting,list):
            for row in batting:
                if not isinstance(row,dict):continue
                name=str(_first_value(row,["batsman","batter","name","player"],""))
                runs=int(_first_value(row,["r","runs"],0) or 0)
                balls=int(_first_value(row,["b","balls"],0) or 0)
                dismissal=str(_first_value(row,["dismissal-text","dismissal","outDesc","status"],"")).lower()
                striker=bool(_first_value(row,["isStriker","striker","onStrike"],False))
                notout=("not out" in dismissal or dismissal in ("","batting"))
                if name and (notout or striker):
                    active.append({"name":name,"r":runs,"b":balls,"striker":striker})
        active=sorted(active,key=lambda x:(x["striker"],x["b"]),reverse=True)
        striker=next((x for x in active if x["striker"]),active[0] if active else None)
        non=next((x for x in active if striker is None or x["name"]!=striker["name"]),None)

        bowl_rows=[]
        if isinstance(bowling,list):
            for row in bowling:
                if not isinstance(row,dict):continue
                name=str(_first_value(row,["bowler","name","player"],""))
                overs=_first_value(row,["o","overs"],0)
                balls=self._overs_to_balls(overs,self.format_var.get())
                runs=int(_first_value(row,["r","runs"],0) or 0)
                wk=int(_first_value(row,["w","wickets"],0) or 0)
                current=bool(_first_value(row,["isBowling","current","bowling"],False))
                if name:bowl_rows.append({"name":name,"b":balls,"r":runs,"w":wk,"current":current})
        bowler=next((x for x in bowl_rows if x["current"]),None)
        if not bowler and bowl_rows:
            bowler=max(bowl_rows,key=lambda x:x["b"])
        return striker,non,bowler,active,bowl_rows

    def _switch_live_innings_if_needed(self,innings_no):
        """
        Hard-separate innings-specific live state. Prevents first-innings
        commentary/players from leaking into the chase.
        """
        try:inn=int(innings_no or 1)
        except:inn=1
        if inn==getattr(self,"_active_innings_number",1):
            return False
        self._active_innings_number=inn
        self._current_innings_id=inn
        self._last_wicket_score=0
        self._last_wicket_balls=0
        self._prev_live_score_state=None
        self.live_snapshots=[]
        self.live_ball_events=[]
        self.latest_cb_commentary=[]
        self._latest_deliveries=[]
        self._latest_crex_deliveries=[]
        self._current_ball_event=None
        self._last_matchup_ball=-1
        # Ledger is keyed by innings, so keep it, but visible player state must reset.
        for var in (self.striker,self.non_striker,self.current_bowler):
            try:var.set("")
            except Exception:pass
        for var in (self.striker_runs,self.striker_balls,self.non_runs,self.non_balls,
                    self.bowler_runs_live,self.bowler_balls_live,self.bowler_wkts_live,
                    self.part_runs,self.part_balls,self.since_boundary,self.since_wicket):
            try:var.set("0")
            except Exception:pass
        return True

    def _update_snapshot_momentum(self,state):
        snap={"score":state["score"],"wickets":state["wickets"],"balls":state["balls"],"ts":time.time()}
        if self.live_snapshots:
            prev=self.live_snapshots[-1]
            db=snap["balls"]-prev["balls"]; dr=snap["score"]-prev["score"]; dw=snap["wickets"]-prev["wickets"]
            if db>=0 and db<=6 and dr>=0 and dw>=0:
                per_runs=dr if db==1 else None
                self.live_ball_events.append({"balls":db,"runs":dr,"wickets":dw,"single":db==1,
                                              "boundary":(db==1 and dr>=4),"ts":snap["ts"]})
                self.live_ball_events=self.live_ball_events[-40:]
            if dw>0:
                # New partnership begins after the wicket event.
                self._last_wicket_score=snap["score"]
                self._last_wicket_balls=snap["balls"]

        self.live_snapshots.append(snap)
        self.live_snapshots=self.live_snapshots[-40:]

        # Partnership from scoreboard is exact enough once we know the last wicket score.
        if snap["wickets"]==0:
            self.part_runs.set(str(snap["score"]))
            self.part_balls.set(str(snap["balls"]))
        elif getattr(self,"_last_wicket_score",0)>0 or getattr(self,"_last_wicket_balls",0)>0:
            self.part_runs.set(str(max(0,snap["score"]-self._last_wicket_score)))
            self.part_balls.set(str(max(0,snap["balls"]-self._last_wicket_balls)))

        recent=self.live_ball_events[-12:]
        boundaries=sum(1 for e in recent if e.get("boundary"))
        wickets=sum(int(e.get("wickets",0)) for e in recent)
        last_runs=sum(int(e.get("runs",0)) for e in recent[-6:])
        if recent:
            self.boundaries12.set(str(boundaries))
            self.wickets12.set(str(wickets))
            self.last.set(str(last_runs))

        # Balls since boundary/wicket using actual legal-ball snapshots.
        sb=0
        for e in reversed(self.live_ball_events):
            if e.get("boundary"):break
            if e.get("balls",0)>0: sb+=int(e.get("balls",0))
        sw=0
        for e in reversed(self.live_ball_events):
            if e.get("wickets",0):break
            if e.get("balls",0)>0: sw+=int(e.get("balls",0))
        self.since_boundary.set(str(sb))
        self.since_wicket.set(str(sw if snap["wickets"] else snap["balls"]))


    def connect_selected_live(self):
        label=self.live_match_var.get()
        if not label or label not in self.live_matches:
            messagebox.showerror("Live match","Fetch and select a current match first.");return
        m=self.live_matches[label]
        match_key=self._make_match_key(m)
        self._reset_match_scoped_state(match_key,str(m.get("name") or label))
        self.live_connected=True
        self.refresh_connected_live()
        if self.auto_refresh.get():self._schedule_live_refresh()

    def _infer_active_batters_from_scorecard(self,current):
        """
        Returns (striker_candidate, non_striker_candidate) from scorecard rows.
        Cricbuzz often marks the two current batters as 'not out'. If only one
        is explicit, fall back to the most recent undismissed/last batting rows.
        """
        bats=current.get("batsmen",[]) or []
        active=[]
        for x in bats:
            if not isinstance(x,dict):continue
            name=str(x.get("name") or "").strip()
            if not name:continue
            dismissal=str(x.get("dismissal") or "").strip().lower()
            # Active batter is usually "not out"; empty can occur before dismissal text is written.
            if dismissal in ("not out","batting","") or "not out" in dismissal:
                active.append(x)
        # If parser only exposes one not-out batter, use latest scorecard row not clearly dismissed.
        if len(active)<2:
            for x in reversed(bats):
                if x in active:continue
                dismissal=str(x.get("dismissal") or "").strip().lower()
                clearly_out=bool(dismissal and "not out" not in dismissal and dismissal!="batting")
                if not clearly_out:
                    active.append(x)
                if len(active)>=2:break
        # Final conservative fallback: last two scorecard entries. This is only used
        # to prevent the entire model from stopping; live coverage will remain lower.
        if len(active)<2:
            for x in reversed(bats):
                if x not in active:
                    active.append(x)
                if len(active)>=2:break
        return (active[0] if active else None, active[1] if len(active)>1 else None)

    def refresh_connected_live(self,silent=False):
        label=self.live_match_var.get()
        if label not in self.live_matches:
            if not silent:messagebox.showerror("Live match","Select a live match first.")
            return
        try:
            m=self.live_matches[label]
            selected_key=self._make_match_key(m)
            if selected_key!=self._active_match_key:
                # Selection changed without a full reconnect: hard-isolate it now.
                self._reset_match_scoped_state(selected_key,str(m.get("name") or label))
            source=m.get("_source","")
            mode=self.live_source_mode.get()

            if source=="CREX":
                detail=getattr(self,"_prefetched_crex_detail",None)
                if detail is None:
                    self._start_crex_background(m.get("_url"),manual=not silent)
                    return
                self._prefetched_crex_detail=None
                st=detail.get("state",{})
                if not st:
                    # CREX markup changed or score line was not recognized.
                    # Keep the live engine running by falling back to Cricbuzz.
                    cb_matches=DirectCricbuzzClient().live_matches().get("data",[])
                    target=player_key(m.get("name","") or detail.get("title",""))
                    best=None; best_score=0
                    selected_name=str(m.get("name","") or "")
                    for cm in cb_matches:
                        candidate=str(cm.get("name","") or "")
                        sim=difflib.SequenceMatcher(None,target,player_key(candidate)).ratio()
                        if self._strict_same_match_names(selected_name,candidate) and sim>best_score:
                            best_score=sim; best=cm
                    if best:
                        cb_raw=DirectCricbuzzClient().scorecard_raw(best["id"])
                        cb_sc=DirectCricbuzzClient().parse_scorecard(cb_raw) if cb_raw else {}
                        cb_inns=cb_sc.get("innings",[])
                        if cb_inns:
                            cur=cb_inns[-1]
                            fmt="Hundred" if "hundred" in str(best.get("name","")).lower() else "T20"
                            self.format_var.set(fmt)
                            score=int(cur.get("runs",0)); wk=int(cur.get("wickets",0))
                            balls=self._overs_to_balls(cur.get("overs",0),fmt)
                            self.score.set(str(score)); self.wkts.set(str(wk)); self.balls.set(str(balls))
                            self.bat_team.set(cur.get("batting_team","")); self.bowl_team.set(cur.get("bowling_team",""))
                            self._update_snapshot_momentum({"score":score,"wickets":wk,"balls":balls})
                            note=self._auto_predict_if_ready()
                            self.live_status.set(f"⚡ CREX FALLBACK → CRICBUZZ • {score}/{wk} • {note}")
                            self.live_raw.delete("1.0","end")
                            self.live_raw.insert("1.0",
                                "CREX parser could not read the score; Cricbuzz fallback kept live updates running.")
                            return
                    raise RuntimeError("CREX rendered page still had no recognized score and Cricbuzz fallback also failed. Run TEST SOURCES and check Edge renderer.")

                _selected_name=str(m.get("name","") or "")
                fmt="Hundred" if ("100b" in _selected_name.lower() or "hundred" in _selected_name.lower()
                                  or "100b" in detail.get("title","").lower() or "hundred" in detail.get("title","").lower()) else "T20"
                _detail_same_match=self._crex_detail_matches_selected(detail,m)
                self.format_var.set(fmt)

                # The selected CREX page is now the PRIMARY metadata source.
                # Cricbuzz is optional enrichment only.
                if _detail_same_match:
                    self._apply_crex_primary_metadata(detail,m)

                # Same-match CREX metadata is useful as a provisional fallback.
                # Verified Cricbuzz Match Facts will supersede it when available.
                self.toss_text=getattr(self,"toss_text","")
                if _detail_same_match:
                    if detail.get("venue") and not self.venue.get().strip():
                        self.venue.set(str(detail.get("venue")).strip())
                    if detail.get("toss") and not self.toss_var.get().strip():
                        self.toss_var.set(str(detail.get("toss")).strip())
                        self.toss_text=str(detail.get("toss")).strip()

                default_total=100 if fmt=="Hundred" else 120
                red=detail.get("reduced_overs")
                if fmt=="T20" and red:
                    self.innings_total_balls=int(red)*6
                    self.innings_limit_var.set(str(red))
                    self.reduction_text=detail.get("reduction_text") or f"Reduced to {red} overs"
                else:
                    self.innings_total_balls=default_total
                    self.innings_limit_var.set("100 balls" if fmt=="Hundred" else "20")
                    self.reduction_text=detail.get("reduction_text") or ""

                if detail.get("pp_overs") is not None and fmt=="T20":
                    self.powerplay_balls=int(round(float(detail["pp_overs"])*6))
                    self.powerplay_var.set(str(detail["pp_overs"]))
                else:
                    self.powerplay_balls=25 if fmt=="Hundred" else 36
                    self.powerplay_var.set("25 balls" if fmt=="Hundred" else "6")

                if detail.get("revised_target"):
                    self.target.set(str(detail["revised_target"]))
                    self.dls_text=f"Revised target {detail['revised_target']}"
                else:
                    self.dls_text=""

                if _detail_same_match:
                    self.latest_commentary=detail.get("commentary",[])
                    self.latest_live_events=detail.get("live_events",[])
                else:
                    # Score state can be fresh while SPA-rendered commentary is stale.
                    self.latest_commentary=[]
                    self.latest_live_events=[]

                score=int(st.get("score",0)); wk=int(st.get("wickets",0))
                balls=self._overs_to_balls(st.get("overs",0),fmt)
                _prev_score_state=getattr(self,"_prev_live_score_state",None)
                self.score.set(str(score)); self.wkts.set(str(wk)); self.balls.set(str(balls))
                if st.get("target"):self.target.set(str(st["target"]))
                _is_second=(st.get("need") is not None) or bool(st.get("target"))
                if _is_second:
                    self.innings_var.set("2nd Innings")
                    self._switch_live_innings_if_needed(2)
                else:
                    self._switch_live_innings_if_needed(1)

                if _detail_same_match and (self.names(self.bat_xi) or self.names(self.bowl_xi)):
                    self._schedule_xi_watch()
                    self.root.after(300,self.start_online_player_enrichment)
                bats=(detail.get("batters",[]) if _detail_same_match else [])
                if bats:
                    self.striker.set(bats[0]["name"]); self.striker_runs.set(str(bats[0]["runs"])); self.striker_balls.set(str(bats[0]["balls"]))
                    if len(bats)>1:
                        self.non_striker.set(bats[1]["name"]); self.non_runs.set(str(bats[1]["runs"])); self.non_balls.set(str(bats[1]["balls"]))
                bw=(detail.get("bowler") if _detail_same_match else None)
                if bw:
                    self.current_bowler.set(bw["name"]); self.bowler_runs_live.set(str(bw["runs"]))
                    self.bowler_wkts_live.set(str(bw["wickets"]))
                    self.bowler_balls_live.set(str(self._overs_to_balls(bw["overs"],fmt)))
                ps=(detail.get("partnership",{}) if _detail_same_match else {})
                if ps:
                    self.part_runs.set(str(ps.get("runs",0))); self.part_balls.set(str(ps.get("balls",0)))

                # CREX primary metadata/XI was applied above. Do not overwrite
                # it using dictionary order or short display abbreviations.

                deliveries=(detail.get("deliveries",[]) if _detail_same_match else [])
                # Recover missing outcome tokens directly from official score/wicket/ball deltas.
                self._apply_score_delta_inference(
                    _prev_score_state,score,wk,balls,deliveries,
                    (detail.get("live_events",[]) if _detail_same_match else [])
                )
                deliveries=self._fill_inferred_tokens(deliveries)
                structured=getattr(self,"latest_cb_commentary",[]) or []
                structured=self._apply_ledger_to_deliveries(self._fill_inferred_tokens(structured))
                # Merge feeds, then apply immutable ledger so confirmed balls never regress.
                self._latest_crex_deliveries=deliveries
                merged=self._merged_verified_deliveries(deliveries,structured)
                self._latest_deliveries=self._apply_ledger_to_deliveries(merged)
                self._hydrate_live_matchup_from_sources()
                metric_deliveries=self._latest_deliveries
                if deliveries and not self.current_bowler.get().strip():
                    self.current_bowler.set(self._delivery_bowler_name(deliveries[-1]))
                l6,l12=self._recent_ball_metrics(metric_deliveries)
                if deliveries:
                    self.last.set(str(l6["runs"]))
                    self.boundaries12.set(str(l12["boundaries"]))
                    self.wickets12.set(str(l12["wickets"]))
                    sb=0
                    for d in reversed(metric_deliveries):
                        if d.get("boundary"):break
                        sb+=1
                    sw=0
                    for d in reversed(metric_deliveries):
                        if d.get("wicket"):break
                        sw+=1
                    self.since_boundary.set(str(sb)); self.since_wicket.set(str(sw))

                self._update_snapshot_momentum({"score":score,"wickets":wk,"balls":balls})
                self._hydrate_live_matchup_from_sources(force_latest=True)
                # Official scoreboard consistency overrides commentary artefacts.
                if wk==0:
                    self.wickets12.set("0")
                    self.since_wicket.set(str(balls))
                    self.part_runs.set(str(score))
                    self.part_balls.set(str(balls))

                # STRUCTURED DEEP SYNC runs entirely in a worker thread.
                # It can no longer freeze tab switching or mark Windows "Not Responding".
                now=time.time()
                last_deep=getattr(self,"_last_deep_sync",0)
                _retry_after=float(getattr(self,"_deep_sync_retry_after",0) or 0)
                need_deep=(now>=_retry_after and
                           (now-last_deep>30 or not self.names(self.bat_xi) or not self.names(self.bowl_xi)
                            or not self.venue.get().strip() or not getattr(self,"latest_scorecard",None)))
                if need_deep and not self._deep_sync_busy:
                    self._start_deep_sync_async(detail,m,fmt)

                _safe_detail=detail if _detail_same_match else {"deliveries":[],"commentary":[],"live_events":[]}
                self.refresh_live_center(_safe_detail,fast_only=True)
                self._start_fast_commentary_sync()
                pred_note=self._maybe_refresh_prediction()

                # Match-day status only. Detailed technical reports are generated
                # only when the user opens their analysis tab.
                self.live_simple_summary.set(
                    f"{self.bat_team.get() or 'Batting'} {score}/{wk} after {st.get('overs','--')} overs\n"
                    f"Current: {self.striker.get() or '--'} / {self.non_striker.get() or '--'} • "
                    f"Bowler: {self.current_bowler.get() or '--'}\n"
                    f"Live Center updates continuously. Analysis reports update on demand."
                )
                self.home_status.set(
                    f"LIVE • {self.bat_team.get() or '--'} {score}/{wk} • "
                    f"{st.get('overs','--')} overs • {time.strftime('%H:%M:%S')}"
                )
                self.live_coverage_text.set(
                    "Fast lane: score/current ball every refresh • matchup/commentary ~2–5s • "
                    "scorecard ~15s background • prediction follows each new ball."
                )
                self._start_fast_commentary_sync()
                self.live_connected=True
                _meta_bits=[]
                if self.venue.get().strip():_meta_bits.append("venue")
                if self.toss_var.get().strip():_meta_bits.append("toss")
                if self.names(self.bat_xi) or self.names(self.bowl_xi):_meta_bits.append("XI")
                self.live_status.set(
                    f"⚡ CREX PRIMARY • {time.strftime('%H:%M:%S')} • {score}/{wk} after {balls} balls"
                    + (f" • metadata: {','.join(_meta_bits)}" if _meta_bits else " • metadata limited by source")
                    + (f" • {pred_note}" if pred_note else "")
                )
                return

            # Existing direct Cricbuzz behavior
            if source=="DirectCricbuzz":
                client=DirectCricbuzzClient()
                sc_raw=client.scorecard_raw(m.get("id"))
                if not sc_raw:raise RuntimeError("Could not parse Cricbuzz scorecard.")
                sc=client.parse_scorecard(sc_raw)
                inns=sc.get("innings",[])
                if not inns:raise RuntimeError("No innings data.")
                current=inns[-1]
                self._switch_live_innings_if_needed(max(1,len(inns)))
                fmt="Hundred" if "hundred" in str(m.get("name","")).lower() else "T20"
                self.format_var.set(fmt)
                score=current.get("runs",0);wk=current.get("wickets",0)
                balls=self._overs_to_balls(current.get("overs",0),fmt)
                self.score.set(str(score));self.wkts.set(str(wk));self.balls.set(str(balls))
                self.bat_team.set(current.get("batting_team",""));self.bowl_team.set(current.get("bowling_team",""))
                self._update_snapshot_momentum({"score":score,"wickets":wk,"balls":balls})
                note=self._auto_predict_if_ready()
                self.live_status.set(f"🔴 CRICBUZZ LIVE • {score}/{wk} • {note}")
                return

            # CricAPI path
            mid=str(m.get("id") or "")
            state=self._score_state_from_match(m)
            scorecard={};squad={}
            try:scorecard=self._api_client().scorecard(mid)
            except Exception as e:scorecard={"_error":str(e)}
            try:squad=self._api_client().squad(mid)
            except Exception as e:squad={"_error":str(e)}
            self.autofill_from_live(m,state,scorecard,squad)
            note=self._auto_predict_if_ready()
            self.live_status.set(f"🔴 CRICAPI LIVE • {state['score']}/{state['wickets']} • {note}")
        except Exception as e:
            self.live_status.set("Live refresh failed — use TEST SOURCES")
            if not silent:messagebox.showerror("Live refresh",str(e))

    def _recent_ball_metrics(self,deliveries):
        vals=[d for d in (deliveries or []) if isinstance(d,dict) and d.get("verified_outcome",True)]
        def pack(lastn):
            x=vals[-lastn:] if vals else []
            legal=[d for d in x if d.get("legal_delivery",
                        not (("WD" in str(d.get("token","")).upper()) or ("NB" in str(d.get("token","")).upper())))]
            n=len(legal)
            runs=sum(int(d.get("runs",0) or 0) for d in x)
            dots=sum(1 for d in legal if d.get("dot"))
            bnds=sum(1 for d in legal if d.get("boundary"))
            fours=sum(1 for d in legal if int(d.get("runs",0) or 0)==4)
            sixes=sum(1 for d in legal if int(d.get("runs",0) or 0)==6)
            wk=sum(1 for d in x if d.get("wicket"))
            scoring=sum(1 for d in legal if int(d.get("runs",0) or 0)>0)
            complete=(n>=lastn)
            return {
                "balls":n,"runs":runs,"dots":dots,"boundaries":bnds,"fours":fours,"sixes":sixes,
                "wickets":wk,
                "dot_pct":round(dots*100/n,1) if n else None,
                "boundary_pct":round(bnds*100/n,1) if n else None,
                "scoring_pct":round(scoring*100/n,1) if n else None,
                "rr":round(runs*6/n,2) if n else None,
                "complete":complete,
                "verified":bool(n)
            }
        return pack(6),pack(12)

    def _resource_lines(self,names,fmt,kind):
        rows=[]
        for p in (names or []):
            if kind=="bat":
                rt=self.model.batter_score(p,fmt)
                form=self.db.recent_batting_form(p,fmt)
                if rt:
                    rows.append(
                        f"{p}: Rating {rt[0]}/100 | SR {rt[1]['sr']:.1f} | "
                        f"Death SR {rt[1]['death_sr']:.1f} | "
                        + (f"Recent SR {form['sr']:.1f}" if form else "Recent form n/a")
                    )
                else:
                    rows.append(f"{p}: historical batting data not found")
            else:
                rt=self.model.bowler_score(p,fmt)
                form=self.db.recent_bowling_form(p,fmt)
                if rt:
                    rows.append(
                        f"{p}: Rating {rt[0]}/100 | Econ {rt[1]['econ']:.2f} | "
                        f"Death Econ {rt[1]['death_econ']:.2f} | "
                        + (f"Recent Econ {form['econ']:.2f}" if form else "Recent form n/a")
                    )
                else:
                    rows.append(f"{p}: historical bowling data not found")
        return rows

    def _technical_indices(self,last6,last12,score,wkts,balls,target=None,total_balls=120):
        if not last12.get("verified"):
            return {
                "dot_pressure":None,"boundary_threat":None,"wicket_pressure":None,
                "acceleration_index":None,"chase_pressure_index":None
            }
        dot=float(last12.get("dot_pct") or 0)
        bnd=float(last12.get("boundary_pct") or 0)
        wp=min(100.0,float(last12.get("wickets",0))*35.0)
        crr=score*6/max(1,balls)
        recent=float(last12.get("rr") or crr)
        accel=max(0.0,min(100.0,50.0+(recent-crr)*6.0))
        chase=None
        if target and balls<total_balls:
            req=max(0,target-score)*6/max(1,total_balls-balls)
            chase=max(0.0,min(100.0,50.0+(req-crr)*8.0+wkts*2.0))
        return {
            "dot_pressure":round(dot,1),
            "boundary_threat":round(min(100.0,bnd*2.5),1),
            "wicket_pressure":round(wp,1),
            "acceleration_index":round(accel,1),
            "chase_pressure_index":round(chase,1) if chase is not None else None
        }

    def _auto_predict_if_ready(self,lightweight=False):
        try:
            bx=self.names(self.bat_xi)
            ox=self.names(self.bowl_xi)
            striker=self.striker.get().strip()
            non=self.non_striker.get().strip()
            bowler=self.current_bowler.get().strip()

            # LIVE-FIRST MODE:
            # Do not stop merely because CREX exposes only one of the two XIs.
            # Build conservative partial resource lists from known live players.
            partial_notes=[]
            if not striker:
                return "waiting for striker"

            if not non:
                self.non_striker.set("Unknown non-striker")
                self.non_runs.set("0"); self.non_balls.set("0")
                non="Unknown non-striker"
                partial_notes.append("non-striker unavailable")

            if not bowler:
                # With no bowler at all, we can still give score-state projection,
                # but live matchup confidence is low.
                self.current_bowler.set("Unknown bowler")
                bowler="Unknown bowler"
                partial_notes.append("current bowler unavailable")

            if not bx:
                bx=[p for p in [striker,non] if p and not p.lower().startswith("unknown")]
                if bx:
                    self.bat_xi.delete("1.0","end")
                    self.bat_xi.insert("1.0","\n".join(bx))
                partial_notes.append("batting XI partial")

            if not ox:
                ox=[bowler] if bowler and not bowler.lower().startswith("unknown") else []
                if ox:
                    self.bowl_xi.delete("1.0","end")
                    self.bowl_xi.insert("1.0","\n".join(ox))
                partial_notes.append("bowling XI partial")

            # Model requires non-empty lists. Use neutral placeholder only as a final
            # conservative fallback; player-history coverage will remain near zero.
            if not bx:
                bx=["Unknown batter"]
            if not ox:
                ox=["Unknown bowler"]

            self.live_predict()

            if hasattr(self,"coach_out"):
                main=self.output.get("1.0","end").strip()
                self.coach_out.delete("1.0","end")
                self.coach_out.insert("1.0",main)
            if not lightweight and hasattr(self,"technical_out"):
                self.refresh_all_analysis_tabs()
            elif lightweight:
                self._maybe_refresh_heavy_tabs()

            if partial_notes:
                return "prediction refreshed • PARTIAL LIVE: "+", ".join(partial_notes)
            return "prediction refreshed • FULL LIVE"
        except Exception:
            return "prediction waiting for usable live fields"

    def autofill_from_live(self,m,state,scorecard,squad):
        self.format_var.set(state["format"])
        self.venue.set(state["venue"])
        self.bat_team.set(state["batting_team"])
        self.bowl_team.set(state["bowling_team"])
        self.innings_var.set("2nd Innings" if state["second"] else "1st Innings")
        self.score.set(str(state["score"])); self.wkts.set(str(state["wickets"])); self.balls.set(str(state["balls"]))
        if state["target"]:self.target.set(str(state["target"]))

        auto_fields=["format","venue","teams","score","wickets","balls","innings"]
        teams=state["teams"]
        squad_map=self._extract_players_from_squad(squad,teams)
        batlist=squad_map.get(state["batting_team"],[])
        bowllist=squad_map.get(state["bowling_team"],[])
        if batlist:
            self.bat_xi.delete("1.0","end"); self.bat_xi.insert("1.0","\n".join(batlist[:11])); auto_fields.append("batting XI/squad")
        if bowllist:
            self.bowl_xi.delete("1.0","end"); self.bowl_xi.insert("1.0","\n".join(bowllist[:11])); auto_fields.append("bowling XI/squad")

        card,cards=self._extract_scorecard_current(scorecard,state["batting_team"])
        striker,non,bowler,active,bowl_rows=self._extract_live_players(card)
        if striker:
            self.striker.set(striker["name"]); self.striker_runs.set(str(striker["r"])); self.striker_balls.set(str(striker["b"]))
            auto_fields+=["striker","striker live figures"]
        if non:
            self.non_striker.set(non["name"]); self.non_runs.set(str(non["r"])); self.non_balls.set(str(non["b"]))
            auto_fields+=["non-striker","non-striker live figures"]
        if bowler:
            self.current_bowler.set(bowler["name"]); self.bowler_runs_live.set(str(bowler["r"]))
            self.bowler_balls_live.set(str(bowler["b"])); self.bowler_wkts_live.set(str(bowler["w"]))
            auto_fields+=["current bowler","bowler figures"]

        if striker and non:
            self.part_runs.set(str(striker["r"]+non["r"]))
            self.part_balls.set(str(striker["b"]+non["b"]))
            auto_fields.append("partnership estimate")

        # Remaining batters = XI minus anyone already appearing in scorecard batting/current active.
        bx=self.names(self.bat_xi)
        appeared=[]
        batting=card.get("batting") or card.get("batsmen") or []
        if isinstance(batting,list):
            for row in batting:
                if isinstance(row,dict):
                    n=str(_first_value(row,["batsman","batter","name","player"],""))
                    if n:appeared.append(n)
        yet=[]
        for p in bx:
            if not any(identity_score(p,a)>=.90 for a in appeared):
                yet.append(p)
        if yet:
            self.yet_to_bat.delete("1.0","end"); self.yet_to_bat.insert("1.0","\n".join(yet))
            auto_fields.append("yet to bat")

        # Available bowlers: XI players with bowling history; scorecard quotas are provider-specific.
        ox=self.names(self.bowl_xi)
        avail=[p for p in ox if self.db.player_bowling(p,self.format_var.get())]
        if avail:
            self.available_bowlers.delete("1.0","end"); self.available_bowlers.insert("1.0","\n".join(avail))
            auto_fields.append("likely bowling resources")

        self._update_snapshot_momentum(state)
        self.refresh_dropdowns()

        # Coverage statement: what came directly/derived from API.
        required=["format","venue","teams","score","wickets","balls","innings","striker","non-striker","current bowler",
                  "striker live figures","non-striker live figures","bowler figures","yet to bat","likely bowling resources"]
        present=sum(1 for x in required if x in auto_fields)
        pct=round(present/len(required)*100)
        missing=[x for x in required if x not in auto_fields]
        msg=f"Auto-filled {present}/{len(required)} critical live groups = {pct}% API/derived coverage."
        if missing:msg+="\nManual fallback still needed for: "+", ".join(missing)+"."
        msg+="\nMomentum from score refresh deltas is exact only when refreshes capture one legal ball at a time; ball-by-ball provider access improves this."
        self.live_coverage_text.set(msg)
    def build_live_center(self):
        hdr=ttk.Frame(self.tab_live_center)
        hdr.pack(fill="x",pady=(0,6))
        ttk.Label(hdr,text="LIVE MATCH ANALYST CENTER",font=("Arial",20,"bold")).pack(side="left")
        ttk.Label(hdr,text="  •  Score • Current over • Commentary • Match conditions",
                  font=("Arial",10)).pack(side="left",padx=8)
        ttk.Button(hdr,text="REFRESH DETAILS",command=lambda:self.refresh_live_center(fast_only=False)).pack(side="right",padx=4)

        self.live_center_status=tk.StringVar(value="Connect a live match from AUTO LIVE DATA.")
        ttk.Label(self.tab_live_center,textvariable=self.live_center_status,
                  font=("Arial",11,"bold")).pack(anchor="w",pady=(0,5))

        sub=ttk.Notebook(self.tab_live_center)
        sub.pack(fill="both",expand=True)
        self.lc_dash_tab=ttk.Frame(sub,padding=6)
        self.lc_scorecard_tab=ttk.Frame(sub,padding=6)
        self.lc_overs_tab=ttk.Frame(sub,padding=6)
        self.lc_rankings_tab=ttk.Frame(sub,padding=6)
        sub.add(self.lc_dash_tab,text="Dashboard")
        sub.add(self.lc_scorecard_tab,text="Full Scorecard")
        sub.add(self.lc_overs_tab,text="Over-by-Over")
        sub.add(self.lc_rankings_tab,text="Live Player Rankings")

        info=ttk.LabelFrame(self.lc_dash_tab,text="MATCH NOW",padding=8)
        info.pack(fill="x",pady=4)
        self.lc_match=tk.StringVar(value="--")
        self.lc_score=tk.StringVar(value="--")
        self.lc_conditions=tk.StringVar(value="--")
        ttk.Label(info,textvariable=self.lc_match,font=("Arial",13,"bold")).pack(anchor="w")
        ttk.Label(info,textvariable=self.lc_score,font=("Arial",17,"bold")).pack(anchor="w",pady=2)
        ttk.Label(info,textvariable=self.lc_conditions,font=("Arial",10)).pack(anchor="w")

        ballbox=ttk.LabelFrame(self.lc_dash_tab,text="CURRENT / LATEST BALL",padding=8)
        ballbox.pack(fill="x",pady=4)
        self.lc_current_ball=tk.StringVar(value="--")
        self.lc_current_result=tk.StringVar(value="--")
        self.lc_current_detail=tk.StringVar(value="Waiting for live delivery.")
        ttk.Label(ballbox,textvariable=self.lc_current_ball,font=("Arial",15,"bold")).pack(side="left",padx=(4,18))
        ttk.Label(ballbox,textvariable=self.lc_current_result,font=("Arial",24,"bold")).pack(side="left",padx=(0,20))
        ttk.Label(ballbox,textvariable=self.lc_current_detail,font=("Arial",11)).pack(side="left",fill="x",expand=True)

        mid=ttk.Frame(self.lc_dash_tab); mid.pack(fill="both",expand=True,pady=4)
        left=ttk.LabelFrame(mid,text="CURRENT OVER — BALL BY BALL",padding=6)
        right=ttk.LabelFrame(mid,text="LIVE COMMENTARY / REVIEW STATUS",padding=6)
        left.pack(side="left",fill="both",expand=True,padx=(0,4))
        right.pack(side="left",fill="both",expand=True,padx=(4,0))
        self.lc_over=tk.Text(left,height=12,font=("Consolas",11),wrap="word")
        self.lc_over.pack(fill="both",expand=True)
        self.lc_commentary=tk.Text(right,height=12,font=("Consolas",10),wrap="word")
        self.lc_commentary.pack(fill="both",expand=True)

        bot=ttk.Frame(self.lc_dash_tab); bot.pack(fill="both",expand=True,pady=4)
        res=ttk.LabelFrame(bot,text="BOWLING / BATTING RESOURCES",padding=6)
        par=ttk.LabelFrame(bot,text="PAR & MATCH CAPACITY",padding=6)
        res.pack(side="left",fill="both",expand=True,padx=(0,4))
        par.pack(side="left",fill="both",expand=True,padx=(4,0))
        self.lc_resources=tk.Text(res,height=10,font=("Consolas",10),wrap="word")
        self.lc_resources.pack(fill="both",expand=True)
        self.lc_par=tk.Text(par,height=10,font=("Consolas",10),wrap="word")
        self.lc_par.pack(fill="both",expand=True)

        self.lc_scorecard=tk.Text(self.lc_scorecard_tab,height=40,font=("Consolas",10),wrap="none")
        self.lc_scorecard.pack(fill="both",expand=True)
        self.lc_all_overs=tk.Text(self.lc_overs_tab,height=40,font=("Consolas",10),wrap="word")
        self.lc_all_overs.pack(fill="both",expand=True)
        self.lc_rankings=tk.Text(self.lc_rankings_tab,height=40,font=("Consolas",10),wrap="word")
        self.lc_rankings.pack(fill="both",expand=True)


    def _effective_total_balls(self,fmt=None):
        fmt=fmt or self.format_var.get()
        default=100 if fmt=="Hundred" else 120
        return int(getattr(self,"innings_total_balls",default) or default)

    def _effective_pp_balls(self,fmt=None):
        fmt=fmt or self.format_var.get()
        default=25 if fmt=="Hundred" else 36
        return int(getattr(self,"powerplay_balls",default) or default)

    def _event_extra_token(self,events):
        txt=" ".join(str(x) for x in (events or [])[-8:]).lower()
        if re.search(r"\bwide\b|\bwides\b|\bwd\b",txt):return "WD"
        if re.search(r"\bno[- ]?ball\b|\bnb\b",txt):return "NB"
        return "EX"

    def _apply_score_delta_inference(self,prev,score,wkts,balls,deliveries,events):
        """
        Scoreboard delta may recover RUNS, but NEVER a wicket.

        Wicket count can arrive asynchronously/correct late. Therefore W is shown
        only when an exact structured delivery explicitly confirms that ball.
        """
        self._current_ball_event=None
        if not prev:
            self._prev_live_score_state={"score":score,"wickets":wkts,"balls":balls}
            return

        ps=int(prev.get("score",0)); pw=int(prev.get("wickets",0)); pb=int(prev.get("balls",0))
        dr=score-ps; dw=wkts-pw; db=balls-pb
        if dr<0 or dw<0 or db<0:
            self._prev_live_score_state={"score":score,"wickets":wkts,"balls":balls}
            return

        latest=max(deliveries,key=self._ball_value) if deliveries else None
        ball_id=str(latest.get("ball",latest.get("over_ball",""))) if latest else ""

        if db==1:
            # If wicket count changed, do NOT attach W to this ball. We wait for
            # structured commentary to identify the exact wicket delivery.
            if dw>0:
                token=""
                verified=False
            elif dr in (0,1,2,3,4,5,6):
                token=str(dr)
                verified=True
            else:
                token=f"+{dr}" if dr>=0 else ""
                verified=bool(token)

            ev={
                "ball":ball_id or self._scoreboard_ball_label(balls),
                "token":token,
                "runs":max(0,dr),
                "wicket":False,
                "boundary":(dr in (4,6) and dw==0),
                "dot":(dr==0 and dw==0),
                "source":"SCOREBOARD DELTA" if verified else "WICKET CHANGE PENDING CONFIRMATION",
                "verified_outcome":verified,
            }
            if latest and verified and not str(latest.get("token","")).strip():
                latest.update({k:v for k,v in ev.items()
                               if k in ("token","runs","wicket","boundary","dot","verified_outcome")})
                self._inferred_ball_results[ball_id]=ev
            self._current_ball_event=ev

        elif db==0 and dr>0:
            kind=self._event_extra_token(events)
            if kind=="WD":
                token=(f"{dr}WD" if dr>1 else "WD")
            elif kind=="NB":
                token=("NB" if dr<=1 else f"NB+{dr}")
            else:
                token=f"EX+{dr}"

            # Illegal delivery happens before the next legal ball. If 16.5 is
            # complete, a wide is displayed as 16.6 WD and the next legal ball is
            # still 16.6.
            extra_ball=self._scoreboard_ball_label(max(1,balls+1))
            self._scoreboard_extra_seq+=1
            ev={
                "ball":extra_ball,
                "over_ball":extra_ball,
                "token":token,
                "runs":dr,
                "wicket":False,
                "boundary":False,
                "dot":False,
                "source":"SCOREBOARD EXTRA",
                "verified_outcome":True,
                "structured_verified":False,
                "legal_delivery":False,
                "extra_delivery":True,
                "extra_runs":dr,
                "_extra_seq":self._scoreboard_extra_seq,
                "_score_before":ps,
                "_score_after":score,
            }
            # Store once; it must survive later refreshes until structured data
            # confirms/replaces the event.
            self._scoreboard_extra_events.append(dict(ev))
            self._scoreboard_extra_events=self._scoreboard_extra_events[-40:]
            self._current_ball_event=ev

        self._prev_live_score_state={"score":score,"wickets":wkts,"balls":balls}

    def _fill_inferred_tokens(self,deliveries):
        out=[]
        for d in (deliveries or []):
            d=dict(d)
            k=str(d.get("ball",d.get("over_ball","")))
            inf=self._inferred_ball_results.get(k)
            if inf and str(inf.get("token","")).upper()!="W" and not str(d.get("token","")).strip():
                for f in ("token","runs","wicket","boundary","dot","verified_outcome"):
                    d[f]=inf.get(f,d.get(f))
            out.append(d)

        # Keep scoreboard-detected illegal deliveries visible across refreshes.
        # If structured Cricbuzz later confirms the same extra, suppress the
        # temporary scoreboard copy.
        structured_extras=[
            d for d in out
            if d.get("extra_delivery") and d.get("structured_verified")
        ]
        for ev in getattr(self,"_scoreboard_extra_events",[]) or []:
            eb=str(ev.get("ball",""))
            et=str(ev.get("token","")).upper()
            er=int(ev.get("runs",0) or 0)
            duplicate=False
            for d in structured_extras:
                if str(d.get("ball",""))!=eb:continue
                dt=str(d.get("token","")).upper()
                dr=int(d.get("runs",0) or 0)
                # Match type and run value where available.
                same_kind=(("WD" in et and "WD" in dt) or ("NB" in et and "NB" in dt) or et==dt)
                if same_kind and (dr==er or er==0 or dr==0):
                    duplicate=True;break
            if not duplicate:
                out.append(dict(ev))
        return sorted(out,key=self._ball_value)


    def _innings_key(self):
        return str(getattr(self,"_current_innings_id",1) or 1)

    def _delivery_event_key(self,d):
        """
        Unique stable key for one delivery EVENT.
        Legal ball: ball number is normally unique.
        Illegal delivery: same displayed ball number can repeat, so include
        token/team-score/comment to preserve every wide/no-ball separately.
        """
        ball=str(d.get("ball",d.get("over_ball",""))).strip()
        legal=d.get("legal_delivery")
        if legal is None:
            tok=str(d.get("token","")).upper()
            legal=not (("WD" in tok) or ("NB" in tok))
        if legal:
            return f"{ball}|LEGAL"
        token=str(d.get("token","")).upper()
        score=str(d.get("team_score",""))
        comment=" ".join(str(d.get("comment","")).split())[:140]
        # deterministic short signature avoids duplicate illegal events across refreshes
        sig=hashlib.md5(f"{ball}|{token}|{score}|{comment}".encode("utf-8","ignore")).hexdigest()[:10]
        return f"{ball}|ILLEGAL|{sig}"

    def _ledger_key(self,d,innings_id=None):
        return (str(innings_id or self._innings_key()),self._delivery_event_key(d))

    def _is_strictly_confirmed_delivery(self,d):
        if not isinstance(d,dict):return False
        if d.get("structured_verified") and "CRICBUZZ" in str(d.get("source","")).upper():
            return True
        return False

    def _update_confirmed_ball_ledger(self,deliveries,innings_id=None):
        ik=str(innings_id or self._innings_key())
        changed=False
        for d in (deliveries or []):
            if not self._is_strictly_confirmed_delivery(d):continue
            ball=str(d.get("ball",d.get("over_ball",""))).strip()
            if not ball:continue
            key=self._ledger_key(d,ik)
            if key not in self._confirmed_ball_ledger:
                locked=dict(d)
                locked["_event_key"]=key[1]
                self._confirmed_ball_ledger[key]=locked
                changed=True
                prev_key=self._last_confirmed_ball_by_innings.get(ik)
                if prev_key is None:
                    self._last_confirmed_ball_by_innings[ik]=key[1]
                else:
                    prev=self._confirmed_ball_ledger.get((ik,prev_key),{})
                    pv=self._ball_value(prev)
                    nv=self._ball_value(d)
                    # Same ball number: later newly-seen event becomes latest.
                    if nv>=pv:
                        self._last_confirmed_ball_by_innings[ik]=key[1]
            else:
                locked=self._confirmed_ball_ledger[key]
                for f in ("bowler_name","batter","comment","team_score","striker","bowler"):
                    if not locked.get(f) and d.get(f):
                        locked[f]=d.get(f)
        return changed

    def _apply_ledger_to_deliveries(self,deliveries,innings_id=None):
        ik=str(innings_id or self._innings_key())
        out=[]
        seen=set()
        for d in (deliveries or []):
            d=dict(d)
            key=self._ledger_key(d,ik)
            locked=self._confirmed_ball_ledger.get(key)
            if locked:
                d=dict(locked)
            seen.add(key[1])
            out.append(d)
        for (inn,event_key),locked in self._confirmed_ball_ledger.items():
            if inn==ik and event_key not in seen:
                out.append(dict(locked))
        # Python sort is stable, so repeated illegal events with same ball position
        # retain their source/ledger order.
        return sorted(out,key=self._ball_value)

    def _latest_locked_delivery(self,innings_id=None):
        ik=str(innings_id or self._innings_key())
        event_key=self._last_confirmed_ball_by_innings.get(ik)
        return dict(self._confirmed_ball_ledger[(ik,event_key)]) if event_key and (ik,event_key) in self._confirmed_ball_ledger else None

    def _scoreboard_ball_label(self,balls):
        try:
            b=int(balls)
            if b<=0:return "0.0"
            over=(b-1)//6
            ball=((b-1)%6)+1
            return f"{over}.{ball}"
        except Exception:
            return "--"

    def _strict_ball_token(self,d,source_name=""):
        if not d:return "…"
        src=str(d.get("source","") or source_name).upper()
        tok=str(d.get("token","")).strip().upper()
        structured=("CRICBUZZ" in src) or bool(d.get("structured_verified"))

        if d.get("wicket") or tok in ("W","OUT","WICKET"):
            return "W" if structured else "…"

        if re.fullmatch(r"\d+WD",tok) or tok=="WD":
            return tok
        if tok=="NB" or re.fullmatch(r"NB\+\d+",tok):
            return tok
        if re.fullmatch(r"EX\+\d+",tok):
            return tok

        try:r=int(d.get("runs",0) or 0)
        except:r=0
        if tok=="" and not d.get("verified_outcome"):return "…"
        if r in (0,1,2,3,4,5,6):return str(r)
        return tok or "…"


    def _delivery_bowler_name(self,d):
        if d.get("bowler_name"):return str(d.get("bowler_name"))
        b=d.get("bowler","")
        return str(b.get("name","")) if isinstance(b,dict) else str(b or "")

    def _delivery_batter_name(self,d):
        if d.get("batter"):return str(d.get("batter"))
        s=d.get("striker","")
        return str(s.get("name","")) if isinstance(s,dict) else str(s or "")

    def _ball_value(self,d):
        try:
            s=str(d.get("ball",d.get("over_ball",""))).strip()
            if "." in s:
                o,b=s.split(".",1)
                return int(float(o))*10+int(re.sub(r"\D","",b)[:1] or 0)
            return int(float(s))*10
        except Exception:
            return -1

    def _freshest_delivery_source(self,crex,cricbuzz):
        """
        Full Cricbuzz commentary is preferred only when it is at least as fresh.
        If CREX has a newer ball, use CREX for the current-over panel immediately.
        """
        c1=[d for d in (crex or []) if isinstance(d,dict)]
        c2=[d for d in (cricbuzz or []) if isinstance(d,dict)]
        v1=max([self._ball_value(d) for d in c1],default=-1)
        v2=max([self._ball_value(d) for d in c2],default=-1)
        return (c1,"CREX FAST") if v1>v2 else (c2,"CRICBUZZ STRUCTURED") if c2 else (c1,"CREX FAST")

    def _merged_verified_deliveries(self,crex,cricbuzz):
        """
        Merge by delivery-event key, not merely ball number.
        This preserves repeated wides/no-balls at the same legal-ball position.
        Structured Cricbuzz wins exact-event ties.
        """
        merged={}
        order=[]
        for source in ((crex or []),(cricbuzz or [])):
            for d in source:
                if not isinstance(d,dict):continue
                k=self._delivery_event_key(d)
                if k not in merged:
                    order.append(k)
                merged[k]=d
        vals=[merged[k] for k in order]
        return sorted(vals,key=self._ball_value)


    def _maybe_refresh_prediction(self,force=False):
        """
        Match-day fast prediction:
        - refresh immediately on a new legal ball
        - otherwise no more often than every 6 seconds
        Cached DB/resource calculations keep this responsive.
        """
        now=time.time()
        ball=self._live_int(self.balls)
        if not force:
            same_ball=(ball==self._last_prediction_ball)
            if same_ball and now-self._last_prediction_refresh<6:
                return "prediction unchanged"
            if not same_ball and now-self._last_prediction_refresh<2:
                return "prediction queued"
        self._last_prediction_ball=ball
        self._last_prediction_refresh=now
        return self._auto_predict_if_ready(lightweight=True)


    def _maybe_refresh_heavy_tabs(self,force=False):
        # Match-day mode: never regenerate all analyst reports automatically.
        # Users can open/refresh advanced reports when needed.
        return

    def _refresh_heavy_tabs_now(self):
        for fn in (
            self.refresh_technical_analysis,
            self.refresh_advanced_analyst,
            self.refresh_team_comparison,
            self.refresh_match_trend,
            self.refresh_squad_intelligence,
            self.refresh_player_intelligence,
        ):
            try:fn()
            except Exception:pass

    def _current_over_rows(self,deliveries):
        if not deliveries:return []
        def ball_of(d):return str(d.get("ball",d.get("over_ball","")))
        last_ball=ball_of(deliveries[-1])
        ov=last_ball.split(".")[0] if "." in last_ball else ""
        return [d for d in deliveries if ball_of(d).split(".")[0]==ov]

    def _ball_token_display(self,d):
        return self._strict_ball_token(d,str(d.get("source","")))


    def _render_full_scorecard(self,scorecard):
        lines=[]
        inns=(scorecard or {}).get("innings",[])
        if not inns:
            return "Scorecard not available yet."
        for inn in inns:
            lines += [
                f"{inn.get('batting_team','--')}  {inn.get('runs',0)}/{inn.get('wickets',0)}  ({inn.get('overs',0)} ov)",
                "="*104,
                f"{'BATTER':30} {'R':>4} {'B':>4} {'4s':>4} {'6s':>4} {'SR':>8}  DISMISSAL",
                "-"*104,
            ]
            for b in inn.get("batsmen",[]):
                lines.append(
                    f"{b.get('name','')[:30]:30} {int(b.get('runs',0)):>4} {int(b.get('balls',0)):>4} "
                    f"{int(b.get('fours',0)):>4} {int(b.get('sixes',0)):>4} "
                    f"{float(b.get('strike_rate',0) or 0):>8.2f}  {b.get('dismissal','')}"
                )
            ex=inn.get("extras",{})
            lines += ["",
                f"EXTRAS: {ex.get('total',0)}  (Wd {ex.get('wides',0)}, Nb {ex.get('noballs',0)}, "
                f"B {ex.get('byes',0)}, Lb {ex.get('legbyes',0)}, Pen {ex.get('penalty',0)})",
                "",
                f"{'BOWLER':30} {'O':>6} {'M':>3} {'R':>4} {'W':>3} {'ECON':>7} {'DOT':>4} {'WD':>3} {'NB':>3}",
                "-"*104,
            ]
            for bw in inn.get("bowlers",[]):
                lines.append(
                    f"{bw.get('name','')[:30]:30} {str(bw.get('overs',0)):>6} {int(bw.get('maidens',0)):>3} "
                    f"{int(bw.get('runs',0)):>4} {int(bw.get('wickets',0)):>3} "
                    f"{float(bw.get('economy',0) or 0):>7.2f} {int(bw.get('dots',0)):>4} "
                    f"{int(bw.get('wides',0)):>3} {int(bw.get('noballs',0)):>3}"
                )
            lines += ["","\n"]
        return "\n".join(lines)

    def _render_all_overs(self,commentary):
        if not commentary:
            return "Ball-by-ball delivery history is not available yet."
        groups={}
        for e in commentary:
            ob=e.get("over_ball",e.get("ball",""))
            s=str(ob)
            ov=s.split(".")[0] if "." in s else s
            groups.setdefault(ov,[]).append(e)
        lines=[]
        def ovkey(x):
            try:return float(x)
            except:return 9999
        for ov in sorted(groups,key=ovkey):
            rows=groups[ov]
            runs=sum(int(x.get("runs",0) or 0) for x in rows)
            lines += [f"OVER {ov}  •  {runs} runs","-"*92]
            for e in rows:
                ob=e.get("over_ball",e.get("ball","--"))
                bow=e.get("bowler",{})
                if isinstance(bow,dict): bow=bow.get("name","")
                bat=e.get("striker",{})
                if isinstance(bat,dict): bat=bat.get("name","")
                if not bat: bat=e.get("batter","")
                event=str(e.get("event",""))
                comment=str(e.get("comment",""))
                token=self._strict_ball_token(e,str(e.get("source","")))
                legality="LEGAL" if e.get("legal_delivery",True) else "EXTRA / NO LEGAL BALL"
                lines.append(
                    f"{str(ob):>5}  {token:>5}  {bow or '--'} → {bat or '--'}  [{legality}]"
                    + (f"  [{event}]" if event and event!="NONE" else "")
                )
                if comment:
                    lines.append(f"       {comment}")
            lines.append("")
        return "\n".join(lines)

    def _live_rankings_text(self,scorecard,fmt):
        inns=(scorecard or {}).get("innings",[])
        if not inns:return "Live player ranking waits for scorecard data."
        cur=inns[-1]
        bats=cur.get("batsmen",[])
        bowls=cur.get("bowlers",[])

        # Current-match danger ranking: transparent descriptive score only.
        bat_rank=[]
        for b in bats:
            balls=max(1,int(b.get("balls",0) or 0))
            runs=int(b.get("runs",0) or 0)
            sr=float(b.get("strike_rate",0) or safe_div(runs*100,balls,0))
            bnd=int(b.get("fours",0) or 0)+int(b.get("sixes",0) or 0)
            bnd_pct=bnd*100/balls
            form=self.db.recent_batting_form(b.get("name",""),fmt,10)
            form_sr=float(form["sr"]) if form else 135.0
            danger=0.42*min(100,sr/2.2)+0.28*min(100,bnd_pct*4)+0.20*min(100,runs*2)+0.10*min(100,form_sr/2)
            bat_rank.append((danger,b,sr,bnd_pct,form))
        bat_rank.sort(reverse=True,key=lambda x:x[0])

        bowl_rank=[]
        for bw in bowls:
            overs=str(bw.get("overs",0))
            econ=float(bw.get("economy",0) or 0)
            wk=int(bw.get("wickets",0) or 0)
            dots=int(bw.get("dots",0) or 0)
            # danger = wickets high + economy low + dots high; ignore 0-over placeholders
            try:
                valid=float(overs)>0
            except: valid=False
            if not valid:continue
            form=self.db.recent_bowling_form(bw.get("name",""),fmt,10)
            form_e=float(form["econ"]) if form else 8.5
            danger=0.48*min(100,wk*30)+0.27*max(0,min(100,(10-econ)*12.5))+0.15*min(100,dots*8)+0.10*max(0,min(100,(10-form_e)*12.5))
            bowl_rank.append((danger,bw,form))
        bowl_rank.sort(reverse=True,key=lambda x:x[0])

        lines=["DANGEROUS BATTERS — CURRENT MATCH","="*90,
               "Ranked using current SR, boundary frequency, runs and recent-form context.",""]
        if not bat_rank: lines.append("No batting scorecard rows yet.")
        for i,(d,b,sr,bp,form) in enumerate(bat_rank,1):
            lines.append(
                f"{i:>2}. {b.get('name',''):<28} Danger {d:>5.1f}/100 | "
                f"{b.get('runs',0)}({b.get('balls',0)}) | SR {sr:.1f} | "
                f"4s {b.get('fours',0)} 6s {b.get('sixes',0)} | Boundary-ball {bp:.1f}%"
                + (f" | Recent SR {form['sr']:.1f}" if form else " | Recent form n/a")
            )

        lines += ["","DANGEROUS BOWLERS — CURRENT MATCH","="*90,
                  "Higher wickets + lower economy + more dots + recent economy rank higher.",""]
        if not bowl_rank: lines.append("No bowling scorecard rows yet.")
        for i,(d,bw,form) in enumerate(bowl_rank,1):
            lines.append(
                f"{i:>2}. {bw.get('name',''):<28} Danger {d:>5.1f}/100 | "
                f"{bw.get('wickets',0)}/{bw.get('runs',0)} in {bw.get('overs',0)} | "
                f"Econ {float(bw.get('economy',0) or 0):.2f} | Dots {bw.get('dots',0)}"
                + (f" | Recent Econ {form['econ']:.2f}" if form else " | Recent form n/a")
            )
        return "\n".join(lines)

    def _current_scorecard_innings(self):
        sc=getattr(self,"latest_scorecard",{}) or {}
        inns=sc.get("innings",[]) or []
        return inns[-1] if inns else {}

    def _player_bat_live_line(self,row,fmt):
        name=str(row.get("name","") or "").strip()
        runs=int(row.get("runs",0) or 0); balls=int(row.get("balls",0) or 0)
        fours=int(row.get("fours",row.get("4s",0)) or 0)
        sixes=int(row.get("sixes",row.get("6s",0)) or 0)
        sr=float(row.get("sr",row.get("strike_rate",safe_div(runs*100,balls,0))) or 0)
        hist=self.db.recent_batting_form(name,fmt,10) if name else None
        rating=self.model.batter_score(name,fmt) if name else None
        danger=(rating[0] if rating else 50)
        # Live boost/penalty from current SR and runs.
        if balls>=5:
            base_sr=135 if fmt=="T20" else 140
            danger=clamp(danger+(sr-base_sr)*0.08+min(runs,50)*0.12,10,99)
        tag=("🔥 HIGH THREAT" if danger>=68 else "▲ DANGEROUS" if danger>=58 else
             "• STABLE" if danger>=45 else "▽ UNDER PRESSURE")
        recent=(f" | Last10 SR {hist['sr']:.0f}, Avg {hist['avg_score']:.1f}" if hist else "")
        return (danger,
                f"{name}: {runs}({balls}) SR {sr:.1f} | 4s {fours} 6s {sixes} | "
                f"Threat {danger:.0f}/100 {tag}{recent}")

    def _player_bowl_live_line(self,row,fmt):
        name=str(row.get("name","") or "").strip()
        runs=int(row.get("runs",0) or 0); wk=int(row.get("wickets",0) or 0)
        overs=row.get("overs",0) or 0
        econ=float(row.get("economy",0) or 0)
        hist=self.db.recent_bowling_form(name,fmt,10) if name else None
        rating=self.model.bowler_score(name,fmt) if name else None
        danger=(rating[0] if rating else 50)
        if str(overs) not in ("0","0.0",""):
            danger=clamp(danger+wk*7+(8.4-econ)*2.5,10,99)
        tag=("🔥 STRIKE THREAT" if danger>=70 else "▲ DANGEROUS" if danger>=60 else
             "• CONTROL" if danger>=48 else "▽ TARGETABLE")
        recent=(f" | Last10 Econ {hist['econ']:.2f}, Wkts {hist['wickets']}" if hist else "")
        return (danger,
                f"{name}: {wk}/{runs} ({overs} ov) Econ {econ:.2f} | "
                f"Threat {danger:.0f}/100 {tag}{recent}")

    def _refresh_resource_and_par_center(self):
        """
        Lightweight professional resource/par module.
        Uses current scorecard every ball; historical DB calls are cached by V16.9+.
        """
        try:
            fmt=self.format_var.get()
            score=self._live_int(self.score); wk=self._live_int(self.wkts); balls=self._live_int(self.balls)
            total=self._effective_total_balls(fmt)
            curr=self._current_scorecard_innings()
            bats=list(curr.get("batsmen",[]) or [])
            bowls=list(curr.get("bowlers",[]) or [])
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)

            # ---------- BATTING RESOURCES ----------
            appeared_keys={player_key(x.get("name","")) for x in bats}
            dismissed_keys={
                player_key(x.get("name","")) for x in bats
                if str(x.get("dismissal","") or "").strip()
            }
            active_bats=[
                x for x in bats
                if player_key(x.get("name","")) not in dismissed_keys and str(x.get("name","") or "").strip()
            ]
            yet=[p for p in bx if player_key(p) not in appeared_keys]

            active_lines=[]
            for row in active_bats[-2:]:
                _,ln=self._player_bat_live_line(row,fmt); active_lines.append(ln)

            yet_rank=[]
            for p in yet:
                rs=self.model.batter_score(p,fmt)
                form=self.db.recent_batting_form(p,fmt,10)
                rating=rs[0] if rs else 50
                line=f"{p}: Bat {rating:.0f}/100"
                if form:
                    line+=f" | Last10 Avg {form['avg_score']:.1f}, SR {form['sr']:.0f}"
                else:
                    line+=" | limited history"
                yet_rank.append((rating,line))
            yet_rank.sort(reverse=True,key=lambda x:x[0])

            # ---------- BOWLING RESOURCES ----------
            used=[]
            used_keys=set()
            for row in bowls:
                nm=str(row.get("name","") or "").strip()
                if nm and player_key(nm) not in used_keys:
                    used.append(row);used_keys.add(player_key(nm))

            used_rank=[]
            for row in used:
                used_rank.append(self._player_bowl_live_line(row,fmt))
            used_rank.sort(reverse=True,key=lambda x:x[0])

            unused=[p for p in ox if player_key(p) not in used_keys]
            unused_rank=[]
            for p in unused:
                bs=self.model.bowler_score(p,fmt)
                form=self.db.recent_bowling_form(p,fmt,10)
                rating=bs[0] if bs else 50
                line=f"{p}: Bowl {rating:.0f}/100"
                if form:
                    line+=f" | Last10 Econ {form['econ']:.2f}, Wkts {form['wickets']}"
                else:
                    line+=" | limited history"
                unused_rank.append((rating,line))
            unused_rank.sort(reverse=True,key=lambda x:x[0])

            current=self.current_bowler.get().strip()
            res=[
                "CURRENT MATCH RESOURCES",
                "="*72,
                f"Score {score}/{wk} after {balls} balls | Wickets in hand {max(0,10-wk)}",
                "",
                "ACTIVE BATTERS",
                *(active_lines or ["-- scorecard active batters not yet exposed --"]),
                "",
                "YET TO BAT — strongest remaining first",
                *([f"{i+1}. {x[1]}" for i,x in enumerate(yet_rank)] or ["-- none / XI incomplete --"]),
                "",
                f"CURRENT BOWLER: {current or '--'}",
                "",
                "BOWLERS USED — strike/control ranking",
                *([f"{i+1}. {x[1]}" for i,x in enumerate(used_rank)] or ["-- figures not yet exposed --"]),
                "",
                "UNUSED / YET TO BOWL — best available options",
                *([f"{i+1}. {x[1]}" for i,x in enumerate(unused_rank)] or ["-- none / XI incomplete --"]),
            ]
            self.lc_resources.delete("1.0","end")
            self.lc_resources.insert("1.0","\n".join(res))

            # ---------- PAR / MATCH CAPACITY ----------
            venue=self.venue.get().strip()
            v=self.db.venue_stats(venue,fmt)
            scheduled=100 if fmt=="Hundred" else 120
            scale=total/max(1,scheduled)
            venue_par=float(v["avg"])*scale
            venue_med=float(v["median"])*scale
            venue_p25=float(v["p25"])*scale
            venue_p75=float(v["p75"])*scale

            bp=self.model.xi_profile(bx,fmt) if bx else {"batting":50,"coverage":0}
            op=self.model.xi_profile(ox,fmt) if ox else {"bowling":50,"coverage":0}
            capacity_par=venue_par+(bp["batting"]-op["bowling"])*0.42*scale

            progress=balls/max(1,total)
            rr=safe_div(score*6,balls,0)
            linear_venue=venue_par*progress
            linear_capacity=capacity_par*progress

            # Phase-aware expected score at this exact ball.
            pp=self._effective_pp_balls(fmt)
            death_start=int(total*0.80)
            if balls<=pp:
                phase="POWERPLAY"
                phase_multiplier=1.04
            elif balls<death_start:
                phase="MIDDLE OVERS"
                phase_multiplier=0.96
            else:
                phase="DEATH OVERS"
                phase_multiplier=1.16

            # Resource-adjusted projection: current pace + expected remaining capacity.
            rem=max(0,total-balls)
            base_future_rpb=max(0.55,(capacity_par-linear_capacity)/max(1,rem))
            wickets_in_hand=max(0,10-wk)
            wicket_factor=clamp(0.72+wickets_in_hand*0.035,0.72,1.07)
            recent=getattr(self,"_latest_deliveries",[]) or []
            l6=self._recent_ball_metrics(recent)[0] if recent else {}
            recent_rpb=(float(l6.get("runs",0))/max(1,int(l6.get("legal",6) or 6))
                        if l6 and l6.get("verified") else safe_div(score,balls,base_future_rpb))
            future_rpb=base_future_rpb*0.58+recent_rpb*0.22+safe_div(score,balls,base_future_rpb)*0.20
            future_rpb*=wicket_factor
            if balls>=death_start:future_rpb*=1.08
            projection=score+rem*future_rpb

            # Preserve model projection when available, blend it with capacity projection.
            model_pred=None
            lm=getattr(self,"latest_model_result",{}) or {}
            if lm.get("innings")=="1st" and lm.get("pred") is not None:
                try:model_pred=float(lm.get("pred"))
                except:model_pred=None
            if model_pred is not None:
                projection=projection*0.55+model_pred*0.45

            tempo_vs_venue=score-linear_venue
            tempo_vs_capacity=score-linear_capacity
            expected_at_ball=linear_capacity
            resource_status=(
                "STRONG" if wickets_in_hand>=8 else
                "HEALTHY" if wickets_in_hand>=6 else
                "MODERATE" if wickets_in_hand>=4 else
                "FRAGILE"
            )
            match_state=(
                "WELL ABOVE PAR" if tempo_vs_capacity>=12 else
                "ABOVE PAR" if tempo_vs_capacity>=5 else
                "AROUND PAR" if tempo_vs_capacity>-5 else
                "BELOW PAR" if tempo_vs_capacity>-12 else
                "WELL BELOW PAR"
            )

            # Phase benchmark at PP / 10 overs / 15 overs / finish.
            checkpoints=[]
            if fmt=="T20":
                for label,bb in [("6 ov",min(36,total)),("10 ov",min(60,total)),
                                 ("15 ov",min(90,total)),("20 ov",total)]:
                    checkpoints.append(f"{label}: {capacity_par*bb/max(1,total):.0f}")
            else:
                for label,bb in [("25b",min(25,total)),("50b",min(50,total)),
                                 ("75b",min(75,total)),("100b",total)]:
                    checkpoints.append(f"{label}: {capacity_par*bb/max(1,total):.0f}")

            par=[
                "ADVANCED PAR & MATCH CAPACITY",
                "="*70,
                f"Venue: {venue or '--'}",
                f"Sample: {v['n']} innings | "+("LEAGUE FALLBACK" if v.get("fallback") else "VENUE-SPECIFIC"),
                f"Venue distribution: P25 {venue_p25:.0f} | Median {venue_med:.0f} | Avg {venue_par:.0f} | P75 {venue_p75:.0f}",
                "",
                f"Batting XI strength: {bp['batting']:.1f}/100 | coverage {bp['coverage']:.0f}%",
                f"Bowling XI strength: {op['bowling']:.1f}/100 | coverage {op['coverage']:.0f}%",
                f"TEAM-CAPACITY PAR: {capacity_par:.0f}",
                "",
                f"Phase: {phase} | Current RR {rr:.2f}",
                f"Expected team-capacity score at this ball: {expected_at_ball:.1f}",
                f"Actual: {score} | Tempo vs venue {tempo_vs_venue:+.1f} | vs team-capacity {tempo_vs_capacity:+.1f}",
                f"Match state: {match_state}",
                f"Resources: {wickets_in_hand} wickets in hand — {resource_status}",
                "",
                f"LIVE PROJECTED FINISH: {projection:.0f}",
                f"Professional range: {max(score,projection-12):.0f} – {projection+12:.0f}",
                "",
                "TEAM-CAPACITY CHECKPOINTS",
                " | ".join(checkpoints),
                "",
                "Analyst read:",
                (f"Batting side is running {abs(tempo_vs_capacity):.1f} runs "
                 f"{'ahead of' if tempo_vs_capacity>=0 else 'behind'} its adjusted par curve. "
                 f"Remaining wickets are {resource_status.lower()}; "
                 f"current projection is {projection:.0f}."),
            ]
            self.lc_par.delete("1.0","end")
            self.lc_par.insert("1.0","\n".join(par))
        except Exception as e:
            # Never leave blank panels; surface the exact limitation.
            try:
                self.lc_resources.delete("1.0","end")
                self.lc_resources.insert("1.0","Resource analysis temporarily unavailable: "+str(e))
                self.lc_par.delete("1.0","end")
                self.lc_par.insert("1.0","Par analysis temporarily unavailable: "+str(e))
            except Exception:
                pass

    def refresh_live_center(self,detail=None,fast_only=False):
        try:
            fmt=self.format_var.get()
            score=self._live_int(self.score); wk=self._live_int(self.wkts); balls=self._live_int(self.balls)
            total=self._effective_total_balls(fmt); pp=self._effective_pp_balls(fmt)
            overs=f"{balls//6}.{balls%6}" if fmt=="T20" else f"{balls}/{total} balls"
            total_overs=total/6 if fmt=="T20" else total
            venue=self.venue.get().strip() or "Venue not available"
            toss=getattr(self,"toss_text","") or "Toss not available"
            reduction=getattr(self,"reduction_text","") or "Normal scheduled innings"
            dls=getattr(self,"dls_text","") or ""
            verified_teams=(self.bat_team.get().strip() and self.bowl_team.get().strip())
            if getattr(self,"_canonical_match_name",""):
                _match_line=self._canonical_match_name
            elif verified_teams:
                _match_line=f"{self.bat_team.get()} vs {self.bowl_team.get()}"
            else:
                _match_line=self._active_match_name or "Current selected match"
            self.lc_match.set(f"{_match_line}  |  {venue}")
            self.lc_score.set(
                f"{self.bat_team.get() or 'Current innings'}  {score}/{wk}  •  {overs}  •  "
                f"Innings limit: {int(total_overs) if fmt=='T20' else total_overs}{' overs' if fmt=='T20' else ' balls'}"
            )
            self.lc_conditions.set(
                f"Toss: {toss}   |   Powerplay: {pp//6 if fmt=='T20' else pp} "
                f"{'overs' if fmt=='T20' else 'balls'}   |   {reduction}"
                + (f"   |   {dls}" if dls else "")
            )

            # Keep raw CREX balls separate from merged history so freshness can be judged.
            deliveries=(detail or {}).get("deliveries",[]) if detail else getattr(self,"_latest_crex_deliveries",[]) or []
            deliveries=self._apply_ledger_to_deliveries(self._fill_inferred_tokens(deliveries))
            cbcomm=self._apply_ledger_to_deliveries(
                self._fill_inferred_tokens(getattr(self,"latest_cb_commentary",[]) or [])
            )
            scorecard=getattr(self,"latest_scorecard",{}) or {}
            # Use the freshest source for CURRENT OVER. Structured Cricbuzz wins
            # ties, but it must never hold the display behind a newer CREX ball.
            over_source,over_source_name=self._freshest_delivery_source(deliveries,cbcomm)
            merged_history=self._apply_ledger_to_deliveries(self._merged_verified_deliveries(deliveries,cbcomm))
            # Use merged ledger-backed history for current-over rendering. This means
            # a confirmed 13.6=0 remains 0 even if the next refresh omits 13.6.
            curr=self._current_over_rows(merged_history)
            if any(self._is_strictly_confirmed_delivery(d) for d in curr):
                over_source_name="CONFIRMED LEDGER + LIVE"
            over_lines=[]
            if curr:
                last_ob=str(curr[-1].get("ball",curr[-1].get("over_ball","")))
                over_no=last_ob.split(".")[0]
                run_sum=sum(int(d.get("runs",0) or 0) for d in curr)
                legal_count=sum(1 for d in curr if d.get("legal_delivery",True))
                extra_count=sum(1 for d in curr if not d.get("legal_delivery",True))
                completed=(fmt=="T20" and legal_count>=6)
                heading=("LAST COMPLETED OVER" if completed else "CURRENT OVER")
                _official=self._scoreboard_ball_label(self._live_int(self.balls))
                _latest_confirmed=str(curr[-1].get("ball",curr[-1].get("over_ball",""))) if curr else "--"
                _sync_note=""
                if self._ball_value({"ball":_official})>self._ball_value({"ball":_latest_confirmed}):
                    _sync_note=f" | Scoreboard {_official} — structured feed catching up"
                over_lines += [
                    f"{heading} {over_no}  |  {run_sum} runs  |  "
                    f"Legal balls {min(legal_count,6)}/6  |  Extra deliveries {extra_count}  |  {over_source_name}{_sync_note}",
                    ""
                ]
                for d in curr:
                    ob=str(d.get("ball",d.get("over_ball","--")))
                    over_lines.append(
                        f"{ob:>4}  {self._strict_ball_token(d,over_source_name):>3}  "
                        f"{self._delivery_bowler_name(d) or '--'} → {self._delivery_batter_name(d) or '--'}"
                    )
                over_lines += ["","Sequence: "+"  ".join(self._strict_ball_token(d,over_source_name) for d in curr)]
            else:
                over_lines=["Current-over ball sequence is not exposed by the source yet."]
            latest=(max(over_source,key=self._ball_value) if over_source else None)
            locked_latest=self._latest_locked_delivery()
            live_ev=getattr(self,"_current_ball_event",None)

            official_ball=self._scoreboard_ball_label(balls)
            official_val=self._ball_value({"ball":official_ball})
            locked_ball=str(locked_latest.get("ball",locked_latest.get("over_ball",""))) if locked_latest else ""
            locked_val=self._ball_value({"ball":locked_ball}) if locked_ball else -1
            latest_ball=str(latest.get("ball",latest.get("over_ball",""))) if latest else ""
            latest_val=self._ball_value({"ball":latest_ball}) if latest_ball else -1

            # Display the most recently CONFIRMED ball permanently until the next
            # confirmed ball arrives. If scoreboard is ahead, show that separately
            # as "waiting for confirmation" in the detail text.
            display_ev=locked_latest or latest
            if display_ev:
                ob=str(display_ev.get("ball",display_ev.get("over_ball","--")))
                token=self._strict_ball_token(display_ev,str(display_ev.get("source","") or over_source_name))
                src=str(display_ev.get("source") or over_source_name)
                bow=self._delivery_bowler_name(display_ev)
                bat=self._delivery_batter_name(display_ev)
                if latest:
                    bow=bow or self._delivery_bowler_name(latest)
                    bat=bat or self._delivery_batter_name(latest)

                confirmed=self._is_strictly_confirmed_delivery(display_ev)
                if confirmed:
                    status=token
                    prefix="LATEST CONFIRMED BALL"
                else:
                    status=token if token!="…" else "RESULT PENDING"
                    prefix="LATEST LIVE BALL"

                over_lines += ["",f"{prefix}: {ob} • {bow or '--'} to {bat or '--'} • {status} • {src}"]
                self.lc_current_ball.set(str(ob))
                self.lc_current_result.set(token)
                detail_text=f"{bow or '--'} → {bat or '--'}  •  {src}"
                if confirmed:
                    if token=="W":detail_text="WICKET CONFIRMED  •  "+detail_text
                    elif token=="WD":detail_text="WIDE CONFIRMED  •  "+detail_text
                    elif re.fullmatch(r"\d+WD",token):
                        detail_text=f"{token[:-2]} WIDES CONFIRMED  •  "+detail_text
                    elif token=="NB":detail_text="NO BALL CONFIRMED  •  "+detail_text
                    elif token.startswith("NB+"):detail_text=f"NO BALL EVENT ({token}) CONFIRMED  •  "+detail_text
                    elif token.startswith("EX+"):detail_text=f"EXTRA ({token}) CONFIRMED  •  "+detail_text
                    elif token=="0":detail_text="DOT BALL CONFIRMED  •  "+detail_text
                    elif token=="4":detail_text="FOUR CONFIRMED  •  "+detail_text
                    elif token=="6":detail_text="SIX CONFIRMED  •  "+detail_text
                    else:detail_text=f"{token} RUN(S) CONFIRMED  •  "+detail_text
                    if official_val>self._ball_value({"ball":ob}):
                        detail_text += f"  |  Scoreboard at {official_ball}: waiting for next confirmation"
                else:
                    detail_text="RESULT PENDING  •  "+detail_text
                self.lc_current_detail.set(detail_text)
            else:
                self.lc_current_ball.set("--")
                self.lc_current_result.set("…")
                self.lc_current_detail.set(f"Waiting for first confirmed delivery • scoreboard {official_ball}")
            _over_text="\n".join(over_lines)
            if getattr(self,"_last_over_text",None)!=_over_text:
                self._last_over_text=_over_text
                self.lc_over.delete("1.0","end");self.lc_over.insert("1.0",_over_text)

            commentary=(detail or {}).get("commentary",[]) if detail else getattr(self,"latest_commentary",[])
            events=(detail or {}).get("live_events",[]) if detail else getattr(self,"latest_live_events",[])
            if cbcomm:
                structured_comments=[x.get("comment","") for x in cbcomm[-12:] if x.get("comment")]
                commentary=list(commentary or [])+structured_comments
            c_lines=[]
            if events:
                c_lines += ["LIVE EVENT / REVIEW STATUS"]+[f"• {x}" for x in events[-6:]]+[""]
            if commentary:
                c_lines += ["RECENT COMMENTARY"]+[f"• {x}" for x in commentary[-8:]]
            if not c_lines:c_lines=["No descriptive commentary exposed on this refresh."]
            _comment_text="\n".join(c_lines)
            if getattr(self,"_last_comment_text",None)!=_comment_text:
                self._last_comment_text=_comment_text
                self.lc_commentary.delete("1.0","end");self.lc_commentary.insert("1.0",_comment_text)

            if fast_only:
                # Resource/par center is designed to be lightweight and cache-backed,
                # so it remains live even when heavy analysis tabs are deferred.
                self._refresh_resource_and_par_center()
                self.live_center_status.set(
                    f"Updated {time.strftime('%H:%M:%S')} • FAST lane • {over_source_name} • resources/par live"
                )
                return

            # Professional resources + par center (same live module used by fast lane).
            self._refresh_resource_and_par_center()

            # Keep possibilities synchronized on the normal/heavy refresh cadence.
            try:
                if hasattr(self,"poss_out"):
                    self.refresh_possibilities()
            except Exception:
                pass

            # Full scorecard, all overs, and live rankings.
            self.lc_scorecard.delete("1.0","end")
            self.lc_scorecard.insert("1.0",self._render_full_scorecard(scorecard))
            all_comm=merged_history
            self.lc_all_overs.delete("1.0","end")
            self.lc_all_overs.insert("1.0",self._render_all_overs(all_comm))
            self.lc_rankings.delete("1.0","end")
            self.lc_rankings.insert("1.0",self._live_rankings_text(scorecard,fmt))

            sync_note=(" • SAME-MATCH structured sync OK" if scorecard and self._cricbuzz_match_key==self._active_match_key else
                       " • waiting for SAME-MATCH structured data")
            self.live_center_status.set(f"Updated {time.strftime('%H:%M:%S')} • CREX fast + Cricbuzz structured{sync_note}")
        except Exception as e:
            self.live_center_status.set(f"Live Center update issue: {e}")

    def build_match(self):
        top=ttk.Frame(self.tab_match); top.pack(fill="x")
        ttk.Label(top,text="Universal Live Match Predictor",font=("Arial",18,"bold")).pack(side="left")
        self.xi_auto_status=tk.StringVar(value="Automatic XI: connect a live match; after toss the app will keep retrying verified sources until both XIs are available.")
        ttk.Label(self.tab_match,textvariable=self.xi_auto_status,font=("Arial",10,"bold")).pack(fill="x",pady=(4,0))

        cfg=ttk.LabelFrame(self.tab_match,text="Match Setup",padding=8); cfg.pack(fill="x",pady=8)
        self.format_var=tk.StringVar(value="T20")
        self.innings_var=tk.StringVar(value="1st Innings")
        ttk.Label(cfg,text="Format").grid(row=0,column=0,sticky="w",padx=4)
        fmt_box=ttk.Combobox(cfg,textvariable=self.format_var,values=["T20","Hundred"],state="readonly",width=12)
        fmt_box.grid(row=0,column=1,padx=4)
        fmt_box.bind("<<ComboboxSelected>>",lambda e:self.refresh_dropdowns())

        ttk.Label(cfg,text="Innings").grid(row=0,column=2,sticky="w",padx=4)
        ttk.Combobox(cfg,textvariable=self.innings_var,values=["1st Innings","2nd Innings"],state="readonly",width=14).grid(row=0,column=3,padx=4)

        self.venue=tk.StringVar(value="")
        self.bat_team=tk.StringVar(value="")
        self.bowl_team=tk.StringVar(value="")
        self.toss_var=tk.StringVar(value="")
        self.innings_limit_var=tk.StringVar(value="20")
        self.powerplay_var=tk.StringVar(value="6")

        ttk.Label(cfg,text="Venue").grid(row=1,column=0,sticky="w",padx=4,pady=4)
        self.venue_box=ttk.Combobox(cfg,textvariable=self.venue,width=34)
        self.venue_box.grid(row=1,column=1,columnspan=2,sticky="ew",padx=4,pady=4)
        self.venue_box.bind("<KeyRelease>",lambda e:self.filter_combo(self.venue_box,self.db.all_venues(self.format_var.get())))

        ttk.Label(cfg,text="Batting Team").grid(row=1,column=3,sticky="w",padx=4,pady=4)
        self.bat_team_box=ttk.Combobox(cfg,textvariable=self.bat_team,width=24)
        self.bat_team_box.grid(row=1,column=4,padx=4,pady=4)
        self.bat_team_box.bind("<KeyRelease>",lambda e:self.filter_combo(self.bat_team_box,self.db.all_teams(self.format_var.get())))

        ttk.Label(cfg,text="Bowling Team").grid(row=1,column=5,sticky="w",padx=4,pady=4)
        self.bowl_team_box=ttk.Combobox(cfg,textvariable=self.bowl_team,width=24)
        self.bowl_team_box.grid(row=1,column=6,padx=4,pady=4)
        self.bowl_team_box.bind("<KeyRelease>",lambda e:self.filter_combo(self.bowl_team_box,self.db.all_teams(self.format_var.get())))

        xis=ttk.LabelFrame(self.tab_match,text="Confirmed Playing XIs — paste list OR use player dropdowns",padding=8)
        xis.pack(fill="x",pady=6)

        self.bat_pick=tk.StringVar()
        self.bowl_pick=tk.StringVar()
        self.bat_player_box=ttk.Combobox(xis,textvariable=self.bat_pick,width=34)
        self.bowl_player_box=ttk.Combobox(xis,textvariable=self.bowl_pick,width=34)
        self.bat_player_box.grid(row=1,column=0,padx=5,sticky="ew")
        ttk.Button(xis,text="Add ↓",command=lambda:self.add_player_to_xi(self.bat_pick,self.bat_xi)).grid(row=1,column=1,padx=3)
        self.bowl_player_box.grid(row=1,column=2,padx=5,sticky="ew")
        ttk.Button(xis,text="Add ↓",command=lambda:self.add_player_to_xi(self.bowl_pick,self.bowl_xi)).grid(row=1,column=3,padx=3)

        ttk.Label(xis,text="Search/Add Batting XI player").grid(row=0,column=0,sticky="w")
        ttk.Label(xis,text="Search/Add Bowling XI player").grid(row=0,column=2,sticky="w")

        self.bat_xi=tk.Text(xis,height=7,width=48)
        self.bowl_xi=tk.Text(xis,height=7,width=48)
        self.bat_xi.grid(row=3,column=0,columnspan=2,padx=5,pady=(5,0),sticky="ew")
        self.bowl_xi.grid(row=3,column=2,columnspan=2,padx=5,pady=(5,0),sticky="ew")
        ttk.Label(xis,text="Batting XI").grid(row=2,column=0,columnspan=2)
        ttk.Label(xis,text="Bowling XI").grid(row=2,column=2,columnspan=2)
        xis.columnconfigure(0,weight=1); xis.columnconfigure(2,weight=1)

        self.bat_player_box.bind("<KeyRelease>",lambda e:self.filter_combo(self.bat_player_box,self.db.all_players(self.format_var.get())))
        self.bowl_player_box.bind("<KeyRelease>",lambda e:self.filter_combo(self.bowl_player_box,self.db.all_players(self.format_var.get())))

        live=ttk.LabelFrame(self.tab_match,text="Live State",padding=8); live.pack(fill="x",pady=6)
        self.score=tk.StringVar(value="0"); self.wkts=tk.StringVar(value="0"); self.balls=tk.StringVar(value="0")
        self.last=tk.StringVar(value="0"); self.target=tk.StringVar(value="0")
        fields=[("Score",self.score),("Wickets",self.wkts),("Balls Used",self.balls),
                ("Last block runs",self.last),("Target (2nd inns)",self.target)]
        for i,(lab,var) in enumerate(fields):
            ttk.Label(live,text=lab).grid(row=0,column=i*2,sticky="w",padx=4)
            ttk.Entry(live,textvariable=var,width=10).grid(row=0,column=i*2+1,padx=4)

        detail=ttk.LabelFrame(self.tab_match,text="Live Players, Partnership & Momentum",padding=8)
        detail.pack(fill="x",pady=6)

        self.striker=tk.StringVar(); self.non_striker=tk.StringVar(); self.current_bowler=tk.StringVar()
        self.striker_box=ttk.Combobox(detail,textvariable=self.striker,width=27)
        self.non_striker_box=ttk.Combobox(detail,textvariable=self.non_striker,width=27)
        self.current_bowler_box=ttk.Combobox(detail,textvariable=self.current_bowler,width=27)
        ttk.Label(detail,text="Striker").grid(row=0,column=0,sticky="w")
        self.striker_box.grid(row=0,column=1,padx=4)
        ttk.Label(detail,text="Non-striker").grid(row=0,column=2,sticky="w")
        self.non_striker_box.grid(row=0,column=3,padx=4)
        ttk.Label(detail,text="Current bowler").grid(row=0,column=4,sticky="w")
        self.current_bowler_box.grid(row=0,column=5,padx=4)

        self.striker_runs=tk.StringVar(value="0"); self.striker_balls=tk.StringVar(value="0")
        self.non_runs=tk.StringVar(value="0"); self.non_balls=tk.StringVar(value="0")
        self.bowler_runs_live=tk.StringVar(value="0"); self.bowler_balls_live=tk.StringVar(value="0")
        self.bowler_wkts_live=tk.StringVar(value="0")
        player_fields=[
            ("Striker R",self.striker_runs),("Striker B",self.striker_balls),
            ("Non-str R",self.non_runs),("Non-str B",self.non_balls),
            ("Bowler R",self.bowler_runs_live),("Bowler B",self.bowler_balls_live),
            ("Bowler W",self.bowler_wkts_live)
        ]
        for i,(lab,var) in enumerate(player_fields):
            ttk.Label(detail,text=lab).grid(row=1,column=i*2,sticky="w",padx=2,pady=3)
            ttk.Entry(detail,textvariable=var,width=7).grid(row=1,column=i*2+1,padx=2,pady=3)

        self.part_runs=tk.StringVar(value="0"); self.part_balls=tk.StringVar(value="0")
        self.since_boundary=tk.StringVar(value="0"); self.since_wicket=tk.StringVar(value="0")
        self.boundaries12=tk.StringVar(value="0"); self.wickets12=tk.StringVar(value="0")
        mom_fields=[
            ("Partnership runs",self.part_runs),("Partnership balls",self.part_balls),
            ("Balls since boundary",self.since_boundary),("Balls since wicket",self.since_wicket),
            ("Boundaries last 12",self.boundaries12),("Wickets last 12",self.wickets12)
        ]
        for i,(lab,var) in enumerate(mom_fields):
            ttk.Label(detail,text=lab).grid(row=2,column=i*2,sticky="w",padx=2,pady=3)
            ttk.Entry(detail,textvariable=var,width=7).grid(row=2,column=i*2+1,padx=2,pady=3)

        resources=ttk.LabelFrame(self.tab_match,text="Remaining Resources — crucial for live accuracy",padding=8)
        resources.pack(fill="x",pady=6)
        ttk.Label(resources,text="Yet to bat (one player per line)").grid(row=0,column=0)
        ttk.Label(resources,text="Bowlers still available / likely upcoming").grid(row=0,column=1)
        self.yet_to_bat=tk.Text(resources,height=5,width=48)
        self.available_bowlers=tk.Text(resources,height=5,width=48)
        self.yet_to_bat.grid(row=1,column=0,padx=5,sticky="ew")
        self.available_bowlers.grid(row=1,column=1,padx=5,sticky="ew")
        resources.columnconfigure(0,weight=1); resources.columnconfigure(1,weight=1)

        impact=ttk.LabelFrame(self.tab_match,text="Impact / Substitute Resources",padding=8)
        impact.pack(fill="x",pady=6)
        ttk.Label(impact,text="Batting-side impact / substitute candidates").grid(row=0,column=0)
        ttk.Label(impact,text="Bowling-side impact / substitute candidates").grid(row=0,column=1)
        self.bat_impact=tk.Text(impact,height=4,width=48)
        self.bowl_impact=tk.Text(impact,height=4,width=48)
        self.bat_impact.grid(row=1,column=0,padx=5,sticky="ew")
        self.bowl_impact.grid(row=1,column=1,padx=5,sticky="ew")
        impact.columnconfigure(0,weight=1); impact.columnconfigure(1,weight=1)

        btn=ttk.Frame(self.tab_match); btn.pack(fill="x",pady=6)
        ttk.Button(btn,text="PRE-MATCH ANALYSIS",command=self.prematch).pack(side="left",padx=4)
        ttk.Button(btn,text="LIVE PREDICT",command=self.live_predict).pack(side="left",padx=4)
        ttk.Button(btn,text="SAVE CHECKPOINT",command=self.checkpoint).pack(side="left",padx=4)
        ttk.Button(btn,text="EXPORT LOG",command=self.export_log).pack(side="left",padx=4)
        ttk.Button(btn,text="REFRESH DROPDOWNS",command=self.refresh_dropdowns).pack(side="left",padx=4)
        ttk.Button(btn,text="COACH REPORT",command=self.coach_report).pack(side="left",padx=4)
        ttk.Button(btn,text="XI REPORT",command=self.xi_report).pack(side="left",padx=4)
        ttk.Button(btn,text="TECHNICAL",command=self.refresh_technical_analysis).pack(side="left",padx=4)
        ttk.Button(btn,text="COMPARE",command=self.refresh_team_comparison).pack(side="left",padx=4)
        ttk.Button(btn,text="TREND",command=self.refresh_match_trend).pack(side="left",padx=4)
        ttk.Button(btn,text="ADVANCED",command=self.refresh_advanced_analyst).pack(side="left",padx=4)
        ttk.Button(btn,text="PLAYER INTEL",command=self.refresh_player_intelligence).pack(side="left",padx=4)

        self.output=tk.Text(self.tab_match,height=20,font=("Consolas",11))
        self.output.pack(fill="both",expand=True,pady=6)
        self.refresh_dropdowns()

    def filter_combo(self, combo, values):
        typed=combo.get().strip().lower()
        if not typed:
            combo["values"]=values[:1000]
            return
        # substring + starts-with priority
        starts=[v for v in values if v.lower().startswith(typed)]
        contains=[v for v in values if typed in v.lower() and v not in starts]
        combo["values"]=(starts+contains)[:300]

    def refresh_dropdowns(self):
        fmt=self.format_var.get() if hasattr(self,"format_var") else None
        venues=self.db.all_venues(fmt)
        players=self.db.all_players(fmt)
        teams=self.db.all_teams(fmt)
        if hasattr(self,"venue_box"): self.venue_box["values"]=venues
        if hasattr(self,"bat_team_box"): self.bat_team_box["values"]=teams
        if hasattr(self,"bowl_team_box"): self.bowl_team_box["values"]=teams
        if hasattr(self,"bat_player_box"): self.bat_player_box["values"]=players[:1000]
        if hasattr(self,"bowl_player_box"): self.bowl_player_box["values"]=players[:1000]
        if hasattr(self,"striker_box"):
            bx=self.names(self.bat_xi) if hasattr(self,"bat_xi") else []
            ox=self.names(self.bowl_xi) if hasattr(self,"bowl_xi") else []
            self.striker_box["values"]=bx or players[:1000]
            self.non_striker_box["values"]=bx or players[:1000]
            self.current_bowler_box["values"]=ox or players[:1000]

    def add_player_to_xi(self, var, text_widget):
        p=norm_name(var.get())
        if not p:return
        existing=self.names(text_widget)
        if player_key(p) not in {player_key(x) for x in existing}:
            if text_widget.get("1.0","end").strip():
                text_widget.insert("end","\n")
            text_widget.insert("end",p)
        var.set("")

    def names(self,text):
        raw=text.get("1.0","end").strip()
        if not raw:
            return []
        # Accept pasted lists separated by commas, semicolons OR new lines.
        parts=re.split(r"[,;\n]+", raw)
        names=[]
        for item in parts:
            item=item.strip()
            # If a whole heading was pasted, keep only the content after 'Playing XI:'.
            if ":" in item and "playing xi" in item.lower():
                item=item.split(":",1)[1].strip()
            item=re.sub(r"^[-•*\d.\)\s]+", "", item).strip()
            item=re.sub(r"\s*\((?:c|wk|c\s*&\s*wk|wk\s*&\s*c)\)\s*$", "", item, flags=re.I).strip()
            item=item.replace("†","").strip()
            bad_labels={
                "view profile","profile","player profile","full profile","details",
                "players","bench","squad","playing xi","more"
            }
            if item.lower() in bad_labels:
                continue
            if re.fullmatch(r"(?:view|see|read|show)\s+(?:profile|details|more)",item,re.I):
                continue
            if item and "playing xi" not in item.lower():
                names.append(norm_name(item))
        # Preserve order but remove accidental duplicates.
        out=[]; seen=set()
        for n in names:
            k=player_key(n)
            if k and k not in seen:
                out.append(n); seen.add(k)
        return out

    def prematch(self):
        fmt=self.format_var.get(); v=self.venue.get()
        bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
        if not bx or not ox:
            messagebox.showerror("Playing XI","Enter both playing XIs."); return
        if len(bx)!=11 or len(ox)!=11:
            if not messagebox.askyesno("XI count",f"Batting XI has {len(bx)} players and Bowling XI has {len(ox)}. Continue anyway?"):
                return
        r=self.model.pre_match(fmt,v,bx,ox)
        vp=r["venue"]; bp=r["bat_profile"]; op=r["bowl_profile"]
        txt=(f"{fmt} PRE-MATCH ANALYSIS\n{'='*70}\n"
             f"{self.bat_team.get()} batting vs {self.bowl_team.get()} bowling\n"
             f"Venue: {v or 'Unknown'}\n\n"
             f"Projected 1st innings score : {r['pred']}\n"
             f"Likely range                : {r['low']} - {r['high']}\n"
             f"Historical data coverage    : {r['coverage']}%\n\n"
             f"Venue innings sample        : {vp['n']}\n"
             f"Venue/league average        : {vp['avg']:.1f}\n"
             f"Venue median                : {vp['median']:.1f}\n"
             f"Venue P25-P75               : {vp['p25']:.0f} - {vp['p75']:.0f}\n\n"
             f"Batting XI strength         : {bp['batting']}/100\n"
             f"Known players               : {bp['known']}/{bp['total']}\n"
             f"Opposition bowling strength : {op['bowling']}/100\n"
             f"Known players               : {op['known']}/{op['total']}\n\n"
             "PLAYER MATCHING REPORT\n" + "-"*70 + "\n" +
             "Batting XI:\n" + "\n".join(
                 f"  {'✓' if d['matched'] else '✗'} {d['requested']}" +
                 (f"  ->  {d['matched']}  ({d['coverage']:.0f}% sample confidence)" if d['matched'] else "  ->  NOT FOUND")
                 for d in bp['details']
             ) + "\n\nBowling XI:\n" + "\n".join(
                 f"  {'✓' if d['matched'] else '✗'} {d['requested']}" +
                 (f"  ->  {d['matched']}  ({d['coverage']:.0f}% sample confidence)" if d['matched'] else "  ->  NOT FOUND")
                 for d in op['details']
             ) + "\n\nNote: unresolved/low-sample players are shrunk toward neutral league-average values.\n")
        self.output.delete("1.0","end"); self.output.insert("1.0",txt)

    def _live_int(self,var):
        try:return int(var.get() or 0)
        except:return 0

    def _hydrate_live_matchup_from_sources(self,force_latest=False):
        """
        Fast live matchup hydration.
        Priority:
          1) latest structured delivery state (same innings)
          2) latest verified merged delivery
          3) current scorecard active rows
        Unlike older versions, fresh evidence REPLACES stale UI values.
        """
        try:
            scorecard=getattr(self,"latest_scorecard",{}) or {}
            inns=scorecard.get("innings",[]) or []
            current_inn=int(getattr(self,"_current_innings_id",1) or 1)
            curr=inns[-1] if inns else {}
            bats=list(curr.get("batsmen",[]) or [])
            bowls=list(curr.get("bowlers",[]) or [])

            deliveries=[
                d for d in (getattr(self,"latest_cb_commentary",[]) or [])
                if int(d.get("innings_id") or current_inn)==current_inn
            ]
            if not deliveries:
                deliveries=list(getattr(self,"_latest_deliveries",[]) or [])
            latest=max(deliveries,key=self._ball_value) if deliveries else None

            latest_batter=self._delivery_batter_name(latest).strip() if latest else ""
            latest_bowler=self._delivery_bowler_name(latest).strip() if latest else ""
            latest_striker=latest.get("striker",{}) if latest else {}
            latest_non=latest.get("non_striker",{}) if latest else {}
            if not isinstance(latest_striker,dict): latest_striker={}
            if not isinstance(latest_non,dict): latest_non={}

            striker_name=str(latest_striker.get("name") or latest_batter or "").strip()
            non_name=str(latest_non.get("name") or "").strip()
            bowler_name=str(latest_bowler or "").strip()

            # Scorecard fallback.
            active=[]
            for row in bats:
                name=str(row.get("name","") or "").strip()
                dismissal=str(row.get("dismissal","") or "").strip().lower()
                if name and (not dismissal or "not out" in dismissal or dismissal=="batting"):
                    active.append(row)

            if not striker_name and active:
                striker_name=str(active[-1].get("name","") or "").strip()
            if not non_name:
                for row in reversed(active):
                    nm=str(row.get("name","") or "").strip()
                    if nm and player_key(nm)!=player_key(striker_name):
                        non_name=nm;break
            if not bowler_name and bowls:
                bowler_name=str(bowls[-1].get("name","") or "").strip()

            # Always replace stale values when fresh same-innings evidence exists.
            if striker_name:self.striker.set(striker_name)
            if non_name:self.non_striker.set(non_name)
            if bowler_name:self.current_bowler.set(bowler_name)

            def batrow(name):
                return next((r for r in bats if player_key(r.get("name",""))==player_key(name)),None)

            # Latest commentary figures are usually fresher than periodic scorecard.
            srrow=batrow(striker_name) if striker_name else None
            nrrow=batrow(non_name) if non_name else None
            if latest_striker and striker_name:
                self.striker_runs.set(str(int(latest_striker.get("runs",0) or 0)))
                self.striker_balls.set(str(int(latest_striker.get("balls",0) or 0)))
            elif srrow:
                self.striker_runs.set(str(int(srrow.get("runs",0) or 0)))
                self.striker_balls.set(str(int(srrow.get("balls",0) or 0)))

            if latest_non and non_name:
                self.non_runs.set(str(int(latest_non.get("runs",0) or 0)))
                self.non_balls.set(str(int(latest_non.get("balls",0) or 0)))
            elif nrrow:
                self.non_runs.set(str(int(nrrow.get("runs",0) or 0)))
                self.non_balls.set(str(int(nrrow.get("balls",0) or 0)))

            # Bowler figures from latest commentary object first.
            latest_bw=latest.get("bowler",{}) if latest else {}
            if not isinstance(latest_bw,dict):latest_bw={}
            if latest_bw and bowler_name:
                self.bowler_runs_live.set(str(int(latest_bw.get("runs",0) or 0)))
                self.bowler_wkts_live.set(str(int(latest_bw.get("wickets",0) or 0)))
                ov=latest_bw.get("overs",0) or 0
                self.bowler_balls_live.set(str(self._overs_to_balls(ov,self.format_var.get())))
            else:
                bwrow=next((r for r in bowls if player_key(r.get("name",""))==player_key(bowler_name)),None) if bowler_name else None
                if bwrow:
                    self.bowler_runs_live.set(str(int(bwrow.get("runs",0) or 0)))
                    self.bowler_wkts_live.set(str(int(bwrow.get("wickets",0) or 0)))
                    self.bowler_balls_live.set(str(self._overs_to_balls(bwrow.get("overs",0),self.format_var.get())))

            # Partnership is continuously derived from scoreboard snapshots.
            score=self._live_int(self.score); wk=self._live_int(self.wkts); balls=self._live_int(self.balls)
            if wk==0:
                self.part_runs.set(str(score));self.part_balls.set(str(balls))
            elif getattr(self,"_last_wicket_score",0)>0 or getattr(self,"_last_wicket_balls",0)>0:
                self.part_runs.set(str(max(0,score-self._last_wicket_score)))
                self.part_balls.set(str(max(0,balls-self._last_wicket_balls)))

            if hasattr(self,"live_matchup_status"):
                self.live_matchup_status.set(
                    f"Current matchup LIVE: {self.striker.get() or '--'} / {self.non_striker.get() or '--'} "
                    f"• bowler {self.current_bowler.get() or '--'} • innings {current_inn}"
                )
            self._last_matchup_ball=balls
            return {"striker":self.striker.get().strip(),"non":self.non_striker.get().strip(),
                    "bowler":self.current_bowler.get().strip(),"source":"FAST SAME-INNINGS LIVE"}
        except Exception:
            return {"striker":self.striker.get().strip(),
                    "non":self.non_striker.get().strip(),
                    "bowler":self.current_bowler.get().strip(),
                    "source":"LIVE FIELDS"}


    def _professional_run_distribution(self, score, wickets, balls, total,
                                       mean_rpb, p_boundary, p_wicket,
                                       simulations=1400):
        """Deterministic Monte-Carlo distribution for live forecasts.

        The seed is derived only from the observed match state, so refreshing an
        unchanged score does not make the forecast jump.  This is an analytical
        uncertainty layer, not a substitute for a trained model.
        """
        rem=max(0,int(total)-int(balls))
        if rem<=0:
            return {
                "median":int(score),"p10":int(score),"p25":int(score),
                "p75":int(score),"p90":int(score),"samples":[int(score)]
            }

        seed_text=f"{int(score)}|{int(wickets)}|{int(balls)}|{int(total)}|{float(mean_rpb):.4f}|{float(p_boundary):.4f}|{float(p_wicket):.4f}"
        seed=int(hashlib.sha256(seed_text.encode("utf-8")).hexdigest()[:16],16)
        rng=random.Random(seed)
        mean_rpb=clamp(float(mean_rpb),0.25,2.75)
        p_boundary=clamp(float(p_boundary),0.02,0.34)
        p_wicket=clamp(float(p_wicket),0.012,0.18)
        results=[]

        # Non-boundary run weights are scaled to the requested mean. Boundary
        # probabilities remain explicit, while dots increase under pressure.
        boundary_mean=p_boundary*(4.35+0.55*clamp((mean_rpb-1.0),0,1))
        non_boundary_mean=max(0.05,mean_rpb-boundary_mean)
        for _ in range(max(300,int(simulations))):
            runs=0
            lost=0
            for i in range(rem):
                if wickets+lost>=10:
                    break
                progress=safe_div(balls+i,total,0)
                local_wicket=clamp(p_wicket*(1+lost*0.075+(0.12 if progress>.80 else 0)),0.01,0.24)
                if rng.random()<local_wicket:
                    lost+=1
                    continue
                local_boundary=clamp(p_boundary*(1-0.055*lost),0.02,0.36)
                u=rng.random()
                if u<local_boundary:
                    runs += 6 if rng.random()<clamp(0.20+(mean_rpb-1)*0.10,0.12,0.38) else 4
                    continue
                # A compact 0/1/2/3 distribution whose scoring mass follows the
                # calibrated future pace without inventing unsupported precision.
                target=clamp(non_boundary_mean/max(0.05,1-local_boundary),0.05,1.15)
                dot=clamp(0.69-target*0.38,0.24,0.70)
                one=clamp(0.23+target*0.22,0.20,0.54)
                two=clamp(1-dot-one-0.012,0.015,0.22)
                v=rng.random()
                if v<dot:r=0
                elif v<dot+one:r=1
                elif v<dot+one+two:r=2
                else:r=3
                runs+=r
            results.append(int(score)+runs)
        results.sort()

        def q(p):
            if not results:return int(score)
            pos=(len(results)-1)*p
            lo=int(pos); hi=min(len(results)-1,lo+1); frac=pos-lo
            return int(round(results[lo]*(1-frac)+results[hi]*frac))
        return {
            "median":q(.50),"p10":q(.10),"p25":q(.25),
            "p75":q(.75),"p90":q(.90),"samples":results
        }

    def _unified_first_innings_calibration(self,fmt,score,wkts,balls,total,raw_result):
        """
        One prediction core shared by Prediction/Coach/Fancy-facing output.
        It prevents older aggressive professional_live_first estimates from
        bypassing the V17.6 resource intelligence.
        """
        raw_pred=float(raw_result.get("pred",score) or score)
        pred=self._resource_calibrated_finish(fmt,score,wkts,balls,total,raw_pred)
        rem=max(0,total-balls)
        rpb=self._resource_calibrated_future_rpb(fmt,score,wkts,balls,total,raw_pred)

        resources=self._remaining_resource_matrix(fmt)
        pm=self._pressure_momentum_matrix(fmt,score,wkts,balls,total)

        # Calibrated next-block runs.
        n1=int(raw_result.get("next1_n",6) or 6)
        n2=int(raw_result.get("next2_n",12) or 12)
        next1=round(min(rem,n1)*rpb,1)
        next2=round(min(rem,n2)*rpb,1)

        # Live boundary hazard.
        deliveries=getattr(self,"_latest_deliveries",[]) or []
        legal=[d for d in deliveries[-36:] if d.get("legal_delivery",True)]
        bnd=sum(1 for d in legal if d.get("boundary") or int(d.get("runs",0) or 0) in (4,6))
        obs_bnd=safe_div(bnd,len(legal),0.12)
        batq=float(resources.get("remaining_bat_rating",50))
        bowl_control=float(resources.get("future_control",50))
        p_boundary_ball=clamp(
            0.10+0.45*obs_bnd+(batq-50)*0.0012-(bowl_control-50)*0.0010,
            0.035,0.28
        )

        # Wicket hazard per ball: current wicket state + recent pressure + bowling threat.
        p_wicket_ball=0.040
        p_wicket_ball+=max(0,wkts-4)*0.006
        p_wicket_ball+=(float(pm.get("wicket_pressure") or 0)/100)*0.035
        p_wicket_ball+=(float(resources.get("future_bowl_rating",50))-50)*0.00055
        p_wicket_ball=clamp(p_wicket_ball,0.025,0.15)

        def at_least_one(p,n):
            return (1-(1-p)**max(0,n))*100

        # Prediction uncertainty: lower with more innings observed, higher with
        # wickets/resource uncertainty.
        frac_rem=safe_div(rem,total,0)
        width=7+14*frac_rem
        if wkts>=6:width+=3
        if wkts>=8:width+=3
        width=clamp(width,7,24)
        low=max(score,round(pred-width))
        high=round(pred+width)

        dist=self._professional_run_distribution(
            score,wkts,balls,total,rpb,p_boundary_ball,p_wicket_ball
        )
        # Median is more robust than the arithmetic mean when collapse and
        # acceleration tails are asymmetric. Keep the resource estimate visible.
        central=round(dist["median"]*.68+pred*.32)
        p10,p25,p75,p90=dist["p10"],dist["p25"],dist["p75"],dist["p90"]
        collapse_cut=max(score,round(central-max(8,(p90-p10)*.28)))
        accel_cut=round(central+max(8,(p90-p10)*.28))
        samples=dist["samples"]
        n=max(1,len(samples))
        collapse_pct=round(sum(x<=collapse_cut for x in samples)*100/n,1)
        accel_pct=round(sum(x>=accel_cut for x in samples)*100/n,1)
        central_pct=round(max(0,100-collapse_pct-accel_pct),1)

        return {
            "pred":central,
            "low":int(p10),
            "high":int(p90),
            "p25":int(p25),"p75":int(p75),
            "future_rpb":round(rpb,3),
            "next1":next1,
            "next2":next2,
            "boundary1":round(at_least_one(p_boundary_ball,min(rem,n1)),1),
            "boundary2":round(at_least_one(p_boundary_ball,min(rem,n2)),1),
            "wicket1":round(at_least_one(p_wicket_ball,min(rem,n1)),1),
            "wicket2":round(at_least_one(p_wicket_ball,min(rem,n2)),1),
            "resources":resources,
            "pressure":pm,
            "raw_pred":round(raw_pred,1),
            "resource_pred":round(pred,1),
            "scenario_probabilities":{
                "suppressed_or_collapse":collapse_pct,
                "central":central_pct,
                "acceleration":accel_pct,
            },
        }

    def live_predict(self):
        try:
            self._hydrate_live_matchup_from_sources()
            fmt=self.format_var.get(); v=self.venue.get()
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
            s=self._live_int(self.score); w=self._live_int(self.wkts); b=self._live_int(self.balls)
            _vs=self._validated_live_state()
            _l6,_l12=_vs["l6"],_vs["l12"]
            # If exact recent balls are unavailable, use innings scoring pace as a neutral
            # last-block input instead of zero or stale values.
            block=10 if fmt=="Hundred" else 6
            l=round(_l6["runs"]) if _l6.get("verified") else round(safe_div(s,b,0)*block)
            striker=self.striker.get().strip(); non=self.non_striker.get().strip(); bowler=self.current_bowler.get().strip()
            sr=self._live_int(self.striker_runs); sb=self._live_int(self.striker_balls)
            nr=self._live_int(self.non_runs); nb=self._live_int(self.non_balls)
            br=self._live_int(self.bowler_runs_live); bb=self._live_int(self.bowler_balls_live); bw=self._live_int(self.bowler_wkts_live)
            pr=_vs["part_runs"]; pb=_vs["part_balls"]
            bsb=self._live_int(self.since_boundary)
            bsw=_vs["balls_since_wicket"]
            bd12=_l12["boundaries"] if _l12.get("verified") else 0
            wk12=_l12["wickets"] if _l12.get("verified") else 0
            yet=self.names(self.yet_to_bat); avail=self.names(self.available_bowlers)

            if not bx:
                bx=[self.striker.get().strip() or "Unknown batter"]
            if not ox:
                ox=[self.current_bowler.get().strip() or "Unknown bowler"]
            matchup_quality="VERIFIED LIVE MATCHUP"
            if not striker:
                striker="Unknown current batter"; matchup_quality="PARTIAL LIVE MATCHUP"
            if not bowler:
                bowler="Unknown current bowler"; matchup_quality="PARTIAL LIVE MATCHUP"
            if not non:
                non="Unknown non-striker"; matchup_quality="PARTIAL LIVE MATCHUP"

            if self.innings_var.get()=="1st Innings":
                _total=self._effective_total_balls(fmt); _pp=self._effective_pp_balls(fmt)
                r=self.model.professional_live_first(fmt,v,bx,ox,s,w,b,l,striker,non,bowler,
                    sr,sb,nr,nb,br,bb,bw,pr,pb,bsb,bsw,bd12,wk12,yet,avail,_total,_pp)
                _cal=self._unified_first_innings_calibration(fmt,s,w,b,_total,r)
                # Unified calibrated values replace the older aggressive branch.
                for _k in ("pred","low","high","p25","p75","next1","next2","boundary1","boundary2","wicket1","wicket2","scenario_probabilities"):
                    r[_k]=_cal[_k]
                r["raw_pred_before_resource_calibration"]=_cal["raw_pred"]
                r["resource_future_rpb"]=_cal["future_rpb"]
                r["resource_pressure"]=_cal["pressure"]
                self.latest_model_result=dict(r)
                self.latest_model_result["innings"]="1st"
                sform=r.get("striker_form"); nform=r.get("non_form"); bform=r.get("bowler_form")
                txt=[
                    f"{fmt} PROFESSIONAL LIVE FIRST-INNINGS ENGINE",
                    "="*82,
                    f"{self.bat_team.get()} {s}/{w} after {b} balls | Venue: {v or 'Unknown'}",
                    "",
                    "CURRENT MATCHUP",
                    f"Data quality  : {matchup_quality}",
                    f"Striker      : {striker} {sr}({sb}) | Hist rating: {r.get('striker_hist') or '--'}",
                    f"Non-striker  : {non} {nr}({nb}) | Hist rating: {r.get('non_hist') or '--'}",
                    f"Bowler       : {bowler} " + (f"{br}/{bw} from {bb} balls" if bb>0 else "figures unavailable") + f" | Hist rating: {r.get('bowler_hist') or '--'}",
                    f"Combined current-batters SR : {r.get('current_pair_sr',0)}",
                    "",
                    "RECENT FORM",
                    f"{striker}: " + (f"{sform['runs']} runs / {sform['innings']} inns, SR {sform['sr']:.1f}" if sform else "no reliable recent history"),
                    f"{non}: " + (f"{nform['runs']} runs / {nform['innings']} inns, SR {nform['sr']:.1f}" if nform else "no reliable recent history"),
                    f"{bowler}: " + (f"{bform['wickets']} wkts / {bform['innings']} inns, Econ {bform['econ']:.2f}" if bform else "no reliable recent history"),
                    "",
                    "MOMENTUM / PARTNERSHIP",
                    f"Partnership        : {pr} from {pb} balls | {r.get('partnership_rpb',0):.2f} runs/ball",
                    f"Boundary momentum  : {r.get('boundary_momentum')}",
                    f"Wicket momentum    : {'Low (no wicket in innings)' if w==0 else r.get('wicket_momentum')}",
                    f"Balls since boundary: {bsb if _l12.get('verified') else '--'}",
                    f"Balls since wicket  : {'No wicket yet ('+str(b)+' balls)' if w==0 else bsw}",
                    "",
                    "REMAINING RESOURCES",
                    f"Yet-to-bat strength       : {r.get('yet_strength')}/100 | coverage {r.get('yet_coverage')}%",
                    f"Remaining bowling strength: {r.get('remaining_bowl_strength')}/100 | coverage {r.get('remaining_bowl_coverage')}%",
                    "",
                    "PIN-TO-PIN FORECAST",
                    f"Next {r['next1_n']} balls expected runs : {r['next1']}",
                    f"  Boundary probability               : {r['boundary1']}%",
                    f"  Wicket probability                 : {r['wicket1']}%",
                    f"Next {r['next2_n']} balls expected runs: {r['next2']}",
                    f"  Boundary probability               : {r['boundary2']}%",
                    f"  Wicket probability                 : {r['wicket2']}%",
                    "",
                    f"FINAL SCORE CENTRAL PREDICTION : {r['pred']}",
                    f"LIKELY FINAL SCORE RANGE (80%) : {r['low']} - {r['high']}",
                    f"CORE FINAL SCORE RANGE (50%)   : {r.get('p25','--')} - {r.get('p75','--')}",
                    f"Raw pre-resource projection    : {r.get('raw_pred_before_resource_calibration','--')}",
                    f"Calibrated future pace         : {r.get('resource_future_rpb','--')} runs/ball",
                    f"Historical XI coverage        : {r['coverage']}%",
                    f"Professional live coverage    : {r['live_coverage']}%",
                    "",
                    "ANALYST TECHNICAL VIEW",
                    f"Combined batters rate / 100 balls: {r.get('current_pair_sr',0)}",
                    f"Partnership run rate/ball     : {r.get('partnership_rpb',0)}",
                    f"Boundary momentum             : {r.get('boundary_momentum')}",
                    f"Wicket momentum               : {r.get('wicket_momentum')}",
                    f"Remaining batting resource    : {r.get('yet_strength')}/100",
                    f"Remaining bowling resource    : {r.get('remaining_bowl_strength')}/100",
                    f"Pressure index                 : {r.get('resource_pressure',{}).get('pressure','--')}/100",
                    f"Momentum index                 : {r.get('resource_pressure',{}).get('momentum','--')}/100",
                    "",
                    "PROBABILISTIC SCENARIOS",
                    f"Suppressed / collapse outcome : {r.get('scenario_probabilities',{}).get('suppressed_or_collapse','--')}%",
                    f"Central outcome               : {r.get('scenario_probabilities',{}).get('central','--')}%",
                    f"Acceleration / upper outcome  : {r.get('scenario_probabilities',{}).get('acceleration','--')}%",
                ]
                if r.get("flags"):
                    txt += ["","COACH TECHNICAL FLAGS"]+[f"- {x}" for x in r["flags"]]
                try:
                    _parts,_conf,_label,_bp,_op=self._advanced_data_quality(fmt,bx,ox)
                    txt += ["",f"MODEL INPUT CONFIDENCE: {_conf}/100 — {_label}",
                            "This confidence measures data quality/coverage, not guaranteed prediction accuracy."]
                except Exception:
                    pass
                self.output.delete("1.0","end"); self.output.insert("1.0","\n".join(txt))
            else:
                t=self._live_int(self.target)
                if t<=0: raise ValueError("Enter target for second innings.")
                _total=self._effective_total_balls(fmt); _pp=self._effective_pp_balls(fmt)
                r=self.model.professional_live_chase(fmt,v,bx,ox,s,w,b,t,l,striker,non,bowler,
                    sr,sb,nr,nb,br,bb,bw,pr,pb,bsb,bsw,bd12,wk12,yet,avail,_total,_pp)
                _n=max(1,int(r.get("next1_n",6) or 6))
                _pb=clamp(1-(1-clamp(float(r.get("boundary1",0))/100,0,.999))**(1/_n),.02,.34)
                _pw=clamp(1-(1-clamp(float(r.get("wicket1",0))/100,0,.999))**(1/_n),.012,.18)
                _mean=max(.25,safe_div(float(r.get("pred",s))-s,max(1,_total-b),safe_div(l,_n,.8)))
                _dist=self._professional_run_distribution(s,w,b,_total,_mean,_pb,_pw)
                _samples=_dist.get("samples",[]) or [s]
                _sim_win=100*sum(x>=t for x in _samples)/max(1,len(_samples))
                # Blend state-equation and simulated probabilities. The blend
                # prevents either a sparse-history prior or a short hot streak
                # from dominating the chase assessment.
                _base_win=float(r.get("win",50))
                _blend_win=clamp(_base_win*.42+_sim_win*.58,1,99)
                r["win"]=round(_blend_win,1);r["loss"]=round(100-_blend_win,1)
                r["projected"]=_dist["median"]
                r["projected_p10"]=_dist["p10"];r["projected_p90"]=_dist["p90"]
                r["simulation_win"]=round(_sim_win,1)
                self.latest_model_result=dict(r)
                self.latest_model_result["innings"]="2nd"
                txt=[
                    f"{fmt} PROFESSIONAL LIVE CHASE ENGINE",
                    "="*82,
                    f"{self.bat_team.get()} {s}/{w} after {b} balls | Target {t}",
                    f"Need {r['need']} from {r['rem']} balls | RRR {r['rrr']}",
                    "",
                    "CURRENT MATCHUP",
                    f"Striker: {striker} {sr}({sb}) | Non-striker: {non} {nr}({nb})",
                    f"Bowler : {bowler} {br}/{bw} from {bb} balls",
                    "",
                    "PIN-TO-PIN FORECAST",
                    f"Next {r['next1_n']} balls expected runs : {r['next1']} | Wicket {r['wicket1']}% | Boundary {r['boundary1']}%",
                    f"Next {r['next2_n']} balls expected runs: {r['next2']} | Wicket {r['wicket2']}% | Boundary {r['boundary2']}%",
                    "",
                    f"WIN PROBABILITY  : {r['win']}%",
                    f"LOSS PROBABILITY : {r['loss']}%",
                    f"Projected finish : {r.get('projected',r.get('pred'))}",
                    f"Projected finish 80% range: {r.get('projected_p10','--')} - {r.get('projected_p90','--')}",
                    f"Distribution-only chase success: {r.get('simulation_win','--')}%",
                    f"Professional live coverage: {r['live_coverage']}%",
                    "",
                    f"Boundary momentum: {r.get('boundary_momentum')} | Wicket momentum: {r.get('wicket_momentum')}",
                    f"Yet-to-bat strength: {r.get('yet_strength')}/100",
                    f"Remaining bowling strength: {r.get('remaining_bowl_strength')}/100",
                ]
                if r.get("flags"):
                    txt += ["","COACH TECHNICAL FLAGS"]+[f"- {x}" for x in r["flags"]]
                try:
                    _parts,_conf,_label,_bp,_op=self._advanced_data_quality(fmt,bx,ox)
                    txt += ["",f"MODEL INPUT CONFIDENCE: {_conf}/100 — {_label}",
                            "This confidence measures data quality/coverage, not guaranteed prediction accuracy."]
                except Exception:
                    pass
                self.output.delete("1.0","end"); self.output.insert("1.0","\n".join(txt))
        except Exception as e:
            messagebox.showerror("Prediction error",str(e))

    def checkpoint(self):
        self.live_predict()
        self.log.append({
            "time":datetime.now().isoformat(timespec="seconds"),
            "format":self.format_var.get(),
            "innings":self.innings_var.get(),
            "venue":self.venue.get(),
            "batting_team":self.bat_team.get(),
            "bowling_team":self.bowl_team.get(),
            "score":self.score.get(),"wickets":self.wkts.get(),"balls":self.balls.get(),
            "target":self.target.get(),
            "analysis":self.output.get("1.0","end").strip().replace("\n"," | ")
        })
        messagebox.showinfo("Saved",f"Checkpoint #{len(self.log)} saved.")

    def export_log(self):
        if not self.log:
            messagebox.showinfo("No checkpoints","Save at least one checkpoint."); return
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="prediction_log.csv")
        if not p:return
        with open(p,"w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=self.log[0].keys()); w.writeheader(); w.writerows(self.log)
        messagebox.showinfo("Exported",p)

    def build_technical_analysis(self):
        ttk.Label(self.tab_technical,text="Current Match Technical Analysis",font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_technical,text="Ball-by-ball pressure, scoring efficiency, momentum, resources and forecast.").pack()
        ttk.Button(self.tab_technical,text="REFRESH TECHNICAL ANALYSIS",command=self.refresh_technical_analysis).pack(pady=6)
        self.technical_out=tk.Text(self.tab_technical,height=38,font=("Consolas",11),wrap="word")
        self.technical_out.pack(fill="both",expand=True)

    def build_advanced_analyst(self):
        ttk.Label(self.tab_advanced,text="Advanced Analyst — Confidence & Model Drivers",
                  font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_advanced,
                  text="Separates verified facts, model inputs, confidence, phase strength and forecast drivers.").pack()
        ttk.Button(self.tab_advanced,text="REFRESH ADVANCED ANALYSIS",
                   command=self.refresh_advanced_analyst).pack(pady=6)
        self.advanced_out=tk.Text(self.tab_advanced,height=40,font=("Consolas",11),wrap="word")
        self.advanced_out.pack(fill="both",expand=True)

    def build_player_intelligence(self):
        ttk.Label(self.tab_player_intel,text="Player Intelligence — Universal Multi-Source",
                  font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_player_intel,
                  text="Automatic hierarchy: local ball-level history → verified Cricbuzz recent history → current-match evidence → limited-data fallback.").pack()
        fr=ttk.Frame(self.tab_player_intel);fr.pack(pady=6)
        ttk.Button(fr,text="REFRESH PLAYER INTELLIGENCE",command=self.refresh_player_intelligence).pack(side="left",padx=4)
        ttk.Button(fr,text="ENRICH MISSING PLAYERS ONLINE",command=lambda:self.start_online_player_enrichment(force=True)).pack(side="left",padx=4)
        self.player_online_status=tk.StringVar(value="Online enrichment: waiting for verified Playing XI/profile links.")
        ttk.Label(self.tab_player_intel,textvariable=self.player_online_status,font=("Arial",10,"bold")).pack(pady=(0,5))
        self.player_intel_out=tk.Text(self.tab_player_intel,height=40,font=("Consolas",10),wrap="word")
        self.player_intel_out.pack(fill="both",expand=True)

    def _sparkline(self,values):
        vals=[float(v) for v in (values or [])]
        if not vals:return "--"
        blocks="▁▂▃▄▅▆▇█"
        lo=min(vals); hi=max(vals)
        if hi<=lo:return blocks[3]*len(vals)
        return "".join(blocks[min(7,max(0,int(round((v-lo)/(hi-lo)*7))))] for v in vals)

    def _trend_label(self,values,lower_is_better=False):
        vals=[float(v) for v in (values or [])]
        if len(vals)<4:return "Insufficient sample"
        # DB rows are newest first: reverse to chronological order.
        vals=list(reversed(vals))
        half=max(2,len(vals)//2)
        early=statistics.mean(vals[:half])
        late=statistics.mean(vals[-half:])
        denom=max(1.0,abs(early))
        change=(late-early)/denom
        if lower_is_better:change=-change
        if change>0.15:return "Rising"
        if change<-0.15:return "Falling"
        return "Stable"

    def _phase_team_ratings(self,names,fmt,kind):
        pp=[]; mid=[]; death=[]; covered=0
        for p in (names or []):
            if kind=="bat":
                s=self.db.player_batting(p,fmt)
                if not s:continue
                covered+=1
                # Map phase SR to 0-100 around realistic short-format baselines.
                pp.append(clamp(50+(s["pp_sr"]-(130 if fmt=="T20" else 135))*0.35,10,95))
                mid.append(clamp(50+(s["mid_sr"]-(125 if fmt=="T20" else 130))*0.35,10,95))
                death.append(clamp(50+(s["death_sr"]-(155 if fmt=="T20" else 160))*0.28,10,95))
            else:
                s=self.db.player_bowling(p,fmt)
                if not s:continue
                covered+=1
                base=8.3 if fmt=="T20" else 8.6
                pp.append(clamp(50+(base-s["pp_econ"])*6+s["pp_wkts"]*0.35,10,95))
                mid.append(clamp(50+(base-s["mid_econ"])*6+s["mid_wkts"]*0.30,10,95))
                death.append(clamp(50+(9.2-s["death_econ"])*5+s["death_wkts"]*0.25,10,95))
        return {
            "pp":round(statistics.mean(pp),1) if pp else 50.0,
            "mid":round(statistics.mean(mid),1) if mid else 50.0,
            "death":round(statistics.mean(death),1) if death else 50.0,
            "known":covered,"total":len(names or [])
        }

    def _advanced_data_quality(self,fmt,bx,ox):
        score_ok=100 if self._live_int(self.balls)>0 else 40
        striker_ok=100 if self.striker.get().strip() and "unknown" not in self.striker.get().lower() else 0
        non_ok=100 if self.non_striker.get().strip() and "unknown" not in self.non_striker.get().lower() else 0
        bowler_ok=100 if self.current_bowler.get().strip() and "unknown" not in self.current_bowler.get().lower() else 0
        matchup=(striker_ok+non_ok+bowler_ok)/3
        l6,l12=self._current_recent_metrics_from_widgets()
        recent=100 if l12.get("complete") else (round((l12.get("balls",0)/12)*100) if l12.get("verified") else 0)
        bp=self.model.xi_profile(bx,fmt) if bx else {"coverage":0,"known":0,"total":0}
        op=self.model.xi_profile(ox,fmt) if ox else {"coverage":0,"known":0,"total":0}
        xi_cov=(bp["coverage"]+op["coverage"])/2
        venue=100 if self.venue.get().strip() else 25
        resources=0
        if self.names(self.yet_to_bat):resources+=50
        if self.names(self.available_bowlers):resources+=50
        impact=100 if (self.names(self.bat_impact) or self.names(self.bowl_impact)) else 0
        form_known=0; form_total=0
        for p,kind in [(self.striker.get(),"bat"),(self.non_striker.get(),"bat"),(self.current_bowler.get(),"bowl")]:
            if not p or "unknown" in p.lower():continue
            form_total+=1
            f=self.db.recent_batting_form(p,fmt,10) if kind=="bat" else self.db.recent_bowling_form(p,fmt,10)
            if f:form_known+=min(1,f["innings"]/5)
        form=round(100*form_known/max(1,form_total),1) if form_total else 0
        parts={
            "Live score state":score_ok,
            "Current matchup":round(matchup,1),
            "Recent-ball window":recent,
            "XI historical coverage":round(xi_cov,1),
            "Venue specificity":venue,
            "Remaining resources":resources,
            "Impact/sub information":impact,
            "Recent form":form,
        }
        weights={
            "Live score state":0.22,"Current matchup":0.13,"Recent-ball window":0.13,
            "XI historical coverage":0.18,"Venue specificity":0.10,"Remaining resources":0.10,
            "Impact/sub information":0.04,"Recent form":0.10
        }
        overall=sum(parts[k]*weights[k] for k in parts)
        label="HIGH" if overall>=75 else "MODERATE" if overall>=55 else "LOW"
        return parts,round(overall,1),label,bp,op

    def _driver_attribution(self,fmt,bx,ox,bp,op):
        # This is transparent heuristic attribution to the current forecast,
        # not SHAP/exact causal decomposition.
        score=self._live_int(self.score); balls=self._live_int(self.balls); wk=self._live_int(self.wkts)
        total=self._effective_total_balls(fmt)
        current_rr=score*6/max(1,balls) if balls else 0
        venue=self.db.venue_stats(self.venue.get(),fmt)
        par_rr=venue["avg"]*6/total
        l6,l12=self._current_recent_metrics_from_widgets()
        recent_rr=l12.get("rr") if l12.get("verified") else None
        yet=self.names(self.yet_to_bat); avail=self.names(self.available_bowlers)
        yp=self.model.xi_profile(yet,fmt) if yet else {"batting":50}
        ap=self.model.xi_profile(avail,fmt) if avail else {"bowling":50}
        bimp=self._impact_profile(self.names(self.bat_impact),fmt,"bat")
        oimp=self._impact_profile(self.names(self.bowl_impact),fmt,"bowl")

        drivers=[]
        def add(name,weight,direction,reason):
            drivers.append({"name":name,"weight":weight,"direction":direction,"reason":reason})

        add("Live score / wickets",30,
            "UP" if current_rr>par_rr*1.05 and wk<=3 else "DOWN" if current_rr<par_rr*.9 or wk>=5 else "NEUTRAL",
            f"CRR {current_rr:.2f} vs venue-adjusted par RR {par_rr:.2f}; wickets {wk}.")
        xi_edge=bp["batting"]-op["bowling"]
        add("Confirmed XI quality",18,"UP" if xi_edge>4 else "DOWN" if xi_edge<-4 else "NEUTRAL",
            f"Batting {bp['batting']}/100 vs opposition bowling {op['bowling']}/100.")
        add("Venue / league baseline",12,"NEUTRAL",
            f"Baseline 1st-innings average {venue['avg']:.1f} from {venue['n']} innings"
            + (" (league fallback)." if venue.get("fallback") else "."))
        if recent_rr is None:
            add("Recent-ball momentum",12,"UNKNOWN","Verified recent delivery window unavailable.")
        else:
            add("Recent-ball momentum",12,"UP" if recent_rr>current_rr*1.12 else "DOWN" if recent_rr<current_rr*.88 else "NEUTRAL",
                f"Recent RR {recent_rr:.2f} vs innings CRR {current_rr:.2f}.")
        resource_edge=yp["batting"]-ap["bowling"]
        add("Remaining resources",10,"UP" if resource_edge>5 else "DOWN" if resource_edge<-5 else "NEUTRAL",
            f"Yet-to-bat {yp['batting']}/100 vs available bowling {ap['bowling']}/100.")
        matchup_known=sum(1 for p in [self.striker.get(),self.non_striker.get(),self.current_bowler.get()]
                          if p and "unknown" not in p.lower())
        add("Current batter-bowler matchup",8,"NEUTRAL" if matchup_known==3 else "UNKNOWN",
            f"{matchup_known}/3 current participants identified.")
        impact_edge=bimp["batting"]-oimp["bowling"]
        add("Impact / substitute options",4,"UP" if impact_edge>7 else "DOWN" if impact_edge<-7 else "NEUTRAL",
            f"Potential batting impact {bimp['batting']}/100 vs bowling impact {oimp['bowling']}/100.")
        form_vals=[]
        for p,kind in [(self.striker.get(),"bat"),(self.non_striker.get(),"bat"),(self.current_bowler.get(),"bowl")]:
            if not p or "unknown" in p.lower():continue
            f=self.db.recent_batting_form(p,fmt,10) if kind=="bat" else self.db.recent_bowling_form(p,fmt,10)
            if f:
                if kind=="bat":form_vals.append((f["sr"]-(135 if fmt=="T20" else 140))/30)
                else:form_vals.append(((8.5 if fmt=="T20" else 8.8)-f["econ"])/2)
        form_edge=statistics.mean(form_vals) if form_vals else 0
        add("Recent player form",6,"UP" if form_edge>.2 else "DOWN" if form_edge<-.2 else "NEUTRAL" if form_vals else "UNKNOWN",
            f"Recent-form samples available for {len(form_vals)} current players.")
        return drivers

    def refresh_advanced_analyst(self):
        try:
            fmt=self.format_var.get()
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
            parts,conf,label,bp,op=self._advanced_data_quality(fmt,bx,ox)
            drivers=self._driver_attribution(fmt,bx,ox,bp,op)
            bat_phase=self._phase_team_ratings(bx,fmt,"bat")
            bowl_phase=self._phase_team_ratings(ox,fmt,"bowl")

            lines=[
                f"{fmt} ADVANCED ANALYST REPORT","="*88,
                f"{self.bat_team.get() or 'Batting team'} vs {self.bowl_team.get() or 'Bowling team'}",
                f"Score: {self.score.get()}/{self.wkts.get()} after {self.balls.get()} balls",
                "",
                f"OVERALL MODEL CONFIDENCE: {conf}/100 — {label}",
                "Confidence measures input quality/coverage, not certainty that the forecast will be correct.",
                "",
                "DATA QUALITY / COVERAGE",
            ]
            for k,v in parts.items():
                lines.append(f"{k:<28}: {v:>5.1f}/100")
            lines += ["","PHASE-BY-PHASE TEAM RATINGS",
                      f"Batting Powerplay : {bat_phase['pp']}/100",
                      f"Batting Middle    : {bat_phase['mid']}/100",
                      f"Batting Death     : {bat_phase['death']}/100",
                      f"Bat phase coverage: {bat_phase['known']}/{bat_phase['total']} players",
                      "",
                      f"Bowling Powerplay : {bowl_phase['pp']}/100",
                      f"Bowling Middle    : {bowl_phase['mid']}/100",
                      f"Bowling Death     : {bowl_phase['death']}/100",
                      f"Bowl phase coverage: {bowl_phase['known']}/{bowl_phase['total']} players",
                      "",
                      "FORECAST DRIVER ATTRIBUTION",
                      "(Transparent heuristic attribution; not exact SHAP values.)"]
            for d in drivers:
                arrow={"UP":"↑","DOWN":"↓","NEUTRAL":"→","UNKNOWN":"?"}.get(d["direction"],"?")
                lines.append(f"{arrow} {d['name']:<29} weight {d['weight']:>2}% | {d['reason']}")

            lines += ["","ANALYST INTERPRETATION"]
            up=[d["name"] for d in drivers if d["direction"]=="UP"]
            down=[d["name"] for d in drivers if d["direction"]=="DOWN"]
            unknown=[d["name"] for d in drivers if d["direction"]=="UNKNOWN"]
            lines.append("Positive forecast drivers : "+(", ".join(up) if up else "None clearly dominant"))
            lines.append("Negative forecast drivers : "+(", ".join(down) if down else "None clearly dominant"))
            lines.append("Unresolved drivers        : "+(", ".join(unknown) if unknown else "None"))
            if conf<55:
                lines.append("Analyst caution: projection should be treated as broad because important inputs remain unresolved.")
            elif conf<75:
                lines.append("Analyst caution: usable forecast, but retain a wider outcome range.")
            else:
                lines.append("Analyst view: input coverage is strong enough for tighter live interpretation.")

            self.advanced_out.delete("1.0","end")
            self.advanced_out.insert("1.0","\n".join(lines))
        except Exception as e:
            messagebox.showerror("Advanced analyst",str(e))

    def _player_intel_lines(self,p,fmt):
        b=self.db.player_batting(p,fmt)
        bo=self.db.player_bowling(p,fmt)
        bf=self.db.recent_batting_form(p,fmt,10)
        bof=self.db.recent_bowling_form(p,fmt,10)
        online=self._online_record(p)
        out=[f"{p}"]
        if b:
            out.append("  SOURCE: LOCAL BALL-LEVEL DATABASE — highest historical confidence")
            scores=bf["scores"] if bf else []
            out.append(
                f"  BAT career: {b['matches']} matches | Avg {b['avg']:.1f} | SR {b['sr']:.1f} | "
                f"Dot {b['dot_pct']:.1f}% | Boundary-ball {b['boundary_pct']:.1f}%"
            )
            out.append(f"  Phase SR : PP {b['pp_sr']:.1f} | Middle {b['mid_sr']:.1f} | Death {b['death_sr']:.1f}")
            if bf:
                chronological=list(reversed(scores));thirty=sum(1 for x in scores if x>=30);fifty=sum(1 for x in scores if x>=50)
                mean=statistics.mean(scores) if scores else 0;sd=statistics.pstdev(scores) if len(scores)>1 else 0
                out.append(f"  Last {bf['innings']}: {chronological} | graph {self._sparkline(chronological)} | "
                           f"Trend {self._trend_label(scores)} | Avg score {mean:.1f} | volatility {sd:.1f} | "
                           f"30+ {thirty} | 50+ {fifty} | recent SR {bf['sr']:.1f}")
        elif online:
            rows=self._online_short_rows(p,"bat",fmt,10)
            if rows:
                runs=sum(int(x.get("runs",0) or 0) for x in rows);balls=sum(int(x.get("balls",0) or 0) for x in rows)
                scores=[int(x.get("runs",0) or 0) for x in rows];fours=sum(int(x.get("fours",0) or 0) for x in rows);sixes=sum(int(x.get("sixes",0) or 0) for x in rows)
                out.append("  SOURCE: ONLINE CRICBUZZ ALL-MATCHES — fallback confidence; cached locally")
                out.append(f"  Online short-format sample: {len(rows)} innings | Runs {runs} | SR {safe_div(runs*100,balls):.1f} | "
                           f"Avg score {safe_div(runs,len(rows)):.1f} | Boundaries {fours}x4 + {sixes}x6")
                out.append(f"  Recent scores: {list(reversed(scores))} | graph {self._sparkline(list(reversed(scores)))} | "
                           f"Trend {self._trend_label(scores)}")
                out.append("  Phase SR: unavailable online — NOT invented; local ball-level data required for PP/Middle/Death split.")
        if bo:
            if not b:out.append("  SOURCE: LOCAL BALL-LEVEL DATABASE — highest historical confidence")
            out.append(f"  BOWL career: {bo['matches']} matches | Econ {bo['econ']:.2f} | SR {bo['sr']:.1f} | "
                       f"Dot {bo['dot_pct']:.1f}% | Boundary conceded {bo['boundary_pct']:.1f}%")
            out.append(f"  Phase Econ: PP {bo['pp_econ']:.2f} | Middle {bo['mid_econ']:.2f} | Death {bo['death_econ']:.2f} | "
                       f"Phase wkts {bo['pp_wkts']}/{bo['mid_wkts']}/{bo['death_wkts']}")
            if bof:
                wk=list(reversed(bof.get("wickets_list",[])));ec=list(reversed(bof.get("econ_list",[])))
                out.append(f"  Last {bof['innings']} bowling: wkts {wk} | graph {self._sparkline(wk)} | "
                           f"Wicket trend {self._trend_label(bof.get('wickets_list',[]))} | Recent econ {bof['econ']:.2f} | "
                           f"Econ trend {self._trend_label(bof.get('econ_list',[]),lower_is_better=True)}")
        elif online:
            rows=self._online_short_rows(p,"bowl",fmt,10)
            if rows:
                wk=[int(x.get("wickets",0) or 0) for x in rows];runs=sum(int(x.get("runs",0) or 0) for x in rows)
                balls=0
                for x in rows:
                    ov=float(x.get("overs",0) or 0);whole=int(ov);frac=int(round((ov-whole)*10));balls+=whole*6+min(frac,5)
                if not b:out.append("  SOURCE: ONLINE CRICBUZZ ALL-MATCHES — fallback confidence; cached locally")
                out.append(f"  Online bowling sample: {len(rows)} matches | Wkts {sum(wk)} | Econ {safe_div(runs*6,balls,99):.2f} | "
                           f"Recent wickets {list(reversed(wk))} | graph {self._sparkline(list(reversed(wk)))}")
                out.append("  Phase economy/dot/boundary splits: unavailable online — NOT invented.")
        if not b and not bo and not online:
            # Present-match evidence, if the player has appeared today.
            current=(getattr(self,"latest_scorecard",{}) or {}).get("innings",[])
            live_rows=[]
            for inn in current:
                live_rows += [("BAT",x) for x in inn.get("batsmen",[]) if identity_score(p,x.get("name",""))>=.90]
                live_rows += [("BOWL",x) for x in inn.get("bowlers",[]) if identity_score(p,x.get("name",""))>=.90]
            if live_rows:
                out.append("  SOURCE: CURRENT MATCH ONLY — historical profile unavailable")
                for typ,x in live_rows[-2:]:
                    if typ=="BAT":out.append(f"  LIVE BAT: {x.get('runs',0)}({x.get('balls',0)}) | SR {float(x.get('strike_rate',0) or 0):.1f} | 4s {x.get('fours',0)} | 6s {x.get('sixes',0)}")
                    else:out.append(f"  LIVE BOWL: {x.get('wickets',0)}/{x.get('runs',0)} in {x.get('overs',0)} | Econ {float(x.get('economy',0) or 0):.2f}")
            else:
                out.append("  LIMITED DATA — no local history and no verified public profile yet. Model keeps this player near neutral with low confidence.")
        return out

    def refresh_player_intelligence(self):
        try:
            fmt=self.format_var.get()
            groups=[
                ("BATTING XI",self.names(self.bat_xi)),
                ("BOWLING XI",self.names(self.bowl_xi)),
                ("YET TO BAT",self.names(self.yet_to_bat)),
                ("AVAILABLE / UPCOMING BOWLERS",self.names(self.available_bowlers)),
                ("BATTING IMPACT / SUBS",self.names(self.bat_impact)),
                ("BOWLING IMPACT / SUBS",self.names(self.bowl_impact)),
            ]
            if not any(names for _,names in groups):
                live=[]
                for inn in (getattr(self,"latest_scorecard",{}) or {}).get("innings",[]):
                    live += [x.get("name","") for x in inn.get("batsmen",[])]
                    live += [x.get("name","") for x in inn.get("bowlers",[])]
                live += [self.striker.get(),self.non_striker.get(),self.current_bowler.get()]
                live=[x for x in dict.fromkeys(norm_name(x) for x in live) if x]
                groups=[("LIVE PLAYERS DETECTED — XI NOT YET AVAILABLE",live)]
            seen=set()
            online_count=sum(1 for _,v in self._online_player_cache.items() if isinstance(v,dict))
            lines=[f"{fmt} PLAYER INTELLIGENCE — MULTI-SOURCE","="*94,
                   "Priority: LOCAL ball-level history → ONLINE Cricbuzz all-match history → CURRENT MATCH ONLY → LIMITED DATA.",
                   "Online data is cached locally for future matches. Phase splits are shown only when ball-level local data exists.",
                   f"Online cache records: {online_count}"]
            for title,names in groups:
                lines += ["",title,"-"*94]
                fresh=[]
                for p in names:
                    k=player_key(p)
                    if k and k not in seen:
                        seen.add(k);fresh.append(p)
                if not fresh:
                    lines.append("Waiting for same-match player list.")
                    continue
                for p in fresh:
                    lines += self._player_intel_lines(p,fmt)+[""]
            self.player_intel_out.delete("1.0","end")
            self.player_intel_out.insert("1.0","\n".join(lines))
            if self._players_needing_online_enrichment() and not self._online_enrich_busy:
                self.root.after(200,self.start_online_player_enrichment)
        except Exception as e:
            messagebox.showerror("Player intelligence",str(e))

    def build_team_comparison(self):
        ttk.Label(self.tab_compare,text="Team Comparison — Present Match",font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_compare,text="Compares batting, bowling, recent form, resources, impact options and present-match advantage.").pack()
        ttk.Button(self.tab_compare,text="REFRESH TEAM COMPARISON",command=self.refresh_team_comparison).pack(pady=6)
        self.compare_out=tk.Text(self.tab_compare,height=38,font=("Consolas",11),wrap="word")
        self.compare_out.pack(fill="both",expand=True)

    def build_match_trend(self):
        ttk.Label(self.tab_trend,text="Present Match Trend Analysis",font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_trend,text="Tracks scoring pace, wickets, momentum shifts and projected finish across live refreshes.").pack()
        ttk.Button(self.tab_trend,text="REFRESH TREND ANALYSIS",command=self.refresh_match_trend).pack(pady=6)
        self.trend_out=tk.Text(self.tab_trend,height=38,font=("Consolas",11),wrap="word")
        self.trend_out.pack(fill="both",expand=True)

    def build_squad_intelligence(self):
        ttk.Label(self.tab_squad,text="Squad & Impact-Player Intelligence",font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_squad,text="Includes confirmed XI, yet-to-bat resources, available bowlers and impact/substitute candidates.").pack()
        ttk.Button(self.tab_squad,text="REFRESH SQUAD INTELLIGENCE",command=self.refresh_squad_intelligence).pack(pady=6)
        self.squad_out=tk.Text(self.tab_squad,height=38,font=("Consolas",11),wrap="word")
        self.squad_out.pack(fill="both",expand=True)

    def _validated_live_state(self):
        """
        Hard consistency layer. The official scoreboard is authoritative.
        Parsed commentary may be incomplete/stale and is never allowed to contradict it.
        """
        score=self._live_int(self.score)
        wkts=self._live_int(self.wkts)
        balls=self._live_int(self.balls)
        l6,l12=self._current_recent_metrics_from_widgets_raw()

        notes=[]
        # Impossible: recent wickets exceed total wickets in current innings.
        if l6.get("verified") and l6.get("wickets",0)>wkts:
            notes.append("Recent 6-ball wicket data contradicted innings wickets; wicket metric suppressed.")
            l6=dict(l6); l6["wickets"]=0 if wkts==0 else min(l6["wickets"],wkts)
        if l12.get("verified") and l12.get("wickets",0)>wkts:
            notes.append("Recent 12-ball wicket data contradicted innings wickets; wicket metric suppressed.")
            l12=dict(l12); l12["wickets"]=0 if wkts==0 else min(l12["wickets"],wkts)

        # If innings is 0 wickets, no recent window can contain a wicket.
        if wkts==0:
            if l6.get("verified"): l6=dict(l6); l6["wickets"]=0
            if l12.get("verified"): l12=dict(l12); l12["wickets"]=0

        # Recent runs cannot exceed the innings score.
        for name,m in (("6-ball",l6),("12-ball",l12)):
            if m.get("verified") and m.get("runs",0)>score:
                notes.append(f"{name} parsed runs exceeded innings score; recent window marked unavailable.")
                m.update({"verified":False,"complete":False,"balls":0,"runs":0,
                          "dot_pct":None,"boundary_pct":None,"scoring_pct":None,"rr":None,
                          "dots":0,"boundaries":0,"fours":0,"sixes":0,"wickets":0})

        # Partnership is deterministic before first wicket.
        pr=self._live_int(self.part_runs)
        pb=self._live_int(self.part_balls)
        if wkts==0:
            if pr!=score or pb!=balls:
                notes.append("Opening partnership corrected to official score/balls because no wicket has fallen.")
            pr=score; pb=balls

        # Since-wicket: at 0 wickets it means since innings start.
        bsw=self._live_int(self.since_wicket)
        if wkts==0:
            bsw=balls

        return {
            "score":score,"wkts":wkts,"balls":balls,
            "l6":l6,"l12":l12,"part_runs":pr,"part_balls":pb,
            "balls_since_wicket":bsw,"notes":notes
        }

    def _current_recent_metrics_from_widgets_raw(self):
        deliveries=getattr(self,"_latest_deliveries",[]) or []
        if deliveries:
            l6,l12=self._recent_ball_metrics(deliveries)
            if l6.get("verified") or l12.get("verified"):
                return l6,l12
        empty=lambda n: {
            "balls":0,"runs":0,"dots":0,"boundaries":0,"fours":0,"sixes":0,"wickets":0,
            "dot_pct":None,"boundary_pct":None,"scoring_pct":None,"rr":None,
            "complete":False,"verified":False
        }
        return empty(6),empty(12)

    def _current_recent_metrics_from_widgets(self):
        state=self._validated_live_state()
        return state["l6"],state["l12"]

    def _impact_profile(self,names,fmt,side):
        if not names:
            return {"batting":50.0,"bowling":50.0,"coverage":0.0,"details":[]}
        prof=self.model.xi_profile(names,fmt)
        details=[]
        for p in names:
            b=self.model.batter_score(p,fmt)
            bo=self.model.bowler_score(p,fmt)
            details.append({
                "name":p,
                "bat":b[0] if b else None,
                "bowl":bo[0] if bo else None
            })
        return {"batting":prof["batting"],"bowling":prof["bowling"],"coverage":prof["coverage"],"details":details}

    def refresh_technical_analysis(self):
        try:
            fmt=self.format_var.get()
            _vs=self._validated_live_state()
            score=_vs["score"]; wkts=_vs["wkts"]; balls=_vs["balls"]
            target=self._live_int(self.target) if self.innings_var.get()=="2nd Innings" else None
            l6,l12=_vs["l6"],_vs["l12"]
            total=self._effective_total_balls(fmt)
            idx=self._technical_indices(l6,l12,score,wkts,balls,target,total)
            crr=round(score*6/max(1,balls),2) if balls else 0
            rem=max(0,total-balls)
            req=round(max(0,target-score)*6/max(1,rem),2) if target else None

            def val(x,suffix=""):
                return "--" if x is None else f"{x}{suffix}"
            def quality(m,n):
                if not m.get("verified"): return "UNAVAILABLE — delivery outcomes not exposed by live feed"
                if m.get("complete"): return f"VERIFIED {n}-BALL WINDOW"
                return f"PARTIAL — {m.get('balls',0)} of {n} legal balls parsed"

            boundary_to_ball=(round(100/l12["boundary_pct"],1)
                              if l12.get("boundary_pct") not in (None,0) else None)
            dot_to_scoring=(round(l12["dot_pct"]/l12["scoring_pct"],2)
                            if l12.get("dot_pct") is not None and l12.get("scoring_pct") not in (None,0) else None)

            lines=[
                f"{fmt} CURRENT MATCH TECHNICAL ANALYSIS","="*84,
                f"Score: {score}/{wkts} | Balls: {balls}/{total} | CRR: {crr}",
            ]
            if req is not None: lines.append(f"Target: {target} | Required RR: {req}")
            lines += ["","LAST 6 BALLS — MICRO MOMENTUM",f"Data quality         : {quality(l6,6)}"]
            if l6.get("verified"):
                lines += [
                    f"Parsed legal balls   : {l6['balls']}",
                    f"Runs                 : {l6['runs']}",
                    f"Equivalent RR        : {val(l6['rr'])}",
                    f"Dot balls            : {l6['dots']} ({val(l6['dot_pct'],'%')})",
                    f"Boundary balls       : {l6['boundaries']} ({val(l6['boundary_pct'],'%')})",
                    f"Scoring-shot %       : {val(l6['scoring_pct'],'%')}",
                    f"Wickets              : {l6['wickets']}",
                ]
            lines += ["","LAST 12 BALLS — SHORT-TERM TREND",f"Data quality         : {quality(l12,12)}"]
            if l12.get("verified"):
                lines += [
                    f"Parsed legal balls   : {l12['balls']}",
                    f"Runs                 : {l12['runs']}",
                    f"Equivalent RR        : {val(l12['rr'])}",
                    f"Dot-ball %           : {val(l12['dot_pct'],'%')}",
                    f"Boundary-ball %      : {val(l12['boundary_pct'],'%')}",
                    f"Scoring-shot %       : {val(l12['scoring_pct'],'%')}",
                    f"Fours / Sixes        : {l12['fours']} / {l12['sixes']}",
                    f"Wickets              : {l12['wickets']}",
                    f"Balls per boundary   : {val(boundary_to_ball)}",
                    f"Dot-to-scoring ratio : {val(dot_to_scoring)}",
                ]
            lines += ["","ANALYST PRESSURE INDICES"]
            if idx["dot_pressure"] is None:
                lines.append("Unavailable until verified recent delivery outcomes are parsed.")
            else:
                lines += [
                    f"Dot-ball pressure    : {idx['dot_pressure']}/100",
                    f"Boundary threat      : {idx['boundary_threat']}/100",
                    f"Wicket pressure      : {idx['wicket_pressure']}/100",
                    f"Acceleration index   : {idx['acceleration_index']}/100",
                ]
                if idx["chase_pressure_index"] is not None:
                    lines.append(f"Chase pressure       : {idx['chase_pressure_index']}/100")

            striker=self.striker.get().strip(); non=self.non_striker.get().strip()
            bowler=self.current_bowler.get().strip()
            lines += [
                "","CURRENT MATCHUP",
                f"Striker              : {striker or '--'} {self.striker_runs.get()}({self.striker_balls.get()})",
                f"Non-striker          : {non or '--'} {self.non_runs.get()}({self.non_balls.get()})",
                f"Current bowler        : {bowler or '--'} | {self.bowler_runs_live.get()} runs, {self.bowler_wkts_live.get()} wkts",
                f"Partnership          : {_vs['part_runs']} from {_vs['part_balls']} balls",
                f"Balls since boundary : {self.since_boundary.get() if l12.get('verified') else '--'}",
                f"Balls since wicket   : {'No wicket yet ('+str(balls)+' balls)' if wkts==0 else (str(_vs['balls_since_wicket']) if l12.get('verified') else '--')}",
            ]
            if _vs.get("notes"):
                lines += ["","CONSISTENCY VALIDATION"]
                lines += [f"- {x}" for x in _vs["notes"]]
            pred_text=self.output.get("1.0","end").strip() if hasattr(self,"output") else ""
            if pred_text:
                lines += ["","LATEST PREDICTION SNAPSHOT","-"*84]+pred_text.splitlines()[:24]
            self.technical_out.delete("1.0","end")
            self.technical_out.insert("1.0","\n".join(lines))
        except Exception as e:
            messagebox.showerror("Technical analysis",str(e))

    def refresh_team_comparison(self):
        try:
            fmt=self.format_var.get()
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
            bp=self.model.xi_profile(bx,fmt) if bx else {"batting":50,"bowling":50,"coverage":0}
            op=self.model.xi_profile(ox,fmt) if ox else {"batting":50,"bowling":50,"coverage":0}
            bimpact=self._impact_profile(self.names(self.bat_impact),fmt,"bat")
            oimpact=self._impact_profile(self.names(self.bowl_impact),fmt,"bowl")
            yet=self.names(self.yet_to_bat)
            avail=self.names(self.available_bowlers)
            yetp=self.model.xi_profile(yet,fmt) if yet else {"batting":50,"coverage":0}
            avp=self.model.xi_profile(avail,fmt) if avail else {"bowling":50,"coverage":0}
            l6,l12=self._current_recent_metrics_from_widgets()
            score=self._live_int(self.score); wk=self._live_int(self.wkts); balls=self._live_int(self.balls)
            crr=round(score*6/max(1,balls),2) if balls else 0

            bat_effective=bp["batting"]*0.82 + bimpact["batting"]*0.08 + yetp["batting"]*0.10
            bowl_effective=op["bowling"]*0.82 + oimpact["bowling"]*0.08 + avp["bowling"]*0.10
            live_edge=(l12["rr"]-crr)*2 if balls else 0
            advantage=bat_effective-bowl_effective+live_edge
            if advantage>7: verdict="Batting side currently has a clear analytical edge."
            elif advantage<-7: verdict="Bowling side currently has a clear analytical edge."
            else: verdict="Present-match balance is relatively even."

            lines=[
                f"{fmt} TEAM COMPARISON — PRESENT MATCH",
                "="*84,
                f"{self.bat_team.get() or 'Batting team'} vs {self.bowl_team.get() or 'Bowling team'}",
                "",
                "CORE XI",
                f"Batting XI batting strength : {bp['batting']}/100 | coverage {bp['coverage']}%",
                f"Bowling XI bowling strength : {op['bowling']}/100 | coverage {op['coverage']}%",
                "",
                "REMAINING RESOURCES",
                f"Yet-to-bat batting strength : {yetp['batting']}/100 | coverage {yetp['coverage']}%",
                f"Available bowlers strength  : {avp['bowling']}/100 | coverage {avp['coverage']}%",
                "",
                "IMPACT / SUBSTITUTE OPTIONS",
                f"Bat-side impact batting     : {bimpact['batting']}/100 | coverage {bimpact['coverage']}%",
                f"Bowl-side impact bowling    : {oimpact['bowling']}/100 | coverage {oimpact['coverage']}%",
                "",
                "PRESENT MATCH TREND",
                f"Current RR                  : {crr}",
                f"Last-12 equivalent RR       : {l12['rr']}",
                f"Last-12 dot-ball %          : {l12['dot_pct']}%",
                f"Last-12 boundary-ball %     : {l12['boundary_pct']}%",
                f"Last-12 wickets             : {l12['wickets']}",
                "",
                f"Effective batting resource  : {round(bat_effective,1)}/100",
                f"Effective bowling resource  : {round(bowl_effective,1)}/100",
                f"Present analytical edge     : {round(advantage,1)}",
                f"Assessment                  : {verdict}",
            ]
            self.compare_out.delete("1.0","end")
            self.compare_out.insert("1.0","\n".join(lines))
        except Exception as e:
            messagebox.showerror("Team comparison",str(e))

    def refresh_match_trend(self):
        try:
            snaps=getattr(self,"live_snapshots",[]) or []
            lines=["PRESENT MATCH TREND ANALYSIS","="*84]
            if not snaps:
                lines.append("No live snapshots yet. Connect a live match and enable auto refresh.")
            else:
                recent=snaps[-12:]
                lines += ["Recent live checkpoints:"]
                prev=None
                for s in recent:
                    score=int(s.get("score",0)); wk=int(s.get("wickets",0)); balls=int(s.get("balls",0))
                    rr=round(score*6/max(1,balls),2) if balls else 0
                    delta=""
                    if prev:
                        dr=score-int(prev.get("score",0))
                        dw=wk-int(prev.get("wickets",0))
                        db=balls-int(prev.get("balls",0))
                        delta=f" | +{dr} runs, +{dw} wkts in {db} balls"
                    lines.append(f"{balls:>3} balls : {score}/{wk} | RR {rr}{delta}")
                    prev=s

                if len(recent)>=2:
                    first=recent[0]; last=recent[-1]
                    dr=int(last["score"])-int(first["score"])
                    dw=int(last["wickets"])-int(first["wickets"])
                    db=max(1,int(last["balls"])-int(first["balls"]))
                    segment_rr=round(dr*6/db,2)
                    lines += [
                        "",
                        "TREND SUMMARY",
                        f"Segment runs        : {dr}",
                        f"Segment wickets     : {dw}",
                        f"Segment balls       : {db}",
                        f"Segment run rate    : {segment_rr}",
                        f"Run momentum        : {'Accelerating' if segment_rr>9 else 'Controlled' if segment_rr>=7 else 'Under pressure'}",
                        f"Wicket momentum     : {'High pressure' if dw>=2 else 'Stable' if dw==0 else 'Moderate pressure'}",
                    ]

            l6,l12=self._current_recent_metrics_from_widgets()
            lines += [
                "",
                "LATEST BALL TREND",
                f"Last 6: {l6['runs']} runs | dot {l6['dot_pct']}% | boundary {l6['boundary_pct']}% | wickets {l6['wickets']}",
                f"Last 12: {l12['runs']} runs | dot {l12['dot_pct']}% | boundary {l12['boundary_pct']}% | wickets {l12['wickets']}",
            ]
            self.trend_out.delete("1.0","end")
            self.trend_out.insert("1.0","\n".join(lines))
        except Exception as e:
            messagebox.showerror("Trend analysis",str(e))

    def refresh_squad_intelligence(self):
        try:
            fmt=self.format_var.get()
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
            bimp=self.names(self.bat_impact); oimp=self.names(self.bowl_impact)
            yet=self.names(self.yet_to_bat); avail=self.names(self.available_bowlers)
            lines=[
                f"{fmt} SQUAD / IMPACT-PLAYER INTELLIGENCE",
                "="*84,
                f"Batting team: {self.bat_team.get() or '--'}",
                f"Bowling team: {self.bowl_team.get() or '--'}",
                "",
                "UPCOMING BATTERS",
                "-"*84,
            ]
            lines += self._resource_lines(yet,fmt,"bat") if yet else ["No upcoming-batter list available."]
            lines += ["","AVAILABLE / UPCOMING BOWLERS","-"*84]
            lines += self._resource_lines(avail,fmt,"bowl") if avail else ["No available-bowler list available."]
            lines += ["","BATTING-SIDE IMPACT / SUB CANDIDATES","-"*84]
            lines += self._resource_lines(bimp,fmt,"bat") if bimp else ["No impact/sub candidates entered or detected."]
            lines += ["","BOWLING-SIDE IMPACT / SUB CANDIDATES","-"*84]
            lines += self._resource_lines(oimp,fmt,"bowl") if oimp else ["No impact/sub candidates entered or detected."]

            # Effective resource view
            bp=self.model.xi_profile(bx,fmt) if bx else {"batting":50,"coverage":0}
            op=self.model.xi_profile(ox,fmt) if ox else {"bowling":50,"coverage":0}
            bprof=self._impact_profile(bimp,fmt,"bat")
            oprof=self._impact_profile(oimp,fmt,"bowl")
            lines += [
                "",
                "RESOURCE SUMMARY",
                f"Confirmed XI batting strength  : {bp['batting']}/100",
                f"Confirmed XI bowling strength  : {op['bowling']}/100",
                f"Impact batting pool strength   : {bprof['batting']}/100",
                f"Impact bowling pool strength   : {oprof['bowling']}/100",
                "",
                "Model note: impact/substitute players are treated as potential resources, not guaranteed participants.",
            ]
            self.squad_out.delete("1.0","end")
            self.squad_out.insert("1.0","\n".join(lines))
        except Exception as e:
            messagebox.showerror("Squad intelligence",str(e))

    def refresh_all_analysis_tabs(self):
        for fn in (
            self.refresh_technical_analysis,
            self.refresh_advanced_analyst,
            self.refresh_team_comparison,
            self.refresh_match_trend,
            self.refresh_squad_intelligence,
            self.refresh_player_intelligence,
        ):
            try:
                fn()
            except Exception:
                pass

    def build_coach(self):
        ttk.Label(self.tab_coach,text="Professional Coach Assessment",font=("Arial",18,"bold")).pack(pady=8)
        ttk.Label(self.tab_coach,text="Technical interpretation of live state, venue, XI strength, momentum and likely next events.").pack()
        ttk.Button(self.tab_coach,text="GENERATE COACH REPORT",command=self.coach_report).pack(pady=8)
        self.coach_out=tk.Text(self.tab_coach,height=35,font=("Consolas",11),wrap="word")
        self.coach_out.pack(fill="both",expand=True)

    def build_xi_report(self):
        ttk.Label(self.tab_xi,text="Playing XI Technical Report",font=("Arial",18,"bold")).pack(pady=8)
        ttk.Label(self.tab_xi,text="Player-by-player batting/bowling ratings, role signals and data coverage.").pack()
        ttk.Button(self.tab_xi,text="GENERATE XI REPORT",command=self.xi_report).pack(pady=8)
        self.xi_out=tk.Text(self.tab_xi,height=35,font=("Consolas",11),wrap="word")
        self.xi_out.pack(fill="both",expand=True)

    def coach_report(self):
        try:
            self._hydrate_live_matchup_from_sources()
            # Generate full professional live output first. Partial matchup now uses
            # neutral placeholders rather than aborting the entire coach report.
            self.live_predict()
            main_text=self.output.get("1.0","end").strip()
            fmt=self.format_var.get(); venue=self.venue.get()
            bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
            s=self._live_int(self.score); w=self._live_int(self.wkts); b=self._live_int(self.balls)
            target=self._live_int(self.target) if self.innings_var.get()=="2nd Innings" else None
            last=self._live_int(self.last)
            a=self.model.technical_assessment(fmt,venue,bx,ox,s,w,b,target,last)
            extra=[
                "",
                "="*82,
                "COACH SUMMARY",
                f"Batting unit assessment : {a.get('batting_band','--')}",
                f"Bowling unit assessment : {a.get('bowling_band','--')}",
                f"Venue type              : {a.get('venue_type','--')}",
                f"Tempo vs par            : {a.get('tempo','--')}",
                f"Wicket state            : {a.get('wicket_state','--')}",
                f"Momentum                : {a.get('momentum','--')}",
            ]
            if target:
                extra.append(f"Chase pressure          : {a.get('chase_pressure','--')}")
            self.coach_out.delete("1.0","end")
            self.coach_out.insert("1.0",main_text+"\n"+"\n".join(extra))
        except Exception as e:
            messagebox.showerror("Coach report",str(e))

    def xi_report(self):
        fmt=self.format_var.get()
        bx=self.names(self.bat_xi); ox=self.names(self.bowl_xi)
        if not bx or not ox:
            messagebox.showerror("XI report","Enter both Playing XIs first.")
            return

        def player_line(p):
            b=self.model.batter_score(p,fmt)
            bo=self.model.bowler_score(p,fmt)
            parts=[p]
            if b:
                parts.append(f"Bat {b[0]}/100 | SR {b[1]['sr']:.1f} | Avg {b[1]['avg']:.1f} | Death SR {b[1]['death_sr']:.1f}")
            else:
                parts.append("Bat: no history")
            if bo:
                parts.append(f"Bowl {bo[0]}/100 | Econ {bo[1]['econ']:.2f} | Wkts {bo[1]['wickets']} | Death Econ {bo[1]['death_econ']:.2f}")
            else:
                parts.append("Bowl: no history")
            return " | ".join(parts)

        bp=self.model.xi_profile(bx,fmt)
        op=self.model.xi_profile(ox,fmt)
        lines=[
            f"{fmt} XI TECHNICAL REPORT",
            "="*78,
            f"{self.bat_team.get()} — batting XI",
            f"Overall batting strength: {bp['batting']}/100 | Coverage: {bp['coverage']}%",
            "-"*78
        ]
        lines += [player_line(p) for p in bx]
        lines += ["","",f"{self.bowl_team.get()} — opposition XI",
                  f"Overall bowling strength: {op['bowling']}/100 | Coverage: {op['coverage']}%",
                  "-"*78]
        lines += [player_line(p) for p in ox]

        self.xi_out.delete("1.0","end")
        self.xi_out.insert("1.0","\n".join(lines))

    def build_market_intelligence(self):
        ttk.Label(self.tab_market,text="Exchange Live Data — Same Match Extractor",
                  font=("Arial",18,"bold")).pack(pady=6)
        ttk.Label(self.tab_market,
                  text="Extracts every visible exchange market row for the same live cricket match: "
                       "Match Odds, Bookmaker, Fancy/Session, Line, Ball-by-Ball, Khado, Tied Match, Back/Lay, No/Yes and limits.").pack()

        top=ttk.LabelFrame(self.tab_market,text="Dubaiexch247 Source",padding=8)
        top.pack(fill="x",pady=6)
        self.market_url=tk.StringVar(value="")
        self.market_refresh_seconds=tk.StringVar(value="8")
        self.market_auto=tk.BooleanVar(value=False)

        ttk.Label(top,text="Exact live match/event URL").grid(row=0,column=0,sticky="w")
        ttk.Entry(top,textvariable=self.market_url,width=88).grid(row=0,column=1,columnspan=5,padx=4,sticky="ew")
        ttk.Label(top,text="Refresh").grid(row=1,column=0,sticky="w")
        ttk.Combobox(top,textvariable=self.market_refresh_seconds,
                     values=["5","8","10","15","30"],width=8,state="readonly").grid(row=1,column=1,sticky="w")
        ttk.Checkbutton(top,text="Auto refresh",variable=self.market_auto,
                        command=self.toggle_market_auto).grid(row=1,column=2,padx=4)
        ttk.Button(top,text="EXTRACT NOW",command=self.refresh_market_intelligence).grid(row=1,column=3,padx=4)
        ttk.Button(top,text="STOP",command=self.stop_market_auto).grid(row=1,column=4,padx=4)
        ttk.Button(top,text="CLEAR SNAPSHOTS",command=self.clear_market_snapshots).grid(row=1,column=5,padx=4)
        top.columnconfigure(1,weight=1)

        self.market_status=tk.StringVar(value="No exchange source connected.")
        ttk.Label(self.tab_market,textvariable=self.market_status,font=("Arial",11,"bold")).pack(pady=4)

        summary=ttk.LabelFrame(self.tab_market,text="Live Exchange Summary",padding=8)
        summary.pack(fill="x",pady=4)
        self.market_summary=tk.StringVar(value="Waiting for extraction.")
        ttk.Label(summary,textvariable=self.market_summary,justify="left").pack(anchor="w")

        self.market_out=tk.Text(self.tab_market,height=34,font=("Consolas",10),wrap="word")
        self.market_out.pack(fill="both",expand=True)
        self.market_snapshots=[]
        self.market_refresh_job=None
        self.exchange_latest={}

    def clear_market_snapshots(self):
        self.market_snapshots=[]
        self.exchange_latest={}
        self.market_summary.set("Snapshots cleared.")
        self.market_out.delete("1.0","end")

    def stop_market_auto(self):
        self.market_auto.set(False)
        if getattr(self,"market_refresh_job",None):
            try:self.root.after_cancel(self.market_refresh_job)
            except:pass
            self.market_refresh_job=None

    def toggle_market_auto(self):
        if self.market_auto.get():
            self._schedule_market_refresh()
        else:
            self.stop_market_auto()

    def _schedule_market_refresh(self):
        if getattr(self,"market_refresh_job",None):
            try:self.root.after_cancel(self.market_refresh_job)
            except:pass
        try:sec=max(5,int(self.market_refresh_seconds.get() or 8))
        except:sec=8
        self.market_refresh_job=self.root.after(sec*1000,self._market_tick)

    def _market_tick(self):
        if self.market_auto.get():
            try:self.refresh_market_intelligence(silent=True)
            except:pass
            self._schedule_market_refresh()

    def _same_match_score(self,text):
        text=player_key(text or "")
        names=[self.bat_team.get(),self.bowl_team.get()]
        tokens=[]
        for n in names:
            k=player_key(n)
            if k:tokens.append(k)
        if not tokens:return 0.0
        hits=0.0
        for k in tokens:
            if k in text:
                hits+=1
            else:
                words=[w for w in k.split() if len(w)>=4]
                if words:
                    matched=sum(1 for w in words if w in text)
                    if matched>=max(1,len(words)//2):hits+=0.65
        return round(hits/len(tokens),2)

    def _exchange_section_stats(self,parsed):
        rows=parsed.get("market_rows",[])
        counts={}
        for r in rows:
            counts[r["section"]]=counts.get(r["section"],0)+1
        return counts

    def _exchange_changed_rows(self,current,previous):
        if not previous:return []
        old={(r["section"],r["text"]):r for r in previous.get("market_rows",[])}
        changed=[]
        for r in current.get("market_rows",[]):
            key=(r["section"],r["text"])
            if key not in old:
                changed.append(("NEW",r))
            else:
                if old[key].get("values")!=r.get("values") or old[key].get("flags")!=r.get("flags"):
                    changed.append(("CHANGED",r))
        return changed[:40]

    def refresh_market_intelligence(self,silent=False):
        url=self.market_url.get().strip()
        if not url:
            if not silent:messagebox.showerror("Exchange source","Paste the exact Dubaiexch247 match/event URL.")
            return
        try:
            self.market_status.set("Rendering exchange match page...")
            self.root.update_idletasks()

            parsed=PublicMarketPageClient().parse(url)
            same=self._same_match_score(
                (parsed.get("match_name","")+" "+parsed.get("text_sample",""))
            )

            previous=self.exchange_latest if getattr(self,"exchange_latest",None) else None
            changed=self._exchange_changed_rows(parsed,previous)
            self.exchange_latest=parsed
            self.market_snapshots.append(parsed)
            self.market_snapshots=self.market_snapshots[-120:]

            counts=self._exchange_section_stats(parsed)
            total_rows=len(parsed.get("market_rows",[]))
            total_limits=len(parsed.get("limits",[]))
            self.market_summary.set(
                f"Match on exchange: {parsed.get('match_name') or 'not detected'}\n"
                f"Same-match confidence: {same*100:.0f}% | Extracted rows: {total_rows} | "
                f"Limits: {total_limits} | Changes since last refresh: {len(changed)}"
            )

            lines=[
                "DUBAIEXCH247 — LIVE EXCHANGE DATA EXTRACT",
                "="*98,
                f"App match     : {self.bat_team.get() or '--'} vs {self.bowl_team.get() or '--'}",
                f"Exchange match: {parsed.get('match_name') or '--'}",
                f"Same-match confidence: {same*100:.0f}%",
                f"Extracted at  : {time.strftime('%H:%M:%S')}",
                f"Source        : {url}",
                "",
            ]

            if parsed.get("blocked"):
                lines += ["STATUS: SOURCE BLOCKED / ANTI-BOT PAGE",
                          "No exchange values accepted from this refresh."]
            elif parsed.get("login_required"):
                lines += ["STATUS: LOGIN REQUIRED",
                          "The read-only extractor cannot access account-only market data.",
                          "No credentials are requested or stored."]
            else:
                if same<0.5:
                    lines += ["WARNING: SAME MATCH NOT VERIFIED.",
                              "Raw rows are displayed below, but they are not marked as trusted same-match data.",""]
                else:
                    lines += ["STATUS: SAME MATCH VERIFIED FOR EXTRACTION",""]

                section_titles=[
                    ("match_odds","MATCH ODDS"),
                    ("who_will_win","WHO WILL WIN THE MATCH"),
                    ("bookmaker","BOOKMAKER"),
                    ("fancy_market","FANCY MARKET / SESSION"),
                    ("line_market","LINE MARKET"),
                    ("ball_by_ball","BALL BY BALL MARKET"),
                    ("khado_market","KHADO MARKET"),
                    ("meter_market","METER MARKET"),
                    ("tied_match","TIED MATCH"),
                ]
                rows=parsed.get("market_rows",[])
                for key,title in section_titles:
                    section=[r for r in rows if r["section"]==key]
                    lines += ["",title,"-"*98]
                    if not section:
                        lines.append("No visible rows detected.")
                    else:
                        for r in section:
                            flagtxt=(" ["+", ".join(r["flags"])+"]") if r.get("flags") else ""
                            valtxt=(" | values: "+", ".join(str(x) for x in r["values"])) if r.get("values") else ""
                            lines.append(f"{r['text']}{flagtxt}{valtxt}")

                lines += ["","LIMITS","-"*98]
                if parsed.get("limits"):
                    for r in parsed["limits"]:
                        lines.append(f"Min {r['min']} | Max {r['max']} | {r['text']}")
                else:
                    lines.append("No explicit Min/Max rows detected.")

                lines += ["","BACK/LAY & NO/YES HEADERS","-"*98]
                if parsed.get("headers"):
                    for h in parsed["headers"]:
                        lines.append(h["text"])
                else:
                    lines.append("No explicit Back/Lay or No/Yes headers detected.")

                lines += ["","CHANGES SINCE PREVIOUS REFRESH","-"*98]
                if changed:
                    for status,r in changed:
                        lines.append(f"{status}: [{r['section']}] {r['text']} | values {r.get('values',[])}")
                else:
                    lines.append("No detected row/value changes or this is the first snapshot.")

                lines += ["","RAW VISIBLE MARKET ROWS","-"*98]
                for r in rows[:120]:
                    lines.append(f"[{r['section']}] {r['text']} | values={r['values']} | flags={r['flags']}")

            self.market_out.delete("1.0","end")
            self.market_out.insert("1.0","\n".join(lines))
            self.market_status.set(
                f"Exchange extracted {time.strftime('%H:%M:%S')} • "
                f"{total_rows} rows • same-match {same*100:.0f}%"
            )
        except Exception as e:
            self.market_status.set("Exchange extraction failed.")
            if not silent:messagebox.showerror("Exchange Live Data",str(e))


    def build_players(self):
        ttk.Label(self.tab_players,text="Player Historical Lookup",font=("Arial",18,"bold")).pack(pady=8)
        fr=ttk.Frame(self.tab_players); fr.pack(fill="x")
        self.lookup_name=tk.StringVar()
        self.lookup_box=ttk.Combobox(fr,textvariable=self.lookup_name,width=42)
        self.lookup_box.pack(side="left",padx=4)
        self.lookup_box.bind("<KeyRelease>",lambda e:self.filter_combo(self.lookup_box,self.db.all_players(self.format_var.get())))
        ttk.Button(fr,text="LOOK UP",command=self.lookup).pack(side="left",padx=4)
        ttk.Button(fr,text="REFRESH PLAYERS",command=lambda:self.lookup_box.configure(values=self.db.all_players(self.format_var.get()))).pack(side="left",padx=4)
        self.player_out=tk.Text(self.tab_players,height=30,font=("Consolas",11))
        self.player_out.pack(fill="both",expand=True,pady=10)
        self.lookup_box["values"]=self.db.all_players(self.format_var.get())

    def lookup(self):
        p=self.lookup_name.get(); fmt=self.format_var.get()
        b=self.db.player_batting(p,fmt); bo=self.db.player_bowling(p,fmt)
        bs=self.model.batter_score(p,fmt); bos=self.model.bowler_score(p,fmt)
        lines=[f"{p} | {fmt}", "="*60]
        if b:
            lines += [f"BATTER RATING: {bs[0]}/100",
                      f"Matches: {b['matches']} | Runs: {b['runs']} | Balls: {b['balls']}",
                      f"SR: {b['sr']:.1f} | Avg: {b['avg']:.1f}",
                      f"Boundary%: {b['boundary_pct']:.1f} | Dot%: {b['dot_pct']:.1f}",
                      f"PP SR: {b['pp_sr']:.1f} | Middle SR: {b['mid_sr']:.1f} | Death SR: {b['death_sr']:.1f}"]
        else: lines += ["No batting history found."]
        lines += [""]
        if bo:
            lines += [f"BOWLER RATING: {bos[0]}/100",
                      f"Matches: {bo['matches']} | Balls: {bo['balls']} | Wickets: {bo['wickets']}",
                      f"Economy: {bo['econ']:.2f} | Strike rate: {bo['sr']:.1f}",
                      f"Dot%: {bo['dot_pct']:.1f} | Boundary conceded%: {bo['boundary_pct']:.1f}",
                      f"PP Econ: {bo['pp_econ']:.2f} | Middle Econ: {bo['mid_econ']:.2f} | Death Econ: {bo['death_econ']:.2f}"]
        else: lines += ["No bowling history found."]
        self.player_out.delete("1.0","end"); self.player_out.insert("1.0","\n".join(lines))

if __name__=="__main__":
    root=tk.Tk()
    App(root)
    root.mainloop()
