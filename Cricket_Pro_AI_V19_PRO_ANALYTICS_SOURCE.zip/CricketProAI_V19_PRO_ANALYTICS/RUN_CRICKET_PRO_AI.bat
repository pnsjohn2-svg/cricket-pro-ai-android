@echo off
cd /d "%~dp0"
title Cricket Pro AI V19 Professional Analytics
python cricket_pro_ai.py
pause
