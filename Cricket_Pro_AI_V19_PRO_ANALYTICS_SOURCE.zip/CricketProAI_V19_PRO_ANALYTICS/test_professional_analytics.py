import importlib.util
import json
import tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("cricket_pro_ai",HERE/"cricket_pro_ai.py")
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def engine():
    # The distribution method is deliberately independent of Tk initialization.
    return object.__new__(mod.App)


def test_distribution_is_deterministic_and_ordered():
    app=engine()
    a=app._professional_run_distribution(96,3,72,120,1.35,.14,.045,700)
    b=app._professional_run_distribution(96,3,72,120,1.35,.14,.045,700)
    assert a["median"]==b["median"]
    assert a["samples"]==b["samples"]
    assert 96<=a["p10"]<=a["p25"]<=a["median"]<=a["p75"]<=a["p90"]


def test_more_scoring_pace_raises_projection():
    app=engine()
    slow=app._professional_run_distribution(80,2,60,120,.85,.08,.04,900)
    fast=app._professional_run_distribution(80,2,60,120,1.55,.20,.04,900)
    assert fast["median"]>slow["median"]


def test_more_wicket_risk_does_not_raise_projection():
    app=engine()
    low=app._professional_run_distribution(110,5,84,120,1.30,.15,.03,900)
    high=app._professional_run_distribution(110,5,84,120,1.30,.15,.16,900)
    assert high["median"]<=low["median"]


def test_json_import_and_duplicate_skip():
    sample={
        "meta":{"data_version":"1.1.0"},
        "info":{"dates":["2026-08-20"],"match_type":"T20",
                "venue":"Test Ground","teams":["Alpha","Beta"],
                "outcome":{"winner":"Alpha"}},
        "innings":[{"team":"Alpha","overs":[{"over":0,"deliveries":[
            {"batter":"A Batter","bowler":"B Bowler","non_striker":"A Two",
             "runs":{"batter":4,"extras":0,"total":4}},
            {"batter":"A Batter","bowler":"B Bowler","non_striker":"A Two",
             "runs":{"batter":0,"extras":1,"total":1},"extras":{"wides":1}}
        ]}]}]
    }
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"match_001.json";p.write_text(json.dumps(sample),encoding="utf-8")
        db=mod.DB(str(Path(td)/"test.db"))
        imp=mod.Importer(db)
        assert imp.import_json_file(p) is True
        assert imp.import_json_file(p) is False
        counts=db.counts()
        assert counts["matches"]==1
        # The wide adds a run but not a legal delivery.
        row=db.conn.execute("select total_runs,balls from innings").fetchone()
        assert int(row["total_runs"])==5 and int(row["balls"])==1
        db.conn.close()


if __name__=="__main__":
    test_distribution_is_deterministic_and_ordered()
    test_more_scoring_pace_raises_projection()
    test_more_wicket_risk_does_not_raise_projection()
    test_json_import_and_duplicate_skip()
    print("professional analytics tests: PASS")
